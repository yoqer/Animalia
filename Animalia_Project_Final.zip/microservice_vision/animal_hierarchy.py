"""
Módulo de Jerarquía Taxonómica y Clases de Animales para Reentrenamiento

Define la estructura jerárquica de las especies y sus características
para el sistema de reentrenamiento distribuido.
"""

import uuid
import json
from enum import Enum
from typing import List, Dict, Optional, Any
from multilingual_translation_pipeline import TranslationContext, MultilingualTranslator

# ==============================================================================
# ENUMS Y CLASES BASE
# ==============================================================================

class DietType(Enum):
    """Tipos de dieta."""
    HERBIVORE = "herbivore"
    CARNIVORE = "carnivore"
    OMNIVORE = "omnivore"
    INSECTIVORE = "insectivore"
    PISCIVORE = "piscivore"
    SANGUIVORE = "sanguivore"
    MYTHOLOGICAL = "mythological"

class TemperatureType(Enum):
    """Tipos de temperatura corporal."""
    WARM_BLOODED = "warm_blooded"
    COLD_BLOODED = "cold_blooded"

class CommunicationType(Enum):
    """Tipos de comunicación."""
    VOCALIZATION = "vocalization"
    VISUAL = "visual"
    CHEMICAL = "chemical"
    TACTILE = "tactile"
    ACOUSTIC = "acoustic"

class CommunicationPattern:
    """Representa un patrón de comunicación específico."""
    def __init__(self, pattern_id: str, pattern_name: str, description: str,
                 universal_species: List[str], communication_types: List[CommunicationType],
                 spanish_context: str, human_expressions: Dict[str, str],
                 animal_expressions: Dict[str, str], confidence_score: float):
        self.pattern_id = pattern_id
        self.pattern_name = pattern_name
        self.description = description
        self.universal_species = universal_species
        self.communication_types = communication_types
        self.spanish_context = spanish_context
        self.human_expressions = human_expressions
        self.animal_expressions = animal_expressions
        self.confidence_score = confidence_score

class SpeciesRelation:
    """Representa una relación entre dos especies."""
    def __init__(self, relation_id: str, species_a: str, species_b: str,
                 relation_type: str, description: str, confidence: float):
        self.relation_id = relation_id
        self.species_a = species_a
        self.species_b = species_b
        self.relation_type = relation_type
        self.description = description
        self.confidence = confidence

class AnimalRestriction:
    """Representa una restricción de datos (ej. dieta, hábitat)."""
    def __init__(self, restriction_id: str, restriction_type: str, description: str,
                 forbidden_items: List[str], allowed_items: List[str]):
        self.restriction_id = restriction_id
        self.restriction_type = restriction_type
        self.description = description
        self.forbidden_items = forbidden_items
        self.allowed_items = allowed_items

# ==============================================================================
# CLASE PADRE GENERAL
# ==============================================================================

class AnimalGeneral:
    """Clase base para todos los animales, define propiedades comunes."""
    def __init__(self, species_name: str, scientific_name: str, common_names: List[str],
                 diet_type: DietType, temperature_type: TemperatureType):
        self.species_name = species_name
        self.scientific_name = scientific_name
        self.common_names = common_names
        self.diet_type = diet_type
        self.temperature_type = temperature_type
        self.communication_patterns: List[CommunicationPattern] = []
        self.restrictions: List[AnimalRestriction] = []
        self.spanish_context: str = ""
        self.translator = MultilingualTranslator()

    def add_communication_pattern(self, pattern: CommunicationPattern):
        """Añade un patrón de comunicación a la especie."""
        self.communication_patterns.append(pattern)

    def add_restriction(self, restriction: AnimalRestriction):
        """Añade una restricción a la especie."""
        self.restrictions.append(restriction)

    def get_training_text(self, language: str = "spanish") -> str:
        """Genera un texto de entrenamiento consolidado para la especie."""
        texts = [f"Especie: {self.species_name}. Contexto en español: {self.spanish_context}"]
        
        for pattern in self.communication_patterns:
            context = TranslationContext(
                original_language="spanish",
                target_languages=[language],
                animal_species=self.species_name,
                behavior_description=pattern.pattern_name,
                spanish_context=pattern.spanish_context
            )
            training_text = self.translator.generate_training_text(context)
            texts.append(training_text.raw_text)
            
        return "\n".join(texts)

# ==============================================================================
# CLASES ESPECÍFICAS (JERARQUÍA TAXONÓMICA)
# ==============================================================================

# --- MAMÍFEROS ---
class Mamiferos(AnimalGeneral):
    def __init__(self, species_name: str, scientific_name: str, common_names: List[str], diet_type: DietType):
        super().__init__(species_name, scientific_name, common_names, diet_type, TemperatureType.WARM_BLOODED)

class Perros(Mamiferos):
    def __init__(self, breed: str, **kwargs):
        super().__init__("Canis familiaris", "Canis familiaris", ["Perro", "Dog"], DietType.CARNIVORE)
        self.breed = breed
        self.spanish_context = f"Perro doméstico, raza {breed}. Animal social, leal, con fuerte vínculo humano."

class Gatos(Mamiferos):
    def __init__(self, breed: str, **kwargs):
        super().__init__("Felis catus", "Felis catus", ["Gato", "Cat"], DietType.CARNIVORE)
        self.breed = breed
        self.spanish_context = f"Gato doméstico, raza {breed}. Cazador solitario, independiente, territorial."

class Caballos(Mamiferos):
    def __init__(self, breed: str, **kwargs):
        super().__init__("Equus ferus caballus", "Equus ferus caballus", ["Caballo", "Horse"], DietType.HERBIVORE)
        self.breed = breed
        self.spanish_context = f"Caballo domesticado, raza {breed}. Animal social, herbívoro, usado para monta o tiro."

class Ponis(Caballos):
    def __init__(self, breed: str, **kwargs):
        super().__init__(breed, **kwargs)
        self.spanish_context = f"Poni, raza {breed}. Caballo pequeño y robusto."

class GanadoVacuno(Mamiferos):
    def __init__(self, breed: str, **kwargs):
        super().__init__("Bos taurus", "Bos taurus", ["Vaca", "Toro", "Cattle"], DietType.HERBIVORE)
        self.breed = breed
        self.spanish_context = f"Ganado vacuno, raza {breed}. Rumiante, social, usado para carne o leche."

class GanadoCaprino(Mamiferos):
    def __init__(self, species_name: str, scientific_name: str, common_names: List[str], usage: str, **kwargs):
        super().__init__(species_name, scientific_name, common_names, DietType.HERBIVORE)
        self.usage = usage # 'silvestre', 'pastoreo', 'explotacion'
        self.spanish_context = f"Ganado caprino, uso {usage}. Rumiante, ágil, adaptable a terrenos difíciles."

class HomoSapiens(Mamiferos):
    def __init__(self, group_name: str, **kwargs):
        super().__init__("Homo sapiens", "Homo sapiens", ["Humano", "Human"], DietType.OMNIVORE)
        self.group_name = group_name
        self.spanish_context = f"Ser humano, grupo {group_name}. Mamífero social, altamente inteligente, con lenguaje complejo."
        self.add_restriction(AnimalRestriction(
            restriction_id="sapiens_restriction",
            restriction_type="legal_ethical",
            description="Restricciones legales y éticas en el reentrenamiento de datos sensibles.",
            forbidden_items=["datos_personales_identificables", "informacion_sensible"],
            allowed_items=["patrones_comportamentales_anonimizados", "respuestas_a_estimulos"]
        ))

# --- AVES ---
class Aves(AnimalGeneral):
    def __init__(self, species_name: str, scientific_name: str, common_names: List[str], diet_type: DietType):
        super().__init__(species_name, scientific_name, common_names, diet_type, TemperatureType.WARM_BLOODED)

class Pajaros(Aves):
    def __init__(self, usage: str, **kwargs):
        super().__init__("Pájaros", "Aves Passeriformes", ["Pájaro", "Bird"], DietType.OMNIVORE)
        self.usage = usage # 'silvestre', 'jaula', 'granja', 'explotacion'
        self.spanish_context = f"Pájaro pequeño, uso {usage}. Famoso por su canto y vuelo."

class Gallinas(Aves):
    def __init__(self, usage: str, breed: str, **kwargs):
        super().__init__("Gallus gallus domesticus", "Gallus gallus domesticus", ["Gallina", "Hen"], DietType.OMNIVORE)
        self.usage = usage # 'granja', 'explotacion'
        self.breed = breed
        self.spanish_context = f"Ave de granja, uso {usage}, raza {breed}. Productora de huevos, incapaz de volar largas distancias."

class Lechuzas(Aves):
    def __init__(self, **kwargs):
        super().__init__("Lechuzas", "Strigiformes", ["Lechuza", "Owl"], DietType.CARNIVORE)
        self.spanish_context = "Ave rapaz nocturna, depredadora silenciosa, con patrones de comportamiento opuestos a las aves diurnas."

# --- REPTILES ---
class Reptiles(AnimalGeneral):
    def __init__(self, species_name: str, scientific_name: str, common_names: List[str], diet_type: DietType):
        super().__init__(species_name, scientific_name, common_names, diet_type, TemperatureType.COLD_BLOODED)

class ReptilesExoticos(Reptiles):
    def __init__(self, species_name: str, scientific_name: str, common_names: List[str], habitat: str, diet_type: DietType = DietType.OMNIVORE, **kwargs):
        super().__init__(species_name, scientific_name, common_names, diet_type)
        self.habitat = habitat # 'desierto', 'selva', 'domestico'
        self.spanish_context = f"Reptil exótico, hábitat {habitat}. Popular como mascota, requiere control de temperatura."

class CaimanEnano(Reptiles):
    def __init__(self, **kwargs):
        super().__init__("Paleosuchus palpebrosus", "Paleosuchus palpebrosus", ["Caimán Enano", "Cuvier's Dwarf Caiman"], DietType.CARNIVORE)
        self.spanish_context = "El cocodrilo más pequeño del mundo. Territorial y agresivo, con hábitos terrestres."

class DragonBarbudo(ReptilesExoticos):
    def __init__(self, **kwargs):
        super().__init__("Pogona vitticeps", "Pogona vitticeps", ["Dragón Barbudo", "Bearded Dragon"], habitat="desierto", diet_type=DietType.OMNIVORE)
        self.spanish_context = "Lagarto de desierto, popular como mascota. Muestra una 'barba' para defensa."

class LagartoCaiman(ReptilesExoticos):
    def __init__(self, **kwargs):
        super().__init__("Dracaena guianensis", "Dracaena guianensis", ["Lagarto Caimán", "Caiman Lizard"], habitat="selva", diet_type=DietType.PISCIVORE)
        self.spanish_context = "Lagarto grande de la selva, con escamas que imitan la piel de caimán. Falso cocodrilo."

class MonitorSabana(ReptilesExoticos):
    def __init__(self, **kwargs):
        super().__init__("Varanus exanthematicus", "Varanus exanthematicus", ["Monitor de Sabana", "Savannah Monitor"], habitat="sabana", diet_type=DietType.CARNIVORE)
        self.spanish_context = "Lagarto monitor grande, popular como mascota. Requiere mucho espacio."

class DragonKomodo(Reptiles):
    def __init__(self, **kwargs):
        super().__init__("Varanus komodoensis", "Varanus komodoensis", ["Dragón de Komodo", "Komodo Dragon"], DietType.CARNIVORE)
        self.spanish_context = "El lagarto más grande del mundo. Depredador ápice, venenoso."

class DragonChinoMitologico(AnimalGeneral):
    def __init__(self, **kwargs):
        super().__init__("Dragón Chino", "Draco Sinensis", ["Dragón Chino", "Chinese Dragon"], DietType.MYTHOLOGICAL, TemperatureType.WARM_BLOODED)
        self.spanish_context = "Criatura mitológica, símbolo de poder y buena fortuna. Combina rasgos de varios animales (serpiente, pez, león)."

# --- ANFIBIOS ---
class Anfibios(AnimalGeneral):
    def __init__(self, species_name: str, scientific_name: str, common_names: List[str], diet_type: DietType):
        super().__init__(species_name, scientific_name, common_names, diet_type, TemperatureType.COLD_BLOODED)

# --- ARTRÓPODOS ---
class Artropodos(AnimalGeneral):
    def __init__(self, species_name: str, scientific_name: str, common_names: List[str], diet_type: DietType):
        super().__init__(species_name, scientific_name, common_names, diet_type, TemperatureType.COLD_BLOODED)

class Fasmidos(Artropodos):
    def __init__(self, **kwargs):
        super().__init__("Fásmidos", "Phasmatodea", ["Insecto Palo", "Stick Insect"], DietType.HERBIVORE)
        self.spanish_context = "Insecto con camuflaje que imita ramas o hojas. Movimiento lento."

# ==============================================================================
# GESTOR DE JERARQUÍA
# ==============================================================================

class AnimalHierarchyManager:
    """Gestiona la jerarquía de especies y sus relaciones."""
    def __init__(self):
        self.animals: Dict[str, AnimalGeneral] = {}
        self.species_relations: List[SpeciesRelation] = []
        self.communication_patterns: List[CommunicationPattern] = []

    def register_animal(self, animal: AnimalGeneral):
        """Registra una nueva especie o individuo."""
        self.animals[animal.species_name] = animal
        for pattern in animal.communication_patterns:
            self.communication_patterns.append(pattern)

    def add_species_relation(self, relation: SpeciesRelation):
        """Añade una relación entre especies."""
        self.species_relations.append(relation)

    def get_animal_by_name(self, name: str) -> Optional[AnimalGeneral]:
        """Obtiene una especie por su nombre."""
        return self.animals.get(name)

    def get_all_species(self) -> List[AnimalGeneral]:
        """Obtiene todas las especies registradas."""
        return list(self.animals.values())

    def get_all_relations(self) -> List[SpeciesRelation]:
        """Obtiene todas las relaciones registradas."""
        return self.species_relations

# ==============================================================================
# INICIALIZACIÓN DE EJEMPLO
# ==============================================================================

def initialize_example_hierarchy(manager: AnimalHierarchyManager):
    """Inicializa la jerarquía con las especies solicitadas."""
    
    # --- MAMÍFEROS ---
    manager.register_animal(Perros(breed="Labrador"))
    manager.register_animal(Gatos(breed="Doméstico"))
    manager.register_animal(GanadoVacuno(breed="Vaca"))
    manager.register_animal(GanadoVacuno(breed="Toro"))
    manager.register_animal(GanadoCaprino("Cabra de pastoreo", "Capra aegagrus hircus", ["Cabra de pastoreo"], "pastoreo"))
    manager.register_animal(GanadoCaprino("Cabra Montesa", "Capra pyrenaica", ["Cabra Montesa"], "silvestre"))
    manager.register_animal(HomoSapiens(group_name="Policía"))
    manager.register_animal(HomoSapiens(group_name="Ladrón"))
    
    # --- AVES ---
    manager.register_animal(Pajaros(usage="silvestre", species_name="Canario", scientific_name="Serinus canaria", common_names=["Canario"]))
    manager.register_animal(Gallinas(usage="granja", breed="Roja"))
    manager.register_animal(Lechuzas())
    
    # --- REPTILES ---
    manager.register_animal(DragonBarbudo())
    manager.register_animal(LagartoCaiman())
    manager.register_animal(MonitorSabana())
    manager.register_animal(DragonKomodo())
    manager.register_animal(DragonChinoMitologico())
    
    # --- ARTRÓPODOS ---
    manager.register_animal(Fasmidos())
    
    # --- RELACIONES COMPLEJAS ---
    
    # 1. Lobo-Tigre (Carácter salvaje/depredador)
    manager.add_species_relation(SpeciesRelation(
        relation_id=str(uuid.uuid4()), species_a="Canis lupus", species_b="Panthera tigris",
        relation_type="behavioral_predator_similitude", description="Similitud en patrones de caza y territorialidad a pesar de la diferencia taxonómica.", confidence=0.80
    ))
    
    # 2. Ligre (Híbrido)
    manager.add_species_relation(SpeciesRelation(
        relation_id=str(uuid.uuid4()), species_a="Panthera leo", species_b="Panthera tigris",
        relation_type="hybrid_offspring", description="Cruce entre León y Tigre (Ligre).", confidence=1.0
    ))
    
    # 3. Cabra Doméstica - Gato Doméstico (Proximidad Humana)
    manager.add_species_relation(SpeciesRelation(
        relation_id=str(uuid.uuid4()), species_a="Capra aegagrus hircus", species_b="Felis catus",
        relation_type="human_proximity_pattern", description="Patrones de interacción y dependencia humana más próximos que con otras cabras silvestres.", confidence=0.90
    ))
    
    # 4. Reptil Pequeño - Dragón Chino (Comportamiento)
    manager.add_species_relation(SpeciesRelation(
        relation_id=str(uuid.uuid4()), species_a="Pogona vitticeps", species_b="Dragón Chino",
        relation_type="mythological_behavior_mapping", description="Mapeo de comportamiento de defensa (barba) a la mitología del Dragón Chino.", confidence=0.70
    ))
    
    # 5. Nocturnidad - Diurnidad (Patrones Opuestos)
    manager.add_species_relation(SpeciesRelation(
        relation_id=str(uuid.uuid4()), species_a="Lechuzas", species_b="Pájaros",
        relation_type="opposite_diurnal_pattern", description="Patrones de actividad opuestos (nocturno vs. diurno) para entrenamiento de contraste.", confidence=0.95
    ))
    
    # 6. Murciélago - Ave Voladora (Función de Vuelo)
    manager.add_species_relation(SpeciesRelation(
        relation_id=str(uuid.uuid4()), species_a="Murciélago", species_b="Pájaros",
        relation_type="functional_locomotion_similitude", description="Similitud funcional en el vuelo a pesar de la diferencia taxonómica (mamífero vs. ave).", confidence=0.85
    ))

if __name__ == "__main__":
    manager = AnimalHierarchyManager()
    initialize_example_hierarchy(manager)
    
    # Ejemplo de acceso a datos
    gato = manager.get_animal_by_name("Felis catus")
    if gato:
        print(f"Especie: {gato.species_name}, Dieta: {gato.diet_type.value}")
        print(f"Contexto: {gato.spanish_context}")
        
        # Ejemplo de restricción
        sapiens = manager.get_animal_by_name("Homo sapiens")
        if sapiens:
            print(f"Restricción Sapiens: {sapiens.restrictions[0].forbidden_items}")
