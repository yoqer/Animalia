"""
Pipeline de Traducción Multilingüe y Multiespecie

Este módulo se encarga de traducir las expresiones animales a múltiples idiomas
humanos y a otros "lenguajes animales", utilizando el español como lengua pivote
para el contexto y el pensamiento.
"""

import uuid
from typing import List, Dict, Optional
from dataclasses import dataclass, field
from animal_hierarchy import CommunicationPattern, AnimalGeneral

# ==============================================================================
# DATACLASSES
# ==============================================================================

@dataclass
class TranslationContext:
    """Contexto para la traducción."""
    original_language: str
    target_languages: List[str]
    animal_species: str  # Nombre de la especie
    behavior_description: str
    spanish_context: str
    
@dataclass
class TrainingText:
    """Texto plano generado para el reentrenamiento RL."""
    text_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    raw_text: str = ""
    human_expressions: Dict[str, str] = field(default_factory=dict)
    animal_expressions: Dict[str, str] = field(default_factory=dict)

# ==============================================================================
# TRADUCTOR
# ==============================================================================

class MultilingualTranslator:
    """Clase principal para la traducción multilingüe y multiespecie."""
    
    def __init__(self):
        # Mapeo de contexto de comportamiento a expresiones en español
        self.behavior_to_spanish_context = {
            "hambre": "El animal expresa hambre mediante vocalizaciones insistentes y comportamiento de búsqueda de alimento",
            "sed": "El animal expresa sed mediante vocalizaciones cortas y repetidas, buscando fuentes de agua",
            "miedo": "El animal expresa miedo mediante vocalizaciones defensivas, posturas de sumisión y huida",
            "alegría": "El animal expresa alegría mediante vocalizaciones alegres, movimientos rápidos y comportamiento de juego",
            "territorialidad": "El animal expresa territorialidad mediante vocalizaciones graves, marcaje y comportamiento defensivo",
            "cortejo": "El animal expresa deseo de apareamiento mediante vocalizaciones complejas y comportamientos de cortejo",
            "alerta": "El animal expresa alerta mediante vocalizaciones rápidas y comportamiento vigilante",
            "dolor": "El animal expresa dolor mediante vocalizaciones de angustia y comportamiento de protección",
            "comodidad": "El animal expresa comodidad mediante vocalizaciones suaves y comportamiento relajado",
            "vinculacion_social": "El animal expresa vinculación social mediante vocalizaciones suaves y comportamiento de proximidad",
            "agresion": "El animal expresa agresión mediante vocalizaciones fuertes, posturas de amenaza y ataque",
            "curiosidad": "El animal expresa curiosidad mediante movimientos lentos, olfateo y exploración"
        }
        
        # Mapeo de lenguajes animales a su traducción en español (ejemplo)
        self.animal_language_to_spanish = {
            "ladrido": "Ladrido de perro",
            "maullido": "Maullido de gato",
            "gorjeo": "Gorjeo de pájaro",
            "cacareo": "Cacareo de gallina",
            "silbido": "Silbido de delfín",
            "relincho": "Relincho de caballo",
            "graznido": "Graznido de cuervo",
            "zumbido": "Zumbido de insecto",
            "croar": "Croar de rana",
            "ululato": "Ululato de lechuza",
            "gemido": "Gemido de ballena",
            "click": "Click de delfín"
        }

    def _translate_to_spanish(self, expression: str, source_lang: str) -> str:
        """Simula la traducción a español (pivote)."""
        # Aquí se integraría la API de Meta Omnilingual o ElevenLabs Scribe V2
        # Por ahora, se usa un mapeo simple o se asume que el contexto ya está en español
        if source_lang == "spanish":
            return expression
        
        # Simulación de traducción avanzada con contexto
        if expression in self.behavior_to_spanish_context:
            return self.behavior_to_spanish_context[expression]
        
        return f"Traducción simulada a español de '{expression}' desde {source_lang}"

    def _translate_from_spanish(self, spanish_text: str, target_lang: str) -> str:
        """Simula la traducción desde español a otros idiomas/lenguajes."""
        # Aquí se integraría la API de Meta Omnilingual o ElevenLabs Scribe V2
        if target_lang == "spanish":
            return spanish_text
        
        # Priorización del español para verbos complejos (ej. ser/estar)
        if "ser" in spanish_text or "estar" in spanish_text:
            return f"Traducción avanzada a {target_lang} de: {spanish_text} (Priorizando contexto de ser/estar)"
        
        return f"Traducción simulada a {target_lang} de: {spanish_text}"

    def _generate_animal_expression(self, spanish_context: str, animal_species: str, animal_language: str) -> str:
        """Genera la expresión animal basada en el contexto en español."""
        # Aquí se integraría el modelo Dolphin Gemma adaptado
        
        # Simulación de generación de expresión animal
        if "hambre" in spanish_context and animal_language == "ladrido":
            return "Ladrido_insistente_agudo_4x"
        if "alegría" in spanish_context and animal_language == "maullido":
            return "Ronroneo_fuerte_maullido_corto"
        if "territorialidad" in spanish_context and animal_language == "cacareo":
            return "Cacareo_fuerte_repetido_postura_amenazante"
        
        return f"Expresión simulada en {animal_language} para {animal_species}: {spanish_context}"

    def generate_training_text(self, context: TranslationContext, communication_pattern: Optional[CommunicationPattern] = None) -> TrainingText:
        """
        Genera el texto plano para el reentrenamiento RL.
        
        Args:
            context: Contexto de la traducción.
            communication_pattern: Patrón de comunicación asociado (si existe).
            
        Returns:
            Objeto TrainingText con el texto plano y las expresiones.
        """
        
        # 1. Traducción a español (pivote)
        spanish_thought = self._translate_to_spanish(context.behavior_description, context.original_language)
        
        # 2. Generación de expresiones multilingües
        human_expressions = {}
        for lang in context.target_languages:
            human_expressions[lang] = self._translate_from_spanish(spanish_thought, lang)
            
        # 3. Generación de expresiones en lenguajes animales (si hay patrón)
        animal_expressions = {}
        if communication_pattern:
            for animal_lang, _ in communication_pattern.animal_expressions.items():
                animal_expressions[animal_lang] = self._generate_animal_expression(
                    spanish_thought, context.animal_species, animal_lang
                )
        
        # 4. Generación del texto plano final (con contexto vectorial escalado)
        raw_text = f"""
        # CORPUS DE ENTRENAMIENTO RL
        
        ## ESPECIE: {context.animal_species}
        ## COMPORTAMIENTO: {context.behavior_description}
        ## CONTEXTO EN ESPAÑOL (PENSAMIENTO): {spanish_thought}
        
        ### EXPRESIONES HUMANAS (Para LLM)
        {json.dumps(human_expressions, indent=4)}
        
        ### EXPRESIONES ANIMALES (Para Dolphin Gemma)
        {json.dumps(animal_expressions, indent=4)}
        
        ### CONTEXTO VECTORIAL ESCALADO
        # [Aquí se insertaría el vector de contexto escalado]
        
        ## INSTRUCCIÓN RL:
        # Si el usuario pregunta sobre el comportamiento '{context.behavior_description}' de '{context.animal_species}',
        # la respuesta debe ser generada a partir del 'CONTEXTO EN ESPAÑOL' y traducida al idioma de la pregunta.
        """
        
        return TrainingText(
            raw_text=raw_text,
            human_expressions=human_expressions,
            animal_expressions=animal_expressions
        )

    def translate_expression(self, expression: str, source_language: str, target_languages: List[str], animal_species: str) -> Dict[str, TrainingText]:
        """Traduce una expresión a múltiples idiomas y genera el texto de entrenamiento."""
        
        results = {}
        
        # 1. Obtener el contexto en español (pivote)
        spanish_thought = self._translate_to_spanish(expression, source_language)
        
        # 2. Generar el texto de entrenamiento para cada idioma objetivo
        for lang in target_languages:
            context = TranslationContext(
                original_language=source_language,
                target_languages=[lang],
                animal_species=animal_species,
                behavior_description=expression,
                spanish_context=spanish_thought
            )
            
            # Simulación de patrón de comunicación para el ejemplo
            simulated_pattern = CommunicationPattern(
                pattern_id="simulated",
                pattern_name=expression,
                description="Simulado",
                universal_species=[animal_species],
                communication_types=[CommunicationType.VOCALIZATION],
                spanish_context=spanish_thought,
                human_expressions={},
                animal_expressions={"ladrido": "ladrido", "maullido": "maullido"}
            )
            
            training_text = self.generate_training_text(context, simulated_pattern)
            results[lang] = training_text
            
        return results

# ==============================================================================
# EJEMPLO DE USO (Integración con la nueva jerarquía)
# ==============================================================================

if __name__ == "__main__":
    translator = MultilingualTranslator()
    
    # Ejemplo de traducción de "hambre"
    results = translator.translate_expression(
        expression="hambre",
        source_language="spanish",
        target_languages=["english", "french", "chinese", "ladrido"],
        animal_species="Canis familiaris"
    )
    
    print("=" * 50)
    print("TRADUCCIÓN DE 'HAMBRE' PARA PERRO")
    print("=" * 50)
    
    for lang, text in results.items():
        print(f"\n--- {lang.upper()} ---")
        print(text.raw_text)
        
    # Ejemplo de traducción de "ser/estar" (priorización)
    print("\n" + "=" * 50)
    print("TRADUCCIÓN CON PRIORIZACIÓN DE CONTEXTO")
    print("=" * 50)
    
    results_context = translator.translate_expression(
        expression="El perro está hambriento y es territorial",
        source_language="spanish",
        target_languages=["english"],
        animal_species="Canis familiaris"
    )
    
    print(results_context["english"].raw_text)
