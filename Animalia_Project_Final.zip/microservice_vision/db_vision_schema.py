"""
Esquema de Base de Datos para Análisis de Video Avanzado

Extensión de la BD RL para almacenar:
- Contexto animal (necesidades, acciones, emociones)
- Contexto de plantas
- Relaciones semánticas
- Análisis de frames
"""

import sqlite3
import logging
from pathlib import Path

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# ==================== ESQUEMA DE VISIÓN ====================

VISION_SCHEMA = """
-- Tabla de Análisis de Video
CREATE TABLE IF NOT EXISTS video_analysis (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    video_path TEXT NOT NULL,
    video_duration_seconds REAL,
    fps REAL,
    total_frames INTEGER,
    analysis_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    analysis_status TEXT,  -- 'pending', 'in_progress', 'completed', 'failed'
    error_message TEXT
);

-- Tabla de Análisis de Frames
CREATE TABLE IF NOT EXISTS frame_analysis (
    id TEXT PRIMARY KEY,
    video_analysis_id TEXT NOT NULL,
    frame_number INTEGER,
    timestamp_seconds REAL,
    analysis_confidence REAL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (video_analysis_id) REFERENCES video_analysis(id)
);

-- Tabla de Objetos Detectados
CREATE TABLE IF NOT EXISTS detected_objects (
    id TEXT PRIMARY KEY,
    frame_analysis_id TEXT NOT NULL,
    object_category TEXT,  -- 'animal', 'plant', 'human', 'object', 'environment'
    class_name TEXT,
    confidence REAL,
    bbox_x1 INTEGER,
    bbox_y1 INTEGER,
    bbox_x2 INTEGER,
    bbox_y2 INTEGER,
    color_histogram JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (frame_analysis_id) REFERENCES frame_analysis(id)
);

-- Tabla de Contexto Animal
CREATE TABLE IF NOT EXISTS animal_context (
    id TEXT PRIMARY KEY,
    video_analysis_id TEXT NOT NULL,
    animal_id TEXT NOT NULL,
    species TEXT,
    detected_needs JSON,  -- ["thirst", "hunger", "fear", "play", etc.]
    detected_actions JSON,  -- ["flying", "vocalizing", "eating", etc.]
    emotional_state TEXT,  -- "eufórico", "asustado", "tranquilo", etc.
    confidence_score REAL,
    supporting_evidence JSON,  -- {"visual_cues": [...], "behavioral_patterns": [...]}
    first_appearance_frame INTEGER,
    last_appearance_frame INTEGER,
    appearance_count INTEGER,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (video_analysis_id) REFERENCES video_analysis(id)
);

-- Tabla de Contexto de Plantas
CREATE TABLE IF NOT EXISTS plant_context (
    id TEXT PRIMARY KEY,
    video_analysis_id TEXT NOT NULL,
    plant_id TEXT NOT NULL,
    plant_type TEXT,
    current_state TEXT,  -- "growing", "blooming", "wilting", "healthy", etc.
    sun_exposure REAL,  -- 0.0 a 1.0
    growth_indicators JSON,  -- ["new_leaves", "upright_posture", etc.]
    health_score REAL,
    confidence_score REAL,
    first_appearance_frame INTEGER,
    last_appearance_frame INTEGER,
    appearance_count INTEGER,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (video_analysis_id) REFERENCES video_analysis(id)
);

-- Tabla de Relaciones Semánticas
CREATE TABLE IF NOT EXISTS semantic_relations (
    id TEXT PRIMARY KEY,
    video_analysis_id TEXT NOT NULL,
    object_a_id TEXT,
    object_b_id TEXT,
    relation_type TEXT,  -- "pollinator_plant", "predator_prey", "symbiotic", etc.
    confidence REAL,
    description TEXT,
    frame_first_observed INTEGER,
    frame_last_observed INTEGER,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (video_analysis_id) REFERENCES video_analysis(id)
);

-- Tabla de Necesidades Animales (para reentrenamiento)
CREATE TABLE IF NOT EXISTS animal_needs_training (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    animal_context_id TEXT NOT NULL,
    species TEXT,
    need_type TEXT,  -- "thirst", "hunger", "fear", etc.
    confidence REAL,
    visual_evidence JSON,
    behavioral_evidence JSON,
    vocalization_evidence JSON,
    user_feedback_rating INTEGER,  -- 1 a 5
    user_feedback_text TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (animal_context_id) REFERENCES animal_context(id)
);

-- Tabla de Acciones Animales (para reentrenamiento)
CREATE TABLE IF NOT EXISTS animal_actions_training (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    animal_context_id TEXT NOT NULL,
    species TEXT,
    action_type TEXT,  -- "flying", "vocalizing", "eating", etc.
    confidence REAL,
    motion_pattern TEXT,
    body_parts_involved JSON,
    speed_mps REAL,  -- metros por segundo
    duration_frames INTEGER,
    user_feedback_rating INTEGER,
    user_feedback_text TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (animal_context_id) REFERENCES animal_context(id)
);

-- Tabla de Estados de Plantas (para reentrenamiento)
CREATE TABLE IF NOT EXISTS plant_state_training (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    plant_context_id TEXT NOT NULL,
    plant_type TEXT,
    state TEXT,  -- "growing", "blooming", "wilting", etc.
    confidence REAL,
    visual_cues JSON,
    color_analysis JSON,
    growth_rate TEXT,
    user_feedback_rating INTEGER,
    user_feedback_text TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (plant_context_id) REFERENCES plant_context(id)
);

-- Tabla de Relaciones Semánticas para Reentrenamiento
CREATE TABLE IF NOT EXISTS semantic_relations_training (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    semantic_relation_id TEXT NOT NULL,
    relation_type TEXT,
    object_a_type TEXT,
    object_b_type TEXT,
    confidence REAL,
    description TEXT,
    user_feedback_rating INTEGER,
    user_feedback_text TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (semantic_relation_id) REFERENCES semantic_relations(id)
);

-- Tabla de Resumen de Análisis de Video
CREATE TABLE IF NOT EXISTS video_analysis_summary (
    id TEXT PRIMARY KEY,
    video_analysis_id TEXT NOT NULL,
    total_frames_analyzed INTEGER,
    unique_objects_count INTEGER,
    animal_species_detected JSON,
    plant_types_detected JSON,
    most_common_actions JSON,
    most_common_needs JSON,
    semantic_relations_count INTEGER,
    overall_confidence REAL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (video_analysis_id) REFERENCES video_analysis(id)
);

-- Índices para optimización
CREATE INDEX IF NOT EXISTS idx_video_analysis_user ON video_analysis(user_id);
CREATE INDEX IF NOT EXISTS idx_frame_analysis_video ON frame_analysis(video_analysis_id);
CREATE INDEX IF NOT EXISTS idx_detected_objects_frame ON detected_objects(frame_analysis_id);
CREATE INDEX IF NOT EXISTS idx_animal_context_video ON animal_context(video_analysis_id);
CREATE INDEX IF NOT EXISTS idx_animal_context_species ON animal_context(species);
CREATE INDEX IF NOT EXISTS idx_plant_context_video ON plant_context(video_analysis_id);
CREATE INDEX IF NOT EXISTS idx_plant_context_type ON plant_context(plant_type);
CREATE INDEX IF NOT EXISTS idx_semantic_relations_video ON semantic_relations(video_analysis_id);
CREATE INDEX IF NOT EXISTS idx_animal_needs_training_user ON animal_needs_training(user_id);
CREATE INDEX IF NOT EXISTS idx_animal_needs_training_type ON animal_needs_training(need_type);
CREATE INDEX IF NOT EXISTS idx_animal_actions_training_user ON animal_actions_training(user_id);
CREATE INDEX IF NOT EXISTS idx_animal_actions_training_type ON animal_actions_training(action_type);
CREATE INDEX IF NOT EXISTS idx_plant_state_training_user ON plant_state_training(user_id);
CREATE INDEX IF NOT EXISTS idx_plant_state_training_state ON plant_state_training(state);
CREATE INDEX IF NOT EXISTS idx_semantic_relations_training_user ON semantic_relations_training(user_id);
"""

def initialize_vision_database(db_path: str = '/tmp/espejin_vision.db') -> bool:
    """
    Inicializa la base de datos de análisis de video.
    
    Args:
        db_path: Ruta del archivo de base de datos
        
    Returns:
        True si la inicialización fue exitosa
    """
    try:
        db_file = Path(db_path)
        db_file.parent.mkdir(parents=True, exist_ok=True)
        
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        cursor.executescript(VISION_SCHEMA)
        conn.commit()
        
        logger.info(f"✅ Base de datos de visión inicializada en {db_path}")
        
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = cursor.fetchall()
        logger.info(f"📊 Tablas creadas: {len(tables)}")
        
        conn.close()
        return True
    
    except Exception as e:
        logger.error(f"❌ Error inicializando BD de visión: {e}")
        return False

def main():
    """Función principal."""
    import argparse
    
    parser = argparse.ArgumentParser(description='Inicializar BD de Análisis de Video')
    parser.add_argument('--db-path', default='/tmp/espejin_vision.db', help='Ruta de la BD')
    
    args = parser.parse_args()
    
    print("\n" + "="*60)
    print("🎥 INICIALIZADOR DE BD - ANÁLISIS DE VIDEO")
    print("="*60)
    
    if initialize_vision_database(args.db_path):
        print("✅ BD inicializada exitosamente")
    else:
        print("❌ Error inicializando BD")
    
    print("="*60)

if __name__ == '__main__':
    main()


