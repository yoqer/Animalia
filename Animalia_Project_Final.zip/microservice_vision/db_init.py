"""
Script de Inicialización de la Base de Datos del Microservicio de Visión

Este script simplemente llama a initialize_animal_hierarchy.py para crear
y poblar la base de datos animal_training.db.
"""

from initialize_animal_hierarchy import initialize_database

if __name__ == "__main__":
    initialize_database()
