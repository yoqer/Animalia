# Manual Técnico: Sistema de Comunicación Animal Multilingüe

## Tabla de Contenidos

1. [Introducción](#introducción)
2. [Arquitectura del Sistema](#arquitectura-del-sistema)
3. [Jerarquía Taxonómica](#jerarquía-taxonómica)
4. [Pipeline de Traducción Multilingüe](#pipeline-de-traducción-multilingüe)
5. [Base de Datos Relacional](#base-de-datos-relacional)
6. [Inicialización y Uso](#inicialización-y-uso)
7. [Reentrenamiento y RL](#reentrenamiento-y-rl)
8. [Ejemplos de Uso](#ejemplos-de-uso)

---

## Introducción

El **Sistema de Comunicación Animal Multilingüe** es una arquitectura avanzada diseñada para:

- **Capturar y analizar** comportamientos y sonidos de animales
- **Traducir** expresiones animales a múltiples idiomas humanos
- **Generar corpus de entrenamiento** para reentrenamiento de LLMs
- **Crear relaciones semánticas** entre especies
- **Implementar reentrenamiento distribuido** por especie

### Características Clave

✅ **Jerarquía Taxonómica Flexible**: Permite añadir nuevas especies sin afectar las existentes

✅ **Multilingüismo Completo**: Español como base, extensible a cualquier idioma/dialecto

✅ **Lenguajes Animales Específicos**: Cada especie tiene sus propias expresiones

✅ **Restricciones de Datos**: Evita mezcla de datos incompatibles (ej. gallinas no comen chocolate)

✅ **Reentrenamiento Distribuido**: Agentes independientes por especie

✅ **Texto Plano para RL**: Generación automática de corpus de entrenamiento

---

## Arquitectura del Sistema

### Componentes Principales

```
┌─────────────────────────────────────────────────────────────┐
│         SISTEMA DE COMUNICACIÓN ANIMAL MULTILINGÜE          │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ┌──────────────────┐  ┌──────────────────┐               │
│  │  Captura de      │  │  Análisis de     │               │
│  │  Datos Multimodal│  │  Comportamiento  │               │
│  │  (Evento-Basada) │  │  (Lightmem)      │               │
│  └────────┬─────────┘  └────────┬─────────┘               │
│           │                     │                         │
│           └─────────────┬───────┘                         │
│                         │                                 │
│           ┌─────────────▼─────────────┐                  │
│           │  Jerarquía Taxonómica     │                  │
│           │  (animal_hierarchy.py)    │                  │
│           └─────────────┬─────────────┘                  │
│                         │                                 │
│           ┌─────────────▼─────────────┐                  │
│           │  Pipeline Multilingüe     │                  │
│           │  (multilingual_           │                  │
│           │   translation_pipeline.py)│                  │
│           └─────────────┬─────────────┘                  │
│                         │                                 │
│           ┌─────────────▼─────────────┐                  │
│           │  Base de Datos Relacional │                  │
│           │  (db_animal_training_     │                  │
│           │   schema.py)              │                  │
│           └─────────────┬─────────────┘                  │
│                         │                                 │
│           ┌─────────────▼─────────────┐                  │
│           │  Corpus de Entrenamiento  │                  │
│           │  (Texto Plano para RL)    │                  │
│           └─────────────────────────────┘                  │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Flujo de Datos

```
1. CAPTURA (Evento-Basada)
   ├── Cámara de movimiento → Video 5 min
   ├── Micrófono de sonido → Audio + timestamp
   ├── Cámara periódica → Fotos a horas específicas
   └── Entrada manual → Datos del usuario

2. ANÁLISIS (Lightmem)
   ├── Memoria Sensorial → Filtrado de redundancia
   ├── STM Topic-Aware → Agrupación por tema
   └── LTM Sleep-Time → Consolidación

3. JERARQUÍA TAXONÓMICA
   ├── Identificar especie
   ├── Recuperar patrones generalizados
   └── Aplicar restricciones específicas

4. TRADUCCIÓN MULTILINGÜE
   ├── Idiomas humanos (español, inglés, francés, etc.)
   ├── Lenguajes animales (ladrido, maullido, gorjeo, etc.)
   └── Contexto vectorial escalado

5. ALMACENAMIENTO
   ├── BD relacional (SQLite)
   ├── Corpus de entrenamiento
   └── Vectores de contexto

6. REENTRENAMIENTO RL
   ├── Agentes especializados por especie
   ├── Aprendizaje distribuido
   └── Actualización continua
```

---

## Jerarquía Taxonómica

### Estructura de Clases

```
AnimalGeneral (Clase Padre)
│
├── Aves
│   ├── Pájaros
│   │   ├── Canario (Serinus canaria)
│   │   └── Gorrión (Passer domesticus)
│   └── Gallinas
│       ├── Gallina Roja
│       └── Gallina Blanca
│
├── Mamíferos
│   ├── Carnívoros
│   │   ├── Felinos
│   │   │   ├── Gatos
│   │   │   │   ├── Gato Doméstico
│   │   │   │   └── Gato Siamés
│   │   │   └── Leones, Tigres
│   │   └── Caninos
│   │       ├── Perros
│   │       │   ├── Labrador
│   │       │   └── Pastor Alemán
│   │       └── Lobos, Zorros
│   │
│   ├── Herbívoros
│   │   ├── Équidos
│   │   │   ├── Caballos
│   │   │   │   ├── Caballo de Silla
│   │   │   │   └── Caballo de Tiro
│   │   │   └── Ponis
│   │   │       └── Poni Shetland
│   │   ├── Bovinos
│   │   └── Ovinos
│   │
│   ├── Omnívoros
│   │   ├── Primates
│   │   └── Osos
│   │
│   └── Cetáceos
│       ├── Delfines
│       │   └── Delfín Mular (Tursiops truncatus)
│       └── Ballenas
│
├── Reptiles
│   ├── Escamosos
│   ├── Quelonios
│   └── Cocodrilos
│
├── Anfibios
│   ├── Anuros (Ranas, Sapos)
│   ├── Caudados (Salamandras)
│   └── Ápodos (Cecilias)
│
├── Peces
│   ├── Agua Dulce
│   ├── Agua Salada
│   └── Migratorios
│
└── Artrópodos
    ├── Insectos
    ├── Aracnidos
    └── Crustáceos
```

### Características de Cada Clase

Cada clase hereda de su padre y añade:

- **Patrones de comunicación**: Vocalizaciones específicas
- **Restricciones de datos**: Alimentos prohibidos, hábitats
- **Relaciones con otras especies**: Depredador-presa, simbiosis
- **Contexto en español**: Descripción del comportamiento
- **Vectorización**: Representación numérica para RL

---

## Pipeline de Traducción Multilingüe

### Idiomas Humanos Soportados

| Idioma | Código | Ejemplos |
| :--- | :--- | :--- |
| Español | `spanish` | "hambre", "miedo", "alegría" |
| Inglés | `english` | "hunger", "fear", "joy" |
| Francés | `french` | "faim", "peur", "joie" |
| Chino | `chinese` | "饥饿", "恐惧", "喜悦" |
| Coreano | `korean` | "배고픔", "두려움", "기쁨" |
| Tibetano | `tibetan` | "རྐྱེན་པ", "འཇིགས་སྐུལ", "དགའ་བ" |
| Mongol | `mongolian` | "өлөө", "айдас", "баяр" |
| Ruso | `russian` | "голод", "страх", "радость" |
| Árabe | `arabic` | "جوع", "خوف", "فرح" |
| Japonés | `japanese` | "飢え", "恐怖", "喜び" |
| Portugués | `portuguese` | "fome", "medo", "alegria" |
| Alemán | `german` | "Hunger", "Angst", "Freude" |

### Lenguajes Animales Soportados

| Lenguaje | Especie | Ejemplos |
| :--- | :--- | :--- |
| `bark` | Perros, Lobos | ladrido_agudo, ladrido_grave, ladrido_juguetón |
| `meow` | Gatos | maullido_demanda, maullido_afectuoso, ronroneo |
| `chirp` | Pájaros | gorjeo_rápido, canto_melodioso, canto_territorial |
| `cackle` | Gallinas | cacareo_agudo, cacareo_territorial, cacareo_contento |
| `whistle` | Delfines | silbido_social, silbido_identificación, silbido_alerta |
| `neigh` | Caballos | relincho_demanda, relincho_alerta, relincho_grupal |
| `craw` | Cuervos | graznido_territorial, graznido_alerta |
| `quack` | Patos | graznido_demanda, graznido_territorial |
| `buzz` | Abejas | zumbido_alerta, zumbido_recolección |
| `croak` | Ranas | croar_territorial, croar_apareamiento |
| `hoot` | Búhos | ululato_territorial, ululato_comunicación |
| `moan` | Ballenas | gemido_largo, gemido_comunicación |
| `click` | Delfines | click_ecolocalización, click_comunicación |

### Contextos Comportamentales

Cada expresión se mapea a un contexto en español:

```python
{
    "hunger": "El animal expresa hambre mediante vocalizaciones insistentes y comportamiento de búsqueda de alimento",
    "thirst": "El animal expresa sed mediante vocalizaciones cortas y repetidas, buscando fuentes de agua",
    "fear": "El animal expresa miedo mediante vocalizaciones defensivas, posturas de sumisión y huida",
    "joy": "El animal expresa alegría mediante vocalizaciones alegres, movimientos rápidos y comportamiento de juego",
    "territoriality": "El animal expresa territorialidad mediante vocalizaciones graves, marcaje y comportamiento defensivo",
    "mating": "El animal expresa deseo de apareamiento mediante vocalizaciones complejas y comportamientos de cortejo",
    "alert": "El animal expresa alerta mediante vocalizaciones rápidas y comportamiento vigilante",
    "pain": "El animal expresa dolor mediante vocalizaciones de angustia y comportamiento de protección",
    "comfort": "El animal expresa comodidad mediante vocalizaciones suaves y comportamiento relajado",
    "social_bonding": "El animal expresa vinculación social mediante vocalizaciones suaves y comportamiento de proximidad"
}
```

---

## Base de Datos Relacional

### Tablas Principales

#### `animal_species`
Almacena información sobre especies animales.

```sql
CREATE TABLE animal_species (
    species_id TEXT PRIMARY KEY,
    species_name TEXT NOT NULL UNIQUE,
    scientific_name TEXT,
    common_names TEXT,  -- JSON list
    temperature_type TEXT,  -- "warm_blooded" or "cold_blooded"
    diet_type TEXT,  -- "herbivore", "carnivore", "omnivore"
    spanish_context TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### `animal_hierarchy`
Almacena relaciones jerárquicas entre especies.

```sql
CREATE TABLE animal_hierarchy (
    hierarchy_id TEXT PRIMARY KEY,
    parent_species_id TEXT,
    child_species_id TEXT,
    hierarchy_level TEXT,  -- "kingdom", "phylum", "class", "order", "family", "genus", "species"
    relation_type TEXT,  -- "generalization", "specialization"
    inheritance_weight REAL,  -- Peso de herencia (0-1)
    FOREIGN KEY (parent_species_id) REFERENCES animal_species(species_id),
    FOREIGN KEY (child_species_id) REFERENCES animal_species(species_id)
);
```

#### `communication_patterns`
Almacena patrones de comunicación generalizados.

```sql
CREATE TABLE communication_patterns (
    pattern_id TEXT PRIMARY KEY,
    pattern_name TEXT NOT NULL,
    description TEXT,
    universal_species TEXT,  -- JSON list
    communication_types TEXT,  -- JSON list
    spanish_context TEXT,
    confidence_score REAL
);
```

#### `training_texts`
Almacena textos de entrenamiento generados.

```sql
CREATE TABLE training_texts (
    text_id TEXT PRIMARY KEY,
    animal_species_id TEXT NOT NULL,
    behavior_description TEXT,
    spanish_context TEXT,
    vector_representation BLOB,
    ready_for_rl BOOLEAN DEFAULT 0,
    raw_text TEXT,
    FOREIGN KEY (animal_species_id) REFERENCES animal_species(species_id)
);
```

#### `multilingual_expressions`
Almacena expresiones en idiomas humanos.

```sql
CREATE TABLE multilingual_expressions (
    expression_id TEXT PRIMARY KEY,
    training_text_id TEXT NOT NULL,
    original_expression TEXT,
    language TEXT,  -- "spanish", "english", "french", etc.
    translated_expression TEXT,
    confidence REAL,
    FOREIGN KEY (training_text_id) REFERENCES training_texts(text_id)
);
```

#### `animal_language_expressions`
Almacena expresiones en lenguajes animales.

```sql
CREATE TABLE animal_language_expressions (
    expression_id TEXT PRIMARY KEY,
    training_text_id TEXT NOT NULL,
    animal_species_id TEXT NOT NULL,
    animal_language TEXT,  -- "bark", "meow", "chirp", etc.
    animal_expression TEXT,
    confidence REAL,
    FOREIGN KEY (training_text_id) REFERENCES training_texts(text_id),
    FOREIGN KEY (animal_species_id) REFERENCES animal_species(species_id)
);
```

#### `training_corpus`
Almacena corpus de entrenamiento para RL.

```sql
CREATE TABLE training_corpus (
    corpus_id TEXT PRIMARY KEY,
    animal_species_id TEXT NOT NULL,
    corpus_text TEXT,
    language TEXT,
    animal_language TEXT,
    vector_representation BLOB,
    ready_for_training BOOLEAN DEFAULT 0,
    training_iterations INTEGER DEFAULT 0,
    FOREIGN KEY (animal_species_id) REFERENCES animal_species(species_id)
);
```

---

## Inicialización y Uso

### Paso 1: Instalación de Dependencias

```bash
pip install -r requirements_vision.txt
```

### Paso 2: Inicializar el Sistema

```bash
python initialize_animal_hierarchy.py
```

Esto creará:
- Base de datos SQLite (`animal_training.db`)
- Especies populares (Pájaros, Gallinas, Perros, Gatos, Caballos, Ponis, Delfines)
- Patrones de comunicación
- Textos de entrenamiento
- Corpus multilingüe

### Paso 3: Usar el Sistema

```python
from animal_hierarchy import AnimalHierarchyManager, Perros
from multilingual_translation_pipeline import MultilingualTranslator, TranslationContext

# Crear gestor
manager = AnimalHierarchyManager()

# Crear un perro
perro = Perros(breed="Labrador")
manager.register_animal(perro)

# Crear traductor
translator = MultilingualTranslator()

# Crear contexto
context = TranslationContext(
    original_language="spanish",
    target_languages=["english", "french", "chinese"],
    animal_species="Canis familiaris",
    behavior_description="hambre",
    spanish_context="El perro expresa hambre mediante ladridos insistentes"
)

# Generar texto de entrenamiento
training_text = translator.generate_training_text(context)

print(training_text.raw_text)
```

---

## Reentrenamiento y RL

### Flujo de Reentrenamiento

```
1. RECOLECCIÓN DE DATOS
   └── Captura multimodal (evento-basada)

2. ANÁLISIS (Lightmem)
   └── Filtrado, agrupación, consolidación

3. GENERACIÓN DE CORPUS
   └── Texto plano para LLM

4. REENTRENAMIENTO DISTRIBUIDO
   ├── Agente de Pájaros
   ├── Agente de Mamíferos
   ├── Agente de Reptiles
   └── Agente de Otros

5. ACTUALIZACIÓN DE VECTORES
   └── Mejora de representaciones contextuales

6. VALIDACIÓN
   └── Prueba con nuevos datos
```

### Ejemplo de Reentrenamiento

```python
from db_animal_training_schema import AnimalTrainingDatabase

# Conectar a BD
db = AnimalTrainingDatabase("animal_training.db")

# Obtener corpus de entrenamiento
corpus = db.get_training_corpus_by_species("canis_familiaris")

# Usar corpus para reentrenamiento
for item in corpus:
    print(f"Corpus ID: {item['corpus_id']}")
    print(f"Texto: {item['corpus_text'][:100]}...")
    print(f"Lenguaje: {item['language']}")
    
    # Aquí se implementaría el reentrenamiento con LLM
    # llm.train(item['corpus_text'], language=item['language'])

db.close()
```

---

## Ejemplos de Uso

### Ejemplo 1: Traducir Expresión Animal

```python
from multilingual_translation_pipeline import MultilingualTranslator

translator = MultilingualTranslator()

# Traducir "hambre" a múltiples idiomas
translations = translator.translate_expression(
    expression="hunger",
    source_language="english",
    target_languages=["spanish", "french", "chinese", "korean"],
    animal_species="Canis familiaris"
)

for lang, trans in translations.items():
    print(f"{lang}: {trans.translated_expression}")
```

### Ejemplo 2: Generar Corpus de Entrenamiento

```python
from animal_hierarchy import Gatos
from multilingual_translation_pipeline import MultilingualTranslator

# Crear gato
gato = Gatos(breed="Siamés")

# Generar texto de entrenamiento
training_text = gato.get_training_text(language="spanish")

print(training_text)
```

### Ejemplo 3: Consultar BD

```python
from db_animal_training_schema import AnimalTrainingDatabase

db = AnimalTrainingDatabase("animal_training.db")

# Obtener todos los textos de entrenamiento
all_texts = db.get_all_training_texts()

for text in all_texts:
    print(f"Especie: {text['species_id']}")
    print(f"Comportamiento: {text['behavior']}")
    print(f"Contexto: {text['spanish_context']}\n")

db.close()
```

---

## Conclusión

El **Sistema de Comunicación Animal Multilingüe** proporciona una arquitectura robusta para:

- Capturar y analizar comportamientos animales
- Traducir expresiones a múltiples idiomas
- Generar corpus de entrenamiento para LLMs
- Implementar reentrenamiento distribuido

Este sistema es extensible y puede adaptarse a nuevas especies, idiomas y contextos según sea necesario.


