"""
Módulo Avanzado de Análisis de Video

Implementa:
- Conteo y seguimiento de objetos
- Demarcación y segmentación
- Agrupación de expresividad
- Relaciones semánticas complejas
"""

import numpy as np
import logging
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass
from collections import defaultdict
import hashlib

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# ==================== DATACLASSES ====================

@dataclass
class ObjectTrack:
    """Seguimiento de un objeto a lo largo del video."""
    track_id: str
    class_name: str
    first_frame: int
    last_frame: int
    frame_count: int
    positions: List[Tuple[int, int, int, int]]  # Bounding boxes
    confidence_scores: List[float]
    average_confidence: float
    
@dataclass
class ExpressionCluster:
    """Agrupación de expresiones relacionadas."""
    cluster_id: str
    expression_type: str  # "euforia", "miedo", "curiosidad", etc.
    component_emotions: List[str]  # ["alegría", "energía", "movimiento"]
    component_actions: List[str]  # ["volar", "silbar", "explorar"]
    confidence: float
    frame_range: Tuple[int, int]
    description: str

@dataclass
class SemanticNetwork:
    """Red de relaciones semánticas entre objetos."""
    network_id: str
    nodes: Dict[str, Dict]  # object_id -> {type, name, properties}
    edges: List[Dict]  # {source, target, relation_type, confidence}
    central_concept: str  # El concepto central de la red
    complexity_score: float  # 0.0 a 1.0

# ==================== ANALIZADOR AVANZADO ====================

class AdvancedAnalyzer:
    """Analizador avanzado con conteo, demarcación y expresividad."""
    
    def __init__(self):
        """Inicializa el analizador avanzado."""
        self.object_tracks = {}  # track_id -> ObjectTrack
        self.expression_clusters = {}
        self.semantic_networks = {}
        
        # Diccionarios de expresividad agrupada
        self.expressivity_groups = self._init_expressivity_groups()
        
        logger.info("AdvancedAnalyzer initialized")
    
    def _init_expressivity_groups(self) -> Dict[str, Dict]:
        """Inicializa agrupaciones de expresividad."""
        return {
            "euforia": {
                "emotions": ["joy", "excitement", "enthusiasm"],
                "actions": ["flying", "vocalizing", "exploring", "playing"],
                "visual_cues": ["rapid_movement", "alert_posture", "bright_colors"],
                "description": "Estado de máxima alegría y energía"
            },
            "miedo": {
                "emotions": ["fear", "anxiety", "stress"],
                "actions": ["fleeing", "hiding", "freezing", "defensive"],
                "visual_cues": ["dilated_pupils", "ears_back", "trembling"],
                "description": "Estado de pánico o amenaza percibida"
            },
            "curiosidad": {
                "emotions": ["interest", "exploration", "investigation"],
                "actions": ["approaching", "sniffing", "investigating", "climbing"],
                "visual_cues": ["alert_posture", "focused_attention", "slow_movement"],
                "description": "Interés en explorar algo nuevo"
            },
            "tranquilidad": {
                "emotions": ["calm", "contentment", "relaxation"],
                "actions": ["resting", "grooming", "sleeping", "eating_slowly"],
                "visual_cues": ["relaxed_posture", "closed_eyes", "slow_movement"],
                "description": "Estado de paz y descanso"
            },
            "hambre_urgente": {
                "emotions": ["desperation", "urgency", "frustration"],
                "actions": ["foraging_intensely", "hunting", "begging", "searching"],
                "visual_cues": ["visible_ribs", "rapid_movement", "focused_search"],
                "description": "Necesidad crítica de alimento"
            },
            "sed_urgente": {
                "emotions": ["desperation", "lethargy", "distress"],
                "actions": ["approaching_water", "drinking", "panting", "reduced_activity"],
                "visual_cues": ["dry_mouth", "sunken_eyes", "slow_movement"],
                "description": "Necesidad crítica de agua"
            },
            "juego_social": {
                "emotions": ["joy", "affection", "playfulness"],
                "actions": ["chasing", "wrestling", "grooming_other", "following"],
                "visual_cues": ["relaxed_posture", "tail_wagging", "synchronized_movement"],
                "description": "Interacción social positiva"
            },
            "cuidado_parental": {
                "emotions": ["protectiveness", "nurturing", "vigilance"],
                "actions": ["feeding_young", "protecting", "teaching", "grooming_young"],
                "visual_cues": ["close_proximity_to_young", "alert_posture", "gentle_movement"],
                "description": "Comportamiento de cuidado de crías"
            }
        }
    
    def count_objects(self, frame_analyses: List[Dict]) -> Dict[str, int]:
        """
        Cuenta la cantidad de cada tipo de objeto en el video.
        
        Args:
            frame_analyses: Lista de análisis de frames
            
        Returns:
            Diccionario con conteos por clase
        """
        counts = defaultdict(int)
        
        for analysis in frame_analyses:
            for obj in analysis.get("detected_objects", []):
                counts[obj.class_name] += 1
        
        return dict(counts)
    
    def track_objects(self, frame_analyses: List[Dict]) -> Dict[str, ObjectTrack]:
        """
        Rastrea objetos a lo largo del video.
        
        Args:
            frame_analyses: Lista de análisis de frames
            
        Returns:
            Diccionario de tracks (track_id -> ObjectTrack)
        """
        tracks = {}
        object_id_to_track = {}  # Mapeo de object_id a track_id
        
        for analysis in frame_analyses:
            frame_num = analysis.get("frame_number", 0)
            
            for obj in analysis.get("detected_objects", []):
                obj_id = obj.object_id
                
                # Determinar si es un objeto nuevo o uno existente
                if obj_id in object_id_to_track:
                    track_id = object_id_to_track[obj_id]
                    track = tracks[track_id]
                    track.last_frame = frame_num
                    track.frame_count += 1
                    track.positions.append(obj.bbox)
                    track.confidence_scores.append(obj.confidence)
                else:
                    # Crear nuevo track
                    track_id = hashlib.md5(f"{obj_id}{frame_num}".encode()).hexdigest()
                    track = ObjectTrack(
                        track_id=track_id,
                        class_name=obj.class_name,
                        first_frame=frame_num,
                        last_frame=frame_num,
                        frame_count=1,
                        positions=[obj.bbox],
                        confidence_scores=[obj.confidence],
                        average_confidence=obj.confidence
                    )
                    tracks[track_id] = track
                    object_id_to_track[obj_id] = track_id
        
        # Calcular confianza promedio
        for track in tracks.values():
            track.average_confidence = np.mean(track.confidence_scores)
        
        return tracks
    
    def demarcate_objects(self, frame_analyses: List[Dict]) -> Dict[str, List[Dict]]:
        """
        Demarca objetos con bounding boxes y máscaras.
        
        Args:
            frame_analyses: Lista de análisis de frames
            
        Returns:
            Diccionario con demarcaciones por frame
        """
        demarcations = defaultdict(list)
        
        for analysis in frame_analyses:
            frame_num = analysis.get("frame_number", 0)
            
            for obj in analysis.get("detected_objects", []):
                demarcation = {
                    "object_id": obj.object_id,
                    "class_name": obj.class_name,
                    "confidence": obj.confidence,
                    "bbox": obj.bbox,
                    "bbox_format": "x1,y1,x2,y2",
                    "segmentation_mask": obj.segmentation_mask is not None,
                    "color_histogram": obj.color_histogram
                }
                demarcations[f"frame_{frame_num}"].append(demarcation)
        
        return dict(demarcations)
    
    def cluster_expressivity(self, frame_analyses: List[Dict]) -> Dict[str, ExpressionCluster]:
        """
        Agrupa expresiones similares en clusters.
        
        Args:
            frame_analyses: Lista de análisis de frames
            
        Returns:
            Diccionario de clusters de expresividad
        """
        clusters = {}
        
        # Agrupar por tipo de expresión
        expression_frames = defaultdict(list)
        
        for analysis in frame_analyses:
            frame_num = analysis.get("frame_number", 0)
            
            for animal in analysis.get("animal_contexts", []):
                # Determinar tipo de expresión basado en emociones y acciones
                expr_type = self._determine_expression_type(
                    animal.emotional_state,
                    animal.detected_actions,
                    animal.detected_needs
                )
                
                expression_frames[expr_type].append({
                    "frame": frame_num,
                    "animal": animal,
                    "confidence": animal.confidence_score
                })
        
        # Crear clusters
        for expr_type, frames in expression_frames.items():
            if frames:
                cluster_id = hashlib.md5(f"{expr_type}{len(frames)}".encode()).hexdigest()
                
                frame_nums = [f["frame"] for f in frames]
                frame_range = (min(frame_nums), max(frame_nums))
                
                # Obtener componentes del grupo de expresividad
                expr_group = self.expressivity_groups.get(expr_type, {})
                
                cluster = ExpressionCluster(
                    cluster_id=cluster_id,
                    expression_type=expr_type,
                    component_emotions=expr_group.get("emotions", []),
                    component_actions=expr_group.get("actions", []),
                    confidence=np.mean([f["confidence"] for f in frames]),
                    frame_range=frame_range,
                    description=expr_group.get("description", "")
                )
                
                clusters[cluster_id] = cluster
        
        return clusters
    
    def extract_semantic_networks(self, frame_analyses: List[Dict]) -> Dict[str, SemanticNetwork]:
        """
        Extrae redes de relaciones semánticas complejas.
        
        Args:
            frame_analyses: Lista de análisis de frames
            
        Returns:
            Diccionario de redes semánticas
        """
        networks = {}
        
        # Agrupar por video completo
        all_objects = {}
        all_relations = []
        
        for analysis in frame_analyses:
            for obj in analysis.get("detected_objects", []):
                all_objects[obj.object_id] = {
                    "type": obj.category.value,
                    "name": obj.class_name,
                    "confidence": obj.confidence
                }
            
            for rel in analysis.get("semantic_relations", []):
                all_relations.append({
                    "source": rel.object_a_id,
                    "target": rel.object_b_id,
                    "relation_type": rel.relation_type,
                    "confidence": rel.confidence
                })
        
        # Crear red semántica
        if all_objects and all_relations:
            network_id = hashlib.md5(f"{len(all_objects)}{len(all_relations)}".encode()).hexdigest()
            
            # Determinar concepto central (objeto más conectado)
            connection_count = defaultdict(int)
            for rel in all_relations:
                connection_count[rel["source"]] += 1
                connection_count[rel["target"]] += 1
            
            central_concept = max(connection_count, key=connection_count.get) if connection_count else "unknown"
            
            # Calcular complejidad
            complexity = len(all_relations) / max(len(all_objects), 1)
            
            network = SemanticNetwork(
                network_id=network_id,
                nodes=all_objects,
                edges=all_relations,
                central_concept=central_concept,
                complexity_score=min(complexity, 1.0)
            )
            
            networks[network_id] = network
        
        return networks
    
    def _determine_expression_type(self, emotional_state: str,
                                   actions: List, needs: List) -> str:
        """
        Determina el tipo de expresión basado en emociones, acciones y necesidades.
        """
        # Lógica de mapeo
        if emotional_state == "eufórico" and "flying" in [a.value for a in actions]:
            return "euforia"
        elif emotional_state == "asustado":
            return "miedo"
        elif "exploration" in [a.value for a in actions]:
            return "curiosidad"
        elif emotional_state == "tranquilo":
            return "tranquilidad"
        elif "thirst" in [n.value for n in needs]:
            return "sed_urgente"
        elif "hunger" in [n.value for n in needs]:
            return "hambre_urgente"
        elif "social" in [n.value for n in needs]:
            return "juego_social"
        else:
            return "neutral"
    
    def generate_analysis_report(self, frame_analyses: List[Dict]) -> Dict:
        """
        Genera un reporte completo de análisis avanzado.
        
        Args:
            frame_analyses: Lista de análisis de frames
            
        Returns:
            Diccionario con reporte completo
        """
        report = {
            "object_counts": self.count_objects(frame_analyses),
            "object_tracks": self.track_objects(frame_analyses),
            "demarcations": self.demarcate_objects(frame_analyses),
            "expression_clusters": self.cluster_expressivity(frame_analyses),
            "semantic_networks": self.extract_semantic_networks(frame_analyses),
            "summary": {
                "total_unique_objects": len(self.count_objects(frame_analyses)),
                "total_tracks": len(self.track_objects(frame_analyses)),
                "expression_types_detected": list(self.cluster_expressivity(frame_analyses).keys()),
                "semantic_complexity": "high" if self.extract_semantic_networks(frame_analyses) else "low"
            }
        }
        
        return report


