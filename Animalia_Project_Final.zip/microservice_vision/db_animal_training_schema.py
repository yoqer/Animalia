"""
Esquema de Base de Datos para Reentrenamiento Multilingüe

Tablas:
- animal_species: Especies animales
- animal_hierarchy: Jerarquía taxonómica
- communication_patterns: Patrones de comunicación
- training_texts: Textos de entrenamiento
- multilingual_expressions: Expresiones multilingües
- animal_language_expressions: Expresiones en lenguajes animales
- species_relations: Relaciones entre especies
- vector_representations: Representaciones vectoriales
- training_corpus: Corpus de entrenamiento para RL
- animal_restrictions: Restricciones de datos
- animal_individuals: Individuos/grupos de animales
"""

import sqlite3
import logging
import json
from typing import Optional, List, Dict
from datetime import datetime

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class AnimalTrainingDatabase:
    """Gestor de base de datos para reentrenamiento animal."""
    
    def __init__(self, db_path: str = "animal_training.db"):
        """Inicializa la conexión a la BD."""
        self.db_path = db_path
        self.connection = None
        self.cursor = None
        
        self.connect()
        self.create_schema()
        
        logger.info(f"AnimalTrainingDatabase initialized at {db_path}")
    
    def connect(self):
        """Conecta a la BD."""
        self.connection = sqlite3.connect(self.db_path)
        self.cursor = self.connection.cursor()
    
    def create_schema(self):
        """Crea el esquema de la BD."""
        
        # Tabla de especies animales
        self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS animal_species (
                species_id TEXT PRIMARY KEY,
                species_name TEXT NOT NULL UNIQUE,
                scientific_name TEXT,
                common_names TEXT,  -- JSON list
                temperature_type TEXT,  -- "warm_blooded" or "cold_blooded"
                diet_type TEXT,  -- "herbivore", "carnivore", "omnivore", etc.
                spanish_context TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # Tabla de jerarquía taxonómica
        self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS animal_hierarchy (
                hierarchy_id TEXT PRIMARY KEY,
                parent_species_id TEXT,
                child_species_id TEXT,
                hierarchy_level TEXT,  -- "kingdom", "phylum", "class", "order", "family", "genus", "species"
                relation_type TEXT,  -- "generalization", "specialization"
                inheritance_weight REAL,  -- Peso de herencia (0-1)
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (parent_species_id) REFERENCES animal_species(species_id),
                FOREIGN KEY (child_species_id) REFERENCES animal_species(species_id)
            )
        """)
        
        # Tabla de patrones de comunicación
        self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS communication_patterns (
                pattern_id TEXT PRIMARY KEY,
                pattern_name TEXT NOT NULL,
                description TEXT,
                universal_species TEXT,  -- JSON list
                communication_types TEXT,  -- JSON list
                spanish_context TEXT,
                confidence_score REAL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # Tabla de textos de entrenamiento
        self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS training_texts (
                text_id TEXT PRIMARY KEY,
                animal_species_id TEXT NOT NULL,
                behavior_description TEXT,
                spanish_context TEXT,
                vector_representation BLOB,  -- Representación vectorial serializada
                ready_for_rl BOOLEAN DEFAULT 0,
                raw_text TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (animal_species_id) REFERENCES animal_species(species_id)
            )
        """)
        
        # Tabla de expresiones multilingües (idiomas humanos)
        self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS multilingual_expressions (
                expression_id TEXT PRIMARY KEY,
                training_text_id TEXT NOT NULL,
                original_expression TEXT,
                language TEXT,  -- "spanish", "english", "french", "chinese", "korean", "tibetan", "mongolian", etc.
                translated_expression TEXT,
                confidence REAL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (training_text_id) REFERENCES training_texts(text_id)
            )
        """)
        
        # Tabla de expresiones en lenguajes animales
        self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS animal_language_expressions (
                expression_id TEXT PRIMARY KEY,
                training_text_id TEXT NOT NULL,
                animal_species_id TEXT NOT NULL,
                animal_language TEXT,  -- "bark", "meow", "chirp", "cackle", "whistle", "neigh", etc.
                animal_expression TEXT,
                confidence REAL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (training_text_id) REFERENCES training_texts(text_id),
                FOREIGN KEY (animal_species_id) REFERENCES animal_species(species_id)
            )
        """)
        
        # Tabla de relaciones entre especies (incluye híbridos y relaciones complejas)
        self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS species_relations (
                relation_id TEXT PRIMARY KEY,
                species_a_id TEXT NOT NULL,
                species_b_id TEXT NOT NULL,
                relation_type TEXT,  -- "predator_prey", "symbiotic", "competitive", "communication", "hybrid_offspring", "behavioral_similitude"
                description TEXT,
                confidence REAL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (species_a_id) REFERENCES animal_species(species_id),
                FOREIGN KEY (species_b_id) REFERENCES animal_species(species_id)
            )
        """)
        
        # Tabla de representaciones vectoriales
        self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS vector_representations (
                vector_id TEXT PRIMARY KEY,
                entity_type TEXT,  -- "species", "behavior", "communication_pattern"
                entity_id TEXT,
                vector_data BLOB,  -- Serializado (numpy array)
                vector_dimension INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # Tabla de corpus de entrenamiento para RL
        self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS training_corpus (
                corpus_id TEXT PRIMARY KEY,
                animal_species_id TEXT NOT NULL,
                corpus_text TEXT,  -- Texto plano para RL
                language TEXT,  -- Idioma del corpus
                animal_language TEXT,  -- Lenguaje animal (opcional)
                vector_representation BLOB,
                ready_for_training BOOLEAN DEFAULT 0,
                training_iterations INTEGER DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (animal_species_id) REFERENCES animal_species(species_id)
            )
        """)
        
        # Tabla de restricciones de datos
        self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS animal_restrictions (
                restriction_id TEXT PRIMARY KEY,
                animal_species_id TEXT NOT NULL,
                restriction_type TEXT,  -- "diet", "habitat", "behavior", "compatibility"
                description TEXT,
                forbidden_items TEXT,  -- JSON list
                allowed_items TEXT,  -- JSON list
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (animal_species_id) REFERENCES animal_species(species_id)
            )
        """)
        
        # Tabla de individuos/grupos de animales
        self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS animal_individuals (
                individual_id TEXT PRIMARY KEY,
                animal_species_id TEXT NOT NULL,
                individual_name TEXT,
                group_id TEXT,  -- Para animales en grupos
                age_months INTEGER,
                characteristics TEXT,  -- JSON
                training_data TEXT,  -- JSON con datos de reentrenamiento específicos
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (animal_species_id) REFERENCES animal_species(species_id)
            )
        """)
        
        # Tabla de análisis de expresividad de video (Gestos y Movimientos)
        self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS video_expressivity_analysis (
                id TEXT PRIMARY KEY,
                session_id TEXT NOT NULL,
                user_id TEXT NOT NULL,
                video_url TEXT,
                facial_expression TEXT,  -- happy, sad, angry, neutral, etc.
                head_movement TEXT,  -- nod, shake, tilt, still
                hand_gestures JSON,  -- (type, start_time, end_time)
                body_posture TEXT,  -- leaning_forward, relaxed, tense
                response_time_seconds REAL,  -- Tiempo de respuesta a la interacción
                inactivity_duration_seconds REAL, -- Duración de la inacción
                user_action TEXT, -- Acción tomada (ej. 'click_button', 'scroll', 'no_action')
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        self.connection.commit()
        logger.info("Database schema created successfully")
    
    def insert_animal_species(self, species_id: str, species_name: str,
                             scientific_name: str, common_names: List[str],
                             temperature_type: str, diet_type: str,
                             spanish_context: str):
        """Inserta una especie animal."""
        
        self.cursor.execute("""
            INSERT INTO animal_species 
            (species_id, species_name, scientific_name, common_names, 
             temperature_type, diet_type, spanish_context)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (species_id, species_name, scientific_name, json.dumps(common_names),
              temperature_type, diet_type, spanish_context))
        
        self.connection.commit()
        logger.info(f"Inserted species: {species_name}")
    
    def insert_hierarchy_relation(self, hierarchy_id: str, parent_species_id: str,
                                 child_species_id: str, hierarchy_level: str,
                                 relation_type: str, inheritance_weight: float):
        """Inserta una relación de jerarquía."""
        self.cursor.execute("""
            INSERT INTO animal_hierarchy 
            (hierarchy_id, parent_species_id, child_species_id, hierarchy_level,
             relation_type, inheritance_weight)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (hierarchy_id, parent_species_id, child_species_id, hierarchy_level,
              relation_type, inheritance_weight))
        
        self.connection.commit()
    
    def insert_training_text(self, text_id: str, animal_species_id: str,
                            behavior_description: str, spanish_context: str,
                            raw_text: str, ready_for_rl: bool = True):
        """Inserta un texto de entrenamiento."""
        self.cursor.execute("""
            INSERT INTO training_texts 
            (text_id, animal_species_id, behavior_description, spanish_context,
             raw_text, ready_for_rl)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (text_id, animal_species_id, behavior_description, spanish_context,
              raw_text, 1 if ready_for_rl else 0))
        
        self.connection.commit()
    
    def insert_multilingual_expression(self, expression_id: str, training_text_id: str,
                                      original_expression: str, language: str,
                                      translated_expression: str, confidence: float):
        """Inserta una expresión multilingüe."""
        self.cursor.execute("""
            INSERT INTO multilingual_expressions 
            (expression_id, training_text_id, original_expression, language,
             translated_expression, confidence)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (expression_id, training_text_id, original_expression, language,
              translated_expression, confidence))
        
        self.connection.commit()
    
    def insert_animal_language_expression(self, expression_id: str, training_text_id: str,
                                         animal_species_id: str, animal_language: str,
                                         animal_expression: str, confidence: float):
        """Inserta una expresión en lenguaje animal."""
        self.cursor.execute("""
            INSERT INTO animal_language_expressions 
            (expression_id, training_text_id, animal_species_id, animal_language,
             animal_expression, confidence)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (expression_id, training_text_id, animal_species_id, animal_language,
              animal_expression, confidence))
        
        self.connection.commit()
    
    def insert_training_corpus(self, corpus_id: str, animal_species_id: str,
                              corpus_text: str, language: str,
                              animal_language: Optional[str] = None,
                              ready_for_training: bool = True):
        """Inserta un corpus de entrenamiento."""
        self.cursor.execute("""
            INSERT INTO training_corpus 
            (corpus_id, animal_species_id, corpus_text, language, animal_language,
             ready_for_training)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (corpus_id, animal_species_id, corpus_text, language, animal_language,
              1 if ready_for_training else 0))
        
        self.connection.commit()
    
    def get_training_corpus_by_species(self, animal_species_id: str) -> List[Dict]:
        """Obtiene corpus de entrenamiento por especie."""
        self.cursor.execute("""
            SELECT corpus_id, corpus_text, language, animal_language
            FROM training_corpus
            WHERE animal_species_id = ? AND ready_for_training = 1
        """, (animal_species_id,))
        
        results = self.cursor.fetchall()
        return [{"corpus_id": r[0], "corpus_text": r[1], "language": r[2],
                "animal_language": r[3]} for r in results]
    
    def get_all_training_texts(self) -> List[Dict]:
        """Obtiene todos los textos de entrenamiento."""
        self.cursor.execute("""
            SELECT text_id, animal_species_id, behavior_description, spanish_context,
                   raw_text, ready_for_rl
            FROM training_texts
            WHERE ready_for_rl = 1
        """)
        
        results = self.cursor.fetchall()
        return [{"text_id": r[0], "species_id": r[1], "behavior": r[2],
                "spanish_context": r[3], "raw_text": r[4], "ready": r[5]}
                for r in results]
    
    def close(self):
        """Cierra la conexión a la BD."""
        if self.connection:
            self.connection.close()
            logger.info("Database connection closed")


