"""
API Flask - Microservicio de Análisis de Video Avanzado

Endpoints:
- POST /api/analyze/video: Analizar un video
- POST /api/analyze/frame: Analizar un frame
- GET /api/analysis/<analysis_id>: Obtener resultados de análisis
- GET /api/status: Estado del servicio
"""

from flask import Flask, request, jsonify
from flask_cors import CORS
import logging
import os
from datetime import datetime
import hashlib
import json

from vision_analyzer import AdvancedVideoAnalyzer, ObjectCategory
from db_vision_schema import initialize_vision_database

# Configuración
app = Flask(__name__)
CORS(app)

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Variables globales
analyzer = AdvancedVideoAnalyzer()
MCP_MASTER_TOKEN = os.getenv('MCP_MASTER_TOKEN', 'change_me_in_production')

# ==================== MIDDLEWARE ====================

@app.before_request
def check_auth():
    """Verifica el token de autenticación."""
    if request.method == 'OPTIONS':
        return
    
    # Permitir /api/status sin autenticación
    if request.path == '/api/status':
        return
    
    token = request.headers.get('X-Auth-Token')
    if not token or token != MCP_MASTER_TOKEN:
        return jsonify({"error": "Unauthorized"}), 401

# ==================== ENDPOINTS ====================

@app.route('/api/status', methods=['GET'])
def status():
    """Obtiene el estado del servicio."""
    return jsonify({
        "status": "operational",
        "service": "espejin_vision_service",
        "version": "1.0.0",
        "timestamp": datetime.utcnow().isoformat()
    }), 200

@app.route('/api/analyze/video', methods=['POST'])
def analyze_video():
    """
    Analiza un video completo.
    
    Request JSON:
    {
        "user_id": "user_123",
        "video_path": "/path/to/video.mp4",
        "sample_rate": 1
    }
    """
    try:
        data = request.get_json()
        
        user_id = data.get('user_id')
        video_path = data.get('video_path')
        sample_rate = data.get('sample_rate', 1)
        
        if not user_id or not video_path:
            return jsonify({"error": "Missing required fields"}), 400
        
        # Verificar que el archivo existe
        if not os.path.exists(video_path):
            return jsonify({"error": "Video file not found"}), 404
        
        logger.info(f"Starting video analysis: {video_path}")
        
        # Analizar video
        results = analyzer.analyze_video(video_path, sample_rate=sample_rate)
        
        # Generar ID de análisis
        analysis_id = hashlib.md5(f"{user_id}{video_path}{datetime.utcnow().isoformat()}".encode()).hexdigest()
        results['analysis_id'] = analysis_id
        results['user_id'] = user_id
        
        logger.info(f"Video analysis completed: {analysis_id}")
        
        return jsonify(results), 200
    
    except Exception as e:
        logger.error(f"Error analyzing video: {e}")
        return jsonify({"error": str(e)}), 500

@app.route('/api/analyze/frame', methods=['POST'])
def analyze_frame():
    """
    Analiza un frame individual.
    
    Request (multipart/form-data):
    - image: Archivo de imagen
    - frame_number: Número del frame (opcional)
    - timestamp_seconds: Timestamp en segundos (opcional)
    """
    try:
        if 'image' not in request.files:
            return jsonify({"error": "No image provided"}), 400
        
        image_file = request.files['image']
        frame_number = request.form.get('frame_number', 0, type=int)
        timestamp_seconds = request.form.get('timestamp_seconds', 0.0, type=float)
        
        # Guardar imagen temporalmente
        import tempfile
        import cv2
        import numpy as np
        
        with tempfile.NamedTemporaryFile(delete=False, suffix='.png') as tmp:
            image_file.save(tmp.name)
            frame = cv2.imread(tmp.name)
            
            if frame is None:
                return jsonify({"error": "Invalid image file"}), 400
            
            # Analizar frame
            results = analyzer.analyze_frame(frame, frame_number, timestamp_seconds)
            
            # Limpiar archivo temporal
            os.unlink(tmp.name)
        
        logger.info(f"Frame analysis completed: frame {frame_number}")
        
        return jsonify(results), 200
    
    except Exception as e:
        logger.error(f"Error analyzing frame: {e}")
        return jsonify({"error": str(e)}), 500

@app.route('/api/analysis/<analysis_id>', methods=['GET'])
def get_analysis(analysis_id):
    """
    Obtiene los resultados de un análisis previo.
    
    En producción, esto consultaría la BD.
    """
    try:
        # Placeholder: En producción, consultar BD
        return jsonify({
            "analysis_id": analysis_id,
            "status": "completed",
            "message": "Analysis results would be retrieved from database"
        }), 200
    
    except Exception as e:
        logger.error(f"Error retrieving analysis: {e}")
        return jsonify({"error": str(e)}), 500

@app.route('/api/animal-needs/<species>', methods=['GET'])
def get_animal_needs(species):
    """
    Obtiene los indicadores de necesidades para una especie animal.
    
    Útil para entrenar modelos de detección.
    """
    try:
        if species not in analyzer.animal_need_indicators:
            return jsonify({"error": f"Species {species} not found"}), 404
        
        indicators = analyzer.animal_need_indicators[species]
        
        return jsonify({
            "species": species,
            "need_indicators": {
                k: v for k, v in indicators.items()
            }
        }), 200
    
    except Exception as e:
        logger.error(f"Error retrieving animal needs: {e}")
        return jsonify({"error": str(e)}), 500

@app.route('/api/plant-states', methods=['GET'])
def get_plant_states():
    """
    Obtiene los indicadores de estados de plantas.
    """
    try:
        states = analyzer.plant_indicators
        
        return jsonify({
            "plant_states": {
                k.value: v for k, v in states.items()
            }
        }), 200
    
    except Exception as e:
        logger.error(f"Error retrieving plant states: {e}")
        return jsonify({"error": str(e)}), 500

@app.route('/api/action-patterns', methods=['GET'])
def get_action_patterns():
    """
    Obtiene los patrones de acciones detectables.
    """
    try:
        patterns = analyzer.action_patterns
        
        return jsonify({
            "action_patterns": {
                k.value: v for k, v in patterns.items()
            }
        }), 200
    
    except Exception as e:
        logger.error(f"Error retrieving action patterns: {e}")
        return jsonify({"error": str(e)}), 500

# ==================== INICIALIZACIÓN ====================

if __name__ == '__main__':
    # Inicializar BD
    db_path = os.getenv('VISION_DB_PATH', '/tmp/espejin_vision.db')
    initialize_vision_database(db_path)
    
    # Iniciar servidor
    port = int(os.getenv('VISION_SERVICE_PORT', 5001))
    app.run(host='0.0.0.0', port=port, debug=False)


