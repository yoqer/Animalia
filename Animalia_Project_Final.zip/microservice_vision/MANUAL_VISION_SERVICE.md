# Manual Técnico - Microservicio de Análisis de Video Avanzado (Espejín Vision Service)

## 1. Introducción

El **Espejín Vision Service** es un microservicio dedicado al análisis avanzado de video utilizando técnicas modernas de Visión por Computadora. Su propósito es:

1. **Detectar y contar objetos** en videos (animales, plantas, personas, objetos).
2. **Demarcación de objetos** con bounding boxes y máscaras de segmentación.
3. **Catalogación de acciones** (volar, caminar, comer, beber, vocalizar, etc.).
4. **Análisis de contexto animal** (necesidades, emociones, comportamientos).
5. **Análisis de contexto de plantas** (estado de crecimiento, salud, exposición al sol).
6. **Extracción de relaciones semánticas** entre objetos (polinizador-planta, depredador-presa, etc.).

---

## 2. Librerías y Técnicas Utilizadas

### 2.1. Detección de Objetos (YOLOv9)

**Librería**: `ultralytics`

**Instalación**:
```bash
pip install ultralytics
```

**Características**:
- Detección en tiempo real de múltiples clases de objetos
- Bounding boxes con confianza
- Soporte para GPU (CUDA)

**Ejemplo de Uso**:
```python
from ultralytics import YOLO

model = YOLO('yolov9.pt')
results = model.predict(source='video.mp4', conf=0.5)
```

### 2.2. Segmentación de Instancias (Detectron2)

**Librería**: `detectron2` (Facebook Research)

**Instalación**:
```bash
pip install detectron2
```

**Características**:
- Segmentación de instancias (máscaras por objeto)
- Detección de keypoints
- Separación de seres vivos de objetos inanimados

**Ejemplo de Uso**:
```python
from detectron2.engine import DefaultPredictor
from detectron2.config import get_cfg

cfg = get_cfg()
cfg.merge_from_file(model_zoo.get_config_file("COCO-InstanceSegmentation/mask_rcnn_R_50_FPN_3x.yaml"))
predictor = DefaultPredictor(cfg)
outputs = predictor(image)
```

### 2.3. Estimación de Pose (OpenPose)

**Librería**: `openpose-python` o **MediaPipe**

**Instalación (MediaPipe - recomendado)**:
```bash
pip install mediapipe
```

**Características**:
- Detección de esqueleto humano (17 keypoints)
- Detección de pose corporal
- Análisis de movimiento

**Ejemplo de Uso**:
```python
import mediapipe as mp

mp_pose = mp.solutions.pose
pose = mp_pose.Pose()
results = pose.process(image)
```

### 2.4. Análisis de Audio (para Vocalizaciones)

**Librería**: `librosa`

**Instalación**:
```bash
pip install librosa soundfile
```

**Características**:
- Extracción de características de audio (MFCC, espectrograma)
- Detección de vocalizaciones de animales
- Análisis de frecuencia

**Ejemplo de Uso**:
```python
import librosa

y, sr = librosa.load('audio.wav')
mfcc = librosa.feature.mfcc(y=y, sr=sr)
```

### 2.5. Procesamiento de Imágenes (scikit-image)

**Librería**: `scikit-image`

**Instalación**:
```bash
pip install scikit-image
```

**Características**:
- Análisis de color
- Detección de bordes
- Análisis de histogramas

---

## 3. Estructura del Microservicio

```
microservice_vision/
├── app.py                    # API Flask
├── vision_analyzer.py        # Lógica de análisis
├── db_vision_schema.py       # Esquema de BD
├── requirements.txt          # Dependencias
└── MANUAL_VISION_SERVICE.md  # Este archivo
```

---

## 4. Endpoints de la API

### 4.1. Analizar Video Completo

**Endpoint**: `POST /api/analyze/video`

**Autenticación**: Requiere header `X-Auth-Token: <MCP_MASTER_TOKEN>`

**Request**:
```json
{
    "user_id": "user_123",
    "video_path": "/path/to/video.mp4",
    "sample_rate": 1
}
```

**Response**:
```json
{
    "analysis_id": "abc123def456",
    "user_id": "user_123",
    "video_path": "/path/to/video.mp4",
    "fps": 30.0,
    "total_frames": 900,
    "duration_seconds": 30.0,
    "frame_analyses": [
        {
            "frame_number": 0,
            "timestamp_seconds": 0.0,
            "detected_objects": [...],
            "animal_contexts": [...],
            "plant_contexts": [...],
            "semantic_relations": [...]
        }
    ],
    "summary": {
        "total_frames_analyzed": 30,
        "animal_species_detected": ["bird", "cat"],
        "plant_types_detected": ["tulip", "rose"],
        "semantic_relations_count": 5
    }
}
```

### 4.2. Analizar Frame Individual

**Endpoint**: `POST /api/analyze/frame`

**Autenticación**: Requiere header `X-Auth-Token`

**Request** (multipart/form-data):
- `image`: Archivo de imagen
- `frame_number`: Número del frame (opcional)
- `timestamp_seconds`: Timestamp en segundos (opcional)

**Response**:
```json
{
    "frame_number": 0,
    "timestamp_seconds": 0.0,
    "detected_objects": [...],
    "animal_contexts": [...],
    "plant_contexts": [...],
    "semantic_relations": [...]
}
```

### 4.3. Obtener Indicadores de Necesidades Animales

**Endpoint**: `GET /api/animal-needs/<species>`

**Response**:
```json
{
    "species": "bird",
    "need_indicators": {
        "thirst": {
            "behaviors": ["approaching_water", "drinking_motion"],
            "visual_cues": ["dry_mouth", "sunken_eyes"],
            "vocalizations": ["whining"]
        }
    }
}
```

### 4.4. Obtener Estados de Plantas

**Endpoint**: `GET /api/plant-states`

**Response**:
```json
{
    "plant_states": {
        "growing": {
            "visual_cues": ["new_leaves", "upward_growth"],
            "color_range": [[0, 255, 0], [100, 200, 0]],
            "growth_rate": "high"
        }
    }
}
```

---

## 5. Base de Datos

### 5.1. Tablas Principales

| Tabla | Propósito |
| :--- | :--- |
| `video_analysis` | Registro de análisis de videos |
| `frame_analysis` | Análisis por frame |
| `detected_objects` | Objetos detectados |
| `animal_context` | Contexto de animales |
| `plant_context` | Contexto de plantas |
| `semantic_relations` | Relaciones entre objetos |

### 5.2. Tablas de Reentrenamiento

| Tabla | Propósito |
| :--- | :--- |
| `animal_needs_training` | Datos de necesidades animales para RL |
| `animal_actions_training` | Datos de acciones animales para RL |
| `plant_state_training` | Datos de estados de plantas para RL |
| `semantic_relations_training` | Datos de relaciones semánticas para RL |

---

## 6. Instalación y Despliegue

### 6.1. Instalación de Dependencias

```bash
cd microservice_vision
pip install -r requirements.txt
```

### 6.2. Instalación de Modelos (Opcional)

Para usar YOLOv9, Detectron2 u OpenPose, instale las librerías adicionales:

```bash
# YOLOv9
pip install ultralytics

# Detectron2
pip install detectron2

# MediaPipe (alternativa más ligera)
pip install mediapipe
```

### 6.3. Inicializar Base de Datos

```bash
python db_vision_schema.py --db-path /tmp/espejin_vision.db
```

### 6.4. Ejecutar el Servicio

```bash
export MCP_MASTER_TOKEN=your_token_here
export VISION_DB_PATH=/tmp/espejin_vision.db
export VISION_SERVICE_PORT=5001

python app.py
```

---

## 7. Integración con Montage Service

El Montage Service puede enviar videos al Vision Service para análisis avanzado:

```python
import requests

response = requests.post(
    'http://localhost:5001/api/analyze/video',
    json={
        "user_id": "user_123",
        "video_path": "/path/to/video.mp4",
        "sample_rate": 1
    },
    headers={'X-Auth-Token': 'MCP_MASTER_TOKEN'}
)

analysis_results = response.json()
```

---

## 8. Ejemplos de Análisis

### 8.1. Detectar Necesidades en un Pájaro

Un pájaro que se acerca al agua + movimiento de beber + vocalización de angustia = **Sed**

### 8.2. Detectar Expresividad Eufórica

Un pájaro volando + explorando + vocalizando alegremente = **Eufórico**

### 8.3. Detectar Relación Semántica

Un pájaro cerca de una flor florecida = **Polinizador-Planta**

---

## 9. Próximos Pasos

1. **Implementar modelos reales**: Reemplazar placeholders con YOLOv9, Detectron2, etc.
2. **Entrenar modelos personalizados**: Fine-tuning para especies específicas.
3. **Optimizar para GPU**: Usar CUDA para inferencia más rápida.
4. **Integrar con Mem0**: Para persistencia de contexto animal.


