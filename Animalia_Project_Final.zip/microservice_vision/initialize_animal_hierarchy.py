"""
Script de Inicialización de la Jerarquía Animal y la Base de Datos

Este script inicializa la jerarquía de especies y carga los datos iniciales
en la base de datos de entrenamiento, utilizando la jerarquía compleja definida
en animal_hierarchy.py.
"""

import uuid
import json
import logging
from animal_hierarchy import (
    AnimalHierarchyManager, initialize_example_hierarchy, AnimalGeneral, SpeciesRelation, 
    CommunicationPattern, CommunicationType, DietType, TemperatureType,
    Perros, Gatos, GanadoVacuno, GanadoCaprino, HomoSapiens, Pajaros, Gallinas, 
    Lechuzas, DragonBarbudo, LagartoCaiman, MonitorSabana, DragonKomodo, 
    DragonChinoMitologico, Fasmidos, AnimalRestriction
)
from db_animal_training_schema import AnimalTrainingDatabase
from multilingual_translation_pipeline import MultilingualTranslator, TranslationContext

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def initialize_database(db_path: str = "animal_training.db"):
    """Inicializa la base de datos y carga los datos de la jerarquía."""
    
    # 1. Inicializar el gestor de jerarquía y cargar la jerarquía compleja
    manager = AnimalHierarchyManager()
    initialize_example_hierarchy(manager)
    
    # 2. Inicializar la base de datos
    db = AnimalTrainingDatabase(db_path)
    
    logger.info("=" * 60)
    logger.info("INICIALIZANDO BASE DE DATOS CON JERARQUÍA COMPLEJA")
    logger.info("=" * 60)
    
    # 3. Cargar especies en la BD
    species_map = {}
    for animal in manager.get_all_species():
        # Usar el nombre de la especie como ID simplificado para el mapeo
        species_id = animal.species_name.replace(" ", "_").lower()
        species_map[animal.species_name] = species_id
        
        db.insert_animal_species(
            species_id=species_id,
            species_name=animal.species_name,
            scientific_name=animal.scientific_name,
            common_names=animal.common_names,
            temperature_type=animal.temperature_type.value,
            diet_type=animal.diet_type.value,
            spanish_context=animal.spanish_context
        )
        
        # Cargar restricciones
        for restriction in animal.restrictions:
            db.cursor.execute("""
                INSERT INTO animal_restrictions 
                (restriction_id, animal_species_id, restriction_type, description,
                 forbidden_items, allowed_items)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (str(uuid.uuid4()), species_id, restriction.restriction_type, 
                  restriction.description, json.dumps(restriction.forbidden_items), 
                  json.dumps(restriction.allowed_items)))
            db.connection.commit()
            
        # Cargar patrones de comunicación
        for pattern in animal.communication_patterns:
            db.cursor.execute("""
                INSERT INTO communication_patterns 
                (pattern_id, pattern_name, description, universal_species,
                 communication_types, spanish_context, confidence_score)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (pattern.pattern_id, pattern.pattern_name, pattern.description,
                  json.dumps(pattern.universal_species), 
                  json.dumps([c.value for c in pattern.communication_types]), 
                  pattern.spanish_context, pattern.confidence_score))
            db.connection.commit()
            
        # Generar y cargar textos de entrenamiento
        translator = MultilingualTranslator()
        
        # Generar un texto de entrenamiento base para la especie (usando el primer patrón)
        if animal.communication_patterns:
            pattern = animal.communication_patterns[0]
            
            # 1. Crear el contexto de traducción
            context = TranslationContext(
                original_language="spanish",
                target_languages=["english", "french", "chinese", "tibetan", "mongolian"],
                animal_species=animal.species_name,
                behavior_description=pattern.pattern_name,
                spanish_context=pattern.spanish_context
            )
            
            # 2. Generar el texto de entrenamiento
            training_text_obj = translator.generate_training_text(context, pattern)
            training_text_id = training_text_obj.text_id
            
            db.insert_training_text(
                text_id=training_text_id,
                animal_species_id=species_id,
                behavior_description=pattern.pattern_name,
                spanish_context=pattern.spanish_context,
                raw_text=training_text_obj.raw_text,
                ready_for_rl=True
            )
            
            # Cargar expresiones multilingües
            for lang, expr in training_text_obj.human_expressions.items():
                db.insert_multilingual_expression(
                    expression_id=str(uuid.uuid4()),
                    training_text_id=training_text_id,
                    original_expression=pattern.spanish_context,
                    language=lang,
                    translated_expression=expr,
                    confidence=0.95
                )
            
            # Cargar expresiones en lenguajes animales
            for lang, expr in training_text_obj.animal_expressions.items():
                db.insert_animal_language_expression(
                    expression_id=str(uuid.uuid4()),
                    training_text_id=training_text_id,
                    animal_species_id=species_id,
                    animal_language=lang,
                    animal_expression=expr,
                    confidence=0.95
                )
    
    # 4. Cargar relaciones entre especies
    for relation in manager.get_all_relations():
        species_a_id = species_map.get(relation.species_a)
        species_b_id = species_map.get(relation.species_b)
        
        if species_a_id and species_b_id:
            db.cursor.execute("""
                INSERT INTO species_relations 
                (relation_id, species_a_id, species_b_id, relation_type,
                 description, confidence)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (relation.relation_id, species_a_id, species_b_id, 
                  relation.relation_type, relation.description, relation.confidence))
            db.connection.commit()
        else:
            logger.warning(f"Warning: Could not find species ID for relation between {relation.species_a} and {relation.species_b}")
            
    db.close()
    logger.info(f"Database initialization complete. {len(species_map)} species loaded.")

if __name__ == "__main__":
    initialize_database()
