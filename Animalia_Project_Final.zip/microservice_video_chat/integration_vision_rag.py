"""
Integración del Chat RAG con el Microservicio de Visión

Proporciona:
1. Conexión entre el Chat RAG y el Microservicio de Visión
2. Análisis de contexto animal para respuestas
3. Reentrenamiento distribuido basado en interacciones
"""

import requests
import json
import logging
from typing import Dict, List, Optional
from datetime import datetime

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class VisionRAGIntegration:
    """Integración entre Vision Service y RAG Chat."""
    
    def __init__(self, vision_service_url: str = "http://localhost:5001",
                 rag_service_url: str = "http://localhost:5002"):
        self.vision_service_url = vision_service_url
        self.rag_service_url = rag_service_url
        self.retraining_data = []
    
    def analyze_video_context(self, video_id: str) -> Dict:
        """Obtiene el contexto de análisis de video del Microservicio de Visión."""
        try:
            response = requests.get(
                f"{self.vision_service_url}/api/analyze/video/{video_id}",
                timeout=10
            )
            if response.status_code == 200:
                return response.json()
        except Exception as e:
            logger.error(f"Error analyzing video context: {e}")
        
        return {}
    
    def get_animal_species_context(self, video_id: str) -> List[str]:
        """Obtiene las especies animales detectadas en el video."""
        try:
            response = requests.get(
                f"{self.vision_service_url}/api/detected-species/{video_id}",
                timeout=10
            )
            if response.status_code == 200:
                return response.json().get("species", [])
        except Exception as e:
            logger.error(f"Error getting animal species: {e}")
        
        return []
    
    def enrich_rag_response(self, rag_response: Dict, video_id: str, 
                           user_question: str) -> Dict:
        """Enriquece la respuesta RAG con contexto del Microservicio de Visión."""
        
        # Obtener contexto de video
        video_context = self.analyze_video_context(video_id)
        species_context = self.get_animal_species_context(video_id)
        
        # Enriquecer respuesta
        enriched_response = rag_response.copy()
        enriched_response["video_context"] = video_context
        enriched_response["detected_species"] = species_context
        
        # Determinar tipo de contexto basado en la pregunta
        context_type = self._determine_context_type(user_question)
        enriched_response["context_type"] = context_type
        
        # Registrar para reentrenamiento
        self._register_for_retraining(
            user_question=user_question,
            response=rag_response.get("response", ""),
            species=species_context,
            context_type=context_type,
            video_id=video_id
        )
        
        return enriched_response
    
    def _determine_context_type(self, question: str) -> str:
        """Determina el tipo de contexto basado en la pregunta."""
        question_lower = question.lower()
        
        if any(word in question_lower for word in ["comportamiento", "actitud", "acción"]):
            return "animal_behavior"
        elif any(word in question_lower for word in ["especie", "tipo", "raza"]):
            return "species_specific"
        elif any(word in question_lower for word in ["sonido", "voz", "canto", "ladrido"]):
            return "communication"
        elif any(word in question_lower for word in ["comida", "comer", "alimento"]):
            return "nutrition"
        elif any(word in question_lower for word in ["hábitat", "lugar", "ambiente"]):
            return "habitat"
        else:
            return "general"
    
    def _register_for_retraining(self, user_question: str, response: str,
                                 species: List[str], context_type: str, video_id: str):
        """Registra la interacción para reentrenamiento distribuido."""
        
        retraining_entry = {
            "timestamp": datetime.now().isoformat(),
            "user_question": user_question,
            "response": response,
            "species": species,
            "context_type": context_type,
            "video_id": video_id,
            "confidence": 0.85  # Simulado
        }
        
        self.retraining_data.append(retraining_entry)
        logger.info(f"Registered for retraining: {context_type} - {user_question[:50]}...")
    
    def send_retraining_data_to_vision_service(self) -> bool:
        """Envía datos de reentrenamiento al Microservicio de Visión."""
        if not self.retraining_data:
            return False
        
        try:
            response = requests.post(
                f"{self.vision_service_url}/api/retraining/add-corpus",
                json={"entries": self.retraining_data},
                timeout=10
            )
            
            if response.status_code == 200:
                logger.info(f"Sent {len(self.retraining_data)} retraining entries to Vision Service")
                self.retraining_data = []  # Limpiar después de enviar
                return True
        except Exception as e:
            logger.error(f"Error sending retraining data: {e}")
        
        return False
    
    def get_species_training_corpus(self, species: str) -> str:
        """Obtiene el corpus de entrenamiento para una especie específica."""
        try:
            response = requests.get(
                f"{self.vision_service_url}/api/training-corpus/{species}",
                timeout=10
            )
            if response.status_code == 200:
                return response.json().get("corpus", "")
        except Exception as e:
            logger.error(f"Error getting training corpus: {e}")
        
        return ""
    
    def get_species_communication_patterns(self, species: str) -> List[Dict]:
        """Obtiene los patrones de comunicación de una especie."""
        try:
            response = requests.get(
                f"{self.vision_service_url}/api/communication-patterns/{species}",
                timeout=10
            )
            if response.status_code == 200:
                return response.json().get("patterns", [])
        except Exception as e:
            logger.error(f"Error getting communication patterns: {e}")
        
        return []

# ==============================================================================
# EJEMPLO DE USO
# ==============================================================================

if __name__ == "__main__":
    # Crear integración
    integration = VisionRAGIntegration()
    
    # Simular una respuesta RAG
    rag_response = {
        "response_id": "resp_123",
        "response": "El comportamiento observado indica que el animal está buscando alimento.",
        "confidence": 0.85,
        "sources": ["Chunk 1", "Chunk 2"]
    }
    
    # Enriquecer con contexto de visión
    enriched = integration.enrich_rag_response(
        rag_response=rag_response,
        video_id="video_001",
        user_question="¿Por qué el perro está olfateando el suelo?"
    )
    
    print("Enriched Response:")
    print(json.dumps(enriched, indent=2))
    
    # Enviar datos de reentrenamiento
    integration.send_retraining_data_to_vision_service()

