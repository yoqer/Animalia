"""
Backend del Chat RAG (Retrieval-Augmented Generation) para Videos

Proporciona endpoints para:
1. Subida de videos/transcripciones
2. Indexación y recuperación de contenido
3. Generación de respuestas con contexto de video
4. Integración con Gemini File Search o LangChain
"""

from flask import Flask, request, jsonify
from flask_cors import CORS
import uuid
import json
import logging
from typing import List, Dict, Optional
from datetime import datetime
import sqlite3

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)
CORS(app)

# ==============================================================================
# CONFIGURACIÓN
# ==============================================================================

class RAGConfig:
    """Configuración del sistema RAG."""
    def __init__(self):
        self.llm_provider = "gemini"  # "gemini", "openai", "anthropic"
        self.embedding_model = "gemini-embedding-001"
        self.chunk_size = 1000  # caracteres
        self.chunk_overlap = 200
        self.max_context_length = 4000
        self.temperature = 0.7
        self.top_k_results = 5

config = RAGConfig()

# ==============================================================================
# CLASES BASE
# ==============================================================================

class VideoDocument:
    """Representa un documento de video para RAG."""
    def __init__(self, video_id: str, title: str, transcript: str, metadata: Dict = None):
        self.video_id = video_id
        self.title = title
        self.transcript = transcript
        self.metadata = metadata or {}
        self.chunks = []
        self.embeddings = []
        self.created_at = datetime.now().isoformat()
        
    def chunk_text(self, chunk_size: int = 1000, overlap: int = 200):
        """Divide el transcript en chunks."""
        text = self.transcript
        chunks = []
        
        for i in range(0, len(text), chunk_size - overlap):
            chunk = text[i:i + chunk_size]
            if chunk.strip():
                chunks.append({
                    "text": chunk,
                    "start_pos": i,
                    "end_pos": i + len(chunk)
                })
        
        self.chunks = chunks
        return chunks

class RAGQuery:
    """Representa una consulta RAG."""
    def __init__(self, query_id: str, user_question: str, video_id: str, 
                 context_type: str = "general"):
        self.query_id = query_id
        self.user_question = user_question
        self.video_id = video_id
        self.context_type = context_type  # "general", "animal_behavior", "species_specific"
        self.retrieved_chunks = []
        self.generated_response = ""
        self.confidence_score = 0.0
        self.created_at = datetime.now().isoformat()

class RAGResponse:
    """Representa una respuesta RAG."""
    def __init__(self, query_id: str, response_text: str, sources: List[str], 
                 confidence: float, related_species: List[str] = None):
        self.response_id = str(uuid.uuid4())
        self.query_id = query_id
        self.response_text = response_text
        self.sources = sources
        self.confidence = confidence
        self.related_species = related_species or []
        self.created_at = datetime.now().isoformat()

# ==============================================================================
# GESTOR RAG
# ==============================================================================

class RAGManager:
    """Gestor principal del sistema RAG."""
    
    def __init__(self):
        self.documents: Dict[str, VideoDocument] = {}
        self.queries: Dict[str, RAGQuery] = {}
        self.responses: Dict[str, RAGResponse] = {}
        
    def add_document(self, video_id: str, title: str, transcript: str, metadata: Dict = None) -> VideoDocument:
        """Añade un documento de video."""
        doc = VideoDocument(video_id, title, transcript, metadata)
        doc.chunk_text(config.chunk_size, config.chunk_overlap)
        self.documents[video_id] = doc
        logger.info(f"Document added: {video_id} with {len(doc.chunks)} chunks")
        return doc
    
    def retrieve_relevant_chunks(self, query: str, video_id: str, top_k: int = 5) -> List[Dict]:
        """Recupera chunks relevantes para una consulta."""
        if video_id not in self.documents:
            return []
        
        doc = self.documents[video_id]
        
        # Simulación de búsqueda por similitud (en producción usar embeddings)
        relevant_chunks = []
        query_words = set(query.lower().split())
        
        for chunk in doc.chunks:
            chunk_words = set(chunk["text"].lower().split())
            similarity = len(query_words & chunk_words) / len(query_words | chunk_words) if query_words | chunk_words else 0
            
            if similarity > 0:
                relevant_chunks.append({
                    "text": chunk["text"],
                    "similarity": similarity,
                    "position": chunk["start_pos"]
                })
        
        # Ordenar por similitud y retornar top_k
        relevant_chunks.sort(key=lambda x: x["similarity"], reverse=True)
        return relevant_chunks[:top_k]
    
    def generate_response(self, query: str, retrieved_chunks: List[Dict], 
                         context_type: str = "general") -> RAGResponse:
        """Genera una respuesta basada en chunks recuperados."""
        
        # Construir contexto
        context = "\n".join([f"[Fuente]: {chunk['text'][:200]}..." for chunk in retrieved_chunks])
        
        # Simulación de generación con LLM (en producción usar Gemini/OpenAI)
        response_text = f"""
        Basándome en el contenido del video:
        
        {context}
        
        Respuesta a tu pregunta "{query}":
        
        [Aquí iría la respuesta generada por el LLM con contexto del video]
        
        Contexto de análisis: {context_type}
        """
        
        # Calcular confianza
        confidence = sum([c.get("similarity", 0) for c in retrieved_chunks]) / len(retrieved_chunks) if retrieved_chunks else 0
        
        # Extraer especies relacionadas (simulado)
        related_species = []
        if "animal" in query.lower():
            related_species = ["Canis familiaris", "Felis catus", "Aves"]
        
        return RAGResponse(
            query_id=str(uuid.uuid4()),
            response_text=response_text,
            sources=[f"Chunk {i}" for i in range(len(retrieved_chunks))],
            confidence=confidence,
            related_species=related_species
        )

# ==============================================================================
# INSTANCIA GLOBAL
# ==============================================================================

rag_manager = RAGManager()

# ==============================================================================
# ENDPOINTS
# ==============================================================================

@app.route("/api/rag/upload-video", methods=["POST"])
def upload_video():
    """Sube un video o su transcripción para indexación RAG."""
    data = request.json
    
    video_id = str(uuid.uuid4())
    title = data.get("title", "Untitled Video")
    transcript = data.get("transcript", "")
    metadata = data.get("metadata", {})
    
    doc = rag_manager.add_document(video_id, title, transcript, metadata)
    
    return jsonify({
        "status": "success",
        "video_id": video_id,
        "chunks_created": len(doc.chunks),
        "message": f"Video '{title}' indexed successfully"
    }), 201

@app.route("/api/rag/query", methods=["POST"])
def query_video():
    """Realiza una consulta RAG sobre un video."""
    data = request.json
    
    user_question = data.get("question", "")
    video_id = data.get("video_id", "")
    context_type = data.get("context_type", "general")
    
    if not user_question or not video_id:
        return jsonify({"error": "Missing question or video_id"}), 400
    
    # Recuperar chunks relevantes
    chunks = rag_manager.retrieve_relevant_chunks(user_question, video_id, config.top_k_results)
    
    # Generar respuesta
    rag_response = rag_manager.generate_response(user_question, chunks, context_type)
    
    # Almacenar respuesta
    rag_manager.responses[rag_response.response_id] = rag_response
    
    return jsonify({
        "status": "success",
        "response_id": rag_response.response_id,
        "response": rag_response.response_text,
        "confidence": rag_response.confidence,
        "sources": rag_response.sources,
        "related_species": rag_response.related_species
    }), 200

@app.route("/api/rag/response/<response_id>", methods=["GET"])
def get_response(response_id):
    """Obtiene una respuesta RAG específica."""
    if response_id not in rag_manager.responses:
        return jsonify({"error": "Response not found"}), 404
    
    resp = rag_manager.responses[response_id]
    return jsonify({
        "response_id": resp.response_id,
        "response": resp.response_text,
        "confidence": resp.confidence,
        "sources": resp.sources,
        "created_at": resp.created_at
    }), 200

@app.route("/api/rag/health", methods=["GET"])
def health():
    """Verifica el estado del servicio RAG."""
    return jsonify({
        "status": "healthy",
        "documents_indexed": len(rag_manager.documents),
        "queries_processed": len(rag_manager.queries),
        "responses_generated": len(rag_manager.responses)
    }), 200

# ==============================================================================
# MAIN
# ==============================================================================

if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5002)

