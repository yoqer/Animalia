# Manual del Sistema de Chat RAG para Videos

## Descripción General

El **Sistema de Chat RAG (Retrieval-Augmented Generation)** permite a los usuarios hacer preguntas sobre videos mientras se reproducen, con respuestas generadas por IA basadas en el contenido del video.

## Características Principales

### 1. **Chat Interactivo en Tiempo Real**
- Interface responsive (desktop y móvil)
- Soporte para entrada de texto y voz
- Indicadores de escritura en tiempo real

### 2. **Recuperación Aumentada (RAG)**
- Indexación automática de transcripciones de video
- Recuperación de chunks relevantes
- Respuestas contextuales basadas en el contenido

### 3. **Memoria Persistente (Mem0 Personalizado)**
- Almacenamiento local en SQLite
- Respaldo automático en la web (no indicado al usuario)
- Recuperación de contexto histórico

### 4. **Integración con Microservicio de Visión**
- Análisis de contexto animal
- Detección de especies
- Reentrenamiento distribuido

## Arquitectura

```
┌─────────────────────────────────────────────────────────────┐
│                    Frontend (HTML/JS)                       │
│                    - Chat UI Responsive                     │
│                    - Voice Input (Web Speech API)           │
│                    - Local Storage Cache                    │
└────────────────────────┬────────────────────────────────────┘
                         │
┌────────────────────────▼────────────────────────────────────┐
│              Backend RAG (Flask)                            │
│  - rag_backend.py (RAG Logic)                              │
│  - mem0_custom.py (Memory Management)                      │
│  - integration_vision_rag.py (Vision Integration)          │
└────────────────────────┬────────────────────────────────────┘
                         │
┌────────────────────────▼────────────────────────────────────┐
│         Microservicio de Visión (Vision Service)           │
│  - Animal Behavior Analysis                                │
│  - Species Detection                                       │
│  - Retraining Corpus Management                            │
└─────────────────────────────────────────────────────────────┘
```

## Componentes

### 1. **rag_backend.py**
Backend Flask que proporciona:
- `POST /api/rag/upload-video`: Sube un video/transcripción
- `POST /api/rag/query`: Realiza una consulta RAG
- `GET /api/rag/response/<response_id>`: Obtiene una respuesta
- `GET /api/rag/health`: Verifica el estado del servicio

### 2. **mem0_custom.py**
Sistema de memoria personalizado:
- `LocalMemoryManager`: Almacenamiento local en SQLite
- `RemoteMemoryManager`: Respaldo en la web
- `IntegratedMemoryManager`: Gestor integrado

### 3. **chat_ui.html**
Interface de usuario:
- Chat responsive
- Entrada de voz
- Indicadores de confianza
- Especies relacionadas

### 4. **integration_vision_rag.py**
Integración con el Microservicio de Visión:
- Análisis de contexto de video
- Detección de especies
- Registro de reentrenamiento

## Flujo de Uso

### 1. **Subida de Video**
```python
POST /api/rag/upload-video
{
    "title": "Video de Perro",
    "transcript": "El perro está corriendo en el parque...",
    "metadata": {"duration": 300, "species": ["Canis familiaris"]}
}
```

### 2. **Consulta RAG**
```python
POST /api/rag/query
{
    "question": "¿Por qué el perro está corriendo?",
    "video_id": "video_001",
    "context_type": "animal_behavior"
}
```

### 3. **Respuesta Enriquecida**
```json
{
    "response_id": "resp_123",
    "response": "Basándome en el video...",
    "confidence": 0.85,
    "sources": ["Chunk 1", "Chunk 2"],
    "related_species": ["Canis familiaris"],
    "context_type": "animal_behavior"
}
```

## Tipos de Contexto

| Tipo | Palabras Clave | Ejemplo |
| :--- | :--- | :--- |
| **animal_behavior** | comportamiento, actitud, acción | "¿Qué está haciendo el gato?" |
| **species_specific** | especie, tipo, raza | "¿Qué raza de perro es?" |
| **communication** | sonido, voz, canto, ladrido | "¿Qué significa ese ladrido?" |
| **nutrition** | comida, comer, alimento | "¿Qué come el pájaro?" |
| **habitat** | hábitat, lugar, ambiente | "¿Dónde vive?" |
| **general** | otros | Preguntas generales |

## Memoria Persistente

### Almacenamiento Local
```
user_memory_local.db
├── memory_entries (Preguntas y respuestas del usuario)
├── subject_matter_relations (Relaciones entre materias)
├── memory_access_log (Registro de acceso)
└── retraining_corpus (Corpus para reentrenamiento)
```

### Respaldo Remoto
- Automático y transparente
- No indicado al usuario
- Sincronización periódica

## Reentrenamiento Distribuido

El sistema registra automáticamente:
1. **Preguntas del usuario**
2. **Respuestas generadas**
3. **Especies detectadas**
4. **Tipo de contexto**
5. **Confianza de la respuesta**

Estos datos se envían al Microservicio de Visión para:
- Mejorar patrones de comunicación animal
- Actualizar corpus de entrenamiento
- Especializar por especie

## Instalación y Despliegue

### 1. Instalar Dependencias
```bash
pip install -r requirements.txt
```

### 2. Iniciar el Backend RAG
```bash
python rag_backend.py
```

### 3. Abrir la Interface de Chat
```
http://localhost:5002/chat_ui.html
```

## Configuración

### Variables de Entorno
```
RAG_LLM_PROVIDER=gemini  # gemini, openai, anthropic
RAG_EMBEDDING_MODEL=gemini-embedding-001
RAG_CHUNK_SIZE=1000
RAG_TEMPERATURE=0.7
VISION_SERVICE_URL=http://localhost:5001
```

## Ejemplos de Uso

### Ejemplo 1: Pregunta sobre Comportamiento
```
Usuario: "¿Por qué el perro está moviendo la cola?"
IA: "Basándome en el video, el movimiento de la cola indica alegría y excitación. 
     En los perros, esto es una señal de comportamiento positivo."
Confianza: 92%
Especies: Canis familiaris
```

### Ejemplo 2: Pregunta sobre Comunicación
```
Usuario: "¿Qué significa ese sonido que hace el pájaro?"
IA: "El canto que escuchas es típico de los pájaros durante la época de reproducción. 
     Es una llamada territorial para atraer parejas."
Confianza: 85%
Especies: Aves
```

## Limitaciones y Consideraciones

1. **Dependencia de Transcripción**: La calidad del RAG depende de la transcripción del video
2. **Contexto Limitado**: Solo analiza el contenido del video actual
3. **Idioma**: Actualmente soporta español, inglés, francés, chino, coreano
4. **Privacidad**: Los datos se almacenan localmente y en respaldo remoto

## Troubleshooting

### El chat no responde
- Verificar que el backend RAG está ejecutándose
- Comprobar la conexión con el Microservicio de Visión
- Revisar los logs en `rag_backend.log`

### Las respuestas no son relevantes
- Asegurar que la transcripción del video es correcta
- Aumentar el número de chunks recuperados (`top_k_results`)
- Verificar que el tipo de contexto es correcto

### Problemas de memoria
- Limpiar la BD local: `rm user_memory_local.db`
- Sincronizar con el servidor remoto manualmente

## Futuras Mejoras

- [ ] Soporte para múltiples idiomas en tiempo real
- [ ] Análisis de video en tiempo real (sin transcripción)
- [ ] Integración con más modelos de LLM
- [ ] Análisis de expresiones faciales y gestos
- [ ] Generación de resúmenes de video

## Soporte

Para reportar problemas o sugerencias, contacta a: support@animalia.example.com

