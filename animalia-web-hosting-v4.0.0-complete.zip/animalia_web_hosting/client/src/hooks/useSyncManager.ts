import { useEffect, useState, useCallback } from "react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { toast } from "sonner";

interface SyncStatus {
  isSyncing: boolean;
  lastSync: Date | null;
  nextSync: Date | null;
  progress: number;
  error: string | null;
}

/**
 * Hook para gestionar la sincronización automática entre Desktop y Web
 * Sincroniza patrones, conocimiento, conversaciones y solicitudes de reentreno
 */
export function useSyncManager(autoSync = true, interval = 5 * 60 * 1000) {
  const { user } = useAuth();
  const [status, setStatus] = useState<SyncStatus>({
    isSyncing: false,
    lastSync: null,
    nextSync: null,
    progress: 0,
    error: null,
  });

  // Procedimientos tRPC para sincronización
  const syncPatterns = trpc.sync.getPatterns.useQuery(
    { since: status.lastSync || new Date(0) },
    { enabled: false }
  );

  const syncKnowledge = trpc.sync.getKnowledge.useQuery(
    { since: status.lastSync || new Date(0) },
    { enabled: false }
  );

  const syncConversations = trpc.sync.getConversations.useQuery(
    { since: status.lastSync || new Date(0) },
    { enabled: false }
  );

  const syncRetraining = trpc.sync.getRetrainingRequests.useQuery(
    { limit: 50 },
    { enabled: false }
  );

  const uploadPatterns = trpc.sync.uploadPatterns.useMutation();
  const uploadKnowledge = trpc.sync.uploadKnowledge.useMutation();
  const uploadConversations = trpc.sync.uploadConversations.useMutation();

  /**
   * Realiza una sincronización completa
   */
  const performSync = useCallback(async () => {
    if (!user) return;

    try {
      setStatus((prev) => ({
        ...prev,
        isSyncing: true,
        error: null,
        progress: 0,
      }));

      // Paso 1: Descargar datos desde el servidor (25%)
      setStatus((prev) => ({ ...prev, progress: 25 }));
      const [patterns, knowledge, conversations, retraining] = await Promise.all([
        syncPatterns.refetch().catch(() => ({ data: [] })),
        syncKnowledge.refetch().catch(() => ({ data: [] })),
        syncConversations.refetch().catch(() => ({ data: [] })),
        syncRetraining.refetch().catch(() => ({ data: [] })),
      ]);

      // Paso 2: Procesar datos descargados (50%)
      setStatus((prev) => ({ ...prev, progress: 50 }));

      // Paso 3: Subir cambios locales (75%)
      setStatus((prev) => ({ ...prev, progress: 75 }));
      // Los datos se suben automáticamente cuando se crean/actualizan

      // Paso 4: Finalizar sincronización (100%)
      setStatus((prev) => ({
        ...prev,
        progress: 100,
        isSyncing: false,
        lastSync: new Date(),
        nextSync: new Date(Date.now() + interval),
      }));
      toast.success("Sincronización completada exitosamente");

      return {
        patterns: patterns?.data || [],
        knowledge: knowledge?.data || [],
        conversations: conversations?.data || [],
        retraining: retraining?.data || [],
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Error desconocido";
      setStatus((prev) => ({
        ...prev,
        isSyncing: false,
        error: errorMessage,
      }));
      toast.error(`Error en sincronización: ${errorMessage}`);
      throw error;
    }
  }, [user, interval, syncPatterns, syncKnowledge, syncConversations, syncRetraining]);

  /**
   * Sincronización automática cada X minutos
   */
  useEffect(() => {
    if (!autoSync || !user) return;

    // Sincronizar inmediatamente
    performSync();

    // Configurar sincronización automática
    const syncInterval = setInterval(performSync, interval);

    return () => clearInterval(syncInterval);
  }, [autoSync, user, interval, performSync, syncPatterns, syncKnowledge, syncConversations, syncRetraining]);

  const handleUploadPatterns = async (patterns: any[]) => {
    return uploadPatterns.mutateAsync({ patterns });
  };

  const handleUploadKnowledge = async (knowledge: any[]) => {
    return uploadKnowledge.mutateAsync({ knowledge });
  };

  const handleUploadConversations = async (conversations: any[]) => {
    return uploadConversations.mutateAsync({ conversations });
  };

  return {
    status,
    performSync,
    handleUploadPatterns,
    handleUploadKnowledge,
    handleUploadConversations,
  };
}
