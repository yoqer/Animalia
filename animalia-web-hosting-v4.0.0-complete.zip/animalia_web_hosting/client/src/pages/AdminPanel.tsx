import { useState } from 'react';
import { DashboardLayout } from '@/components/DashboardLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Plus, Settings, Trash2, Check, X } from 'lucide-react';
import { trpc } from '@/lib/trpc';

export default function AdminPanel() {
  const [activeTab, setActiveTab] = useState('ai-providers');
  const [newProvider, setNewProvider] = useState({ name: '', apiKey: '', endpoint: '' });
  const [newDatabase, setNewDatabase] = useState({ name: '', type: '', credentials: '' });

  // Queries
  const aiProviders = trpc.admin.listAIProviders.useQuery();
  const databases = trpc.admin.listDatabases.useQuery();
  const webhooks = trpc.admin.listWebhooks.useQuery();

  // Mutations
  const addAIProvider = trpc.admin.addAIProvider.useMutation({
    onSuccess: () => {
      aiProviders.refetch();
      setNewProvider({ name: '', apiKey: '', endpoint: '' });
    },
  });

  const addDatabase = trpc.admin.addDatabase.useMutation({
    onSuccess: () => {
      databases.refetch();
      setNewDatabase({ name: '', type: '', credentials: '' });
    },
  });

  const removeAIProvider = trpc.admin.removeAIProvider.useMutation({
    onSuccess: () => aiProviders.refetch(),
  });

  const removeDatabase = trpc.admin.removeDatabase.useMutation({
    onSuccess: () => databases.refetch(),
  });

  const testConnection = trpc.admin.testConnection.useMutation();

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Panel de Administración</h1>
          <p className="text-muted-foreground mt-2">
            Gestiona proveedores de IA, bases de datos y webhooks
          </p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="ai-providers">Proveedores IA</TabsTrigger>
            <TabsTrigger value="databases">Bases de Datos</TabsTrigger>
            <TabsTrigger value="webhooks">Webhooks</TabsTrigger>
          </TabsList>

          {/* Proveedores de IA */}
          <TabsContent value="ai-providers" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Agregar Nuevo Proveedor de IA</CardTitle>
                <CardDescription>
                  Configura acceso a OpenAI, Gemini, Claude, Grok, Meta, Qwen, Deepseek, Perplexity, Copilot, Ollama, LMstudio
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Input
                    placeholder="Nombre del proveedor (ej: OpenAI, Gemini, Claude)"
                    value={newProvider.name}
                    onChange={(e) => setNewProvider({ ...newProvider, name: e.target.value })}
                  />
                  <Input
                    placeholder="Clave API"
                    type="password"
                    value={newProvider.apiKey}
                    onChange={(e) => setNewProvider({ ...newProvider, apiKey: e.target.value })}
                  />
                  <Input
                    placeholder="Endpoint (opcional)"
                    value={newProvider.endpoint}
                    onChange={(e) => setNewProvider({ ...newProvider, endpoint: e.target.value })}
                  />
                </div>
                <Button
                  onClick={() => addAIProvider.mutate(newProvider)}
                  disabled={addAIProvider.isPending}
                  className="w-full"
                >
                  <Plus className="mr-2 h-4 w-4" />
                  Agregar Proveedor
                </Button>
              </CardContent>
            </Card>

            {/* Lista de Proveedores */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {aiProviders.data?.providers?.map((provider: any) => (
                <Card key={provider.id}>
                  <CardHeader>
                    <CardTitle className="text-lg">{provider.name}</CardTitle>
                    <CardDescription>{provider.type || 'Proveedor personalizado'}</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Estado:</span>
                      {provider.active ? (
                        <Check className="h-4 w-4 text-green-500" />
                      ) : (
                        <X className="h-4 w-4 text-red-500" />
                      )}
                    </div>
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() =>
                          testConnection.mutate({
                            type: 'ai-provider',
                            id: provider.id,
                          })
                        }
                      >
                        Probar
                      </Button>
                      <Button
                        size="sm"
                        variant="destructive"
                        onClick={() => removeAIProvider.mutate(provider.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Bases de Datos */}
          <TabsContent value="databases" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Agregar Nueva Base de Datos</CardTitle>
                <CardDescription>
                  Conecta Supabase, Database.com, Notion, Obsidian, NotebookLM y otras fuentes de datos
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Input
                    placeholder="Nombre de la BD (ej: Supabase, Notion)"
                    value={newDatabase.name}
                    onChange={(e) => setNewDatabase({ ...newDatabase, name: e.target.value })}
                  />
                  <Input
                    placeholder="Tipo (supabase, notion, obsidian, etc)"
                    value={newDatabase.type}
                    onChange={(e) => setNewDatabase({ ...newDatabase, type: e.target.value })}
                  />
                  <Input
                    placeholder="Credenciales/Token"
                    type="password"
                    value={newDatabase.credentials}
                    onChange={(e) =>
                      setNewDatabase({ ...newDatabase, credentials: e.target.value })
                    }
                  />
                </div>
                <Button
                  onClick={() => addDatabase.mutate(newDatabase)}
                  disabled={addDatabase.isPending}
                  className="w-full"
                >
                  <Plus className="mr-2 h-4 w-4" />
                  Agregar Base de Datos
                </Button>
              </CardContent>
            </Card>

            {/* Lista de Bases de Datos */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {databases.data?.databases?.map((db: any) => (
                <Card key={db.id}>
                  <CardHeader>
                    <CardTitle className="text-lg">{db.name}</CardTitle>
                    <CardDescription>{db.type}</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Conectada:</span>
                      {db.connected ? (
                        <Check className="h-4 w-4 text-green-500" />
                      ) : (
                        <X className="h-4 w-4 text-red-500" />
                      )}
                    </div>
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() =>
                          testConnection.mutate({
                            type: 'database',
                            id: db.id,
                          })
                        }
                      >
                        Probar
                      </Button>
                      <Button
                        size="sm"
                        variant="destructive"
                        onClick={() => removeDatabase.mutate(db.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Webhooks */}
          <TabsContent value="webhooks" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Webhooks Configurados</CardTitle>
                <CardDescription>Gestiona webhooks para sincronización y eventos</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {webhooks.data?.webhooks?.map((webhook: any) => (
                    <div key={webhook.id} className="flex items-center justify-between p-4 border rounded">
                      <div>
                        <p className="font-medium">{webhook.name}</p>
                        <p className="text-sm text-muted-foreground">{webhook.url}</p>
                      </div>
                      <Button
                        size="sm"
                        variant="destructive"
                        onClick={() => removeDatabase.mutate(webhook.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
}
