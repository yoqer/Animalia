import { useAuth } from "@/_core/hooks/useAuth";
import DashboardLayout from "@/components/DashboardLayout";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  BarChart, Bar, LineChart, Line, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer
} from "recharts";
import { Download, TrendingUp, Calendar } from "lucide-react";

const speciesData = [
  { name: "Panthera leo", patterns: 45, confidence: 92, accuracy: 94 },
  { name: "Canis lupus", patterns: 38, confidence: 88, accuracy: 90 },
  { name: "Ursus arctos", patterns: 32, confidence: 85, accuracy: 87 },
  { name: "Equus ferus", patterns: 28, confidence: 90, accuracy: 92 },
];

const timeSeriesData = [
  { month: "Ene", patterns: 120, accuracy: 85, confidence: 82 },
  { month: "Feb", patterns: 145, accuracy: 87, confidence: 85 },
  { month: "Mar", patterns: 165, accuracy: 89, confidence: 88 },
  { month: "Abr", patterns: 180, accuracy: 90, confidence: 89 },
  { month: "May", patterns: 195, accuracy: 91, confidence: 90 },
  { month: "Jun", patterns: 210, accuracy: 92, confidence: 91 },
];

const categoryDistribution = [
  { name: "Comunicación", value: 35, color: "#3b82f6" },
  { name: "Comportamiento", value: 30, color: "#10b981" },
  { name: "Alimentación", value: 20, color: "#f59e0b" },
  { name: "Reproducción", value: 15, color: "#8b5cf6" },
];

export default function Analytics() {
  const { isAuthenticated } = useAuth();

  if (!isAuthenticated) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Card className="p-8 text-center">
          <p className="text-lg font-semibold">Por favor, inicia sesión</p>
        </Card>
      </div>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold">Análisis y Reportes</h1>
            <p className="text-gray-600 mt-1">Visualiza estadísticas detalladas de tu actividad</p>
          </div>
          <Button>
            <Download className="w-4 h-4 mr-2" />
            Descargar Reporte
          </Button>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Patrones Totales</p>
                <p className="text-3xl font-bold mt-2">1,243</p>
                <p className="text-xs text-green-600 mt-2 flex items-center">
                  <TrendingUp className="w-3 h-3 mr-1" />
                  +12% este mes
                </p>
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <div>
              <p className="text-sm text-gray-600">Precisión Promedio</p>
              <p className="text-3xl font-bold mt-2">89.5%</p>
              <p className="text-xs text-green-600 mt-2">↑ 2.3% vs mes anterior</p>
            </div>
          </Card>

          <Card className="p-6">
            <div>
              <p className="text-sm text-gray-600">Confianza Promedio</p>
              <p className="text-3xl font-bold mt-2">87.2%</p>
              <p className="text-xs text-green-600 mt-2">↑ 1.8% vs mes anterior</p>
            </div>
          </Card>

          <Card className="p-6">
            <div>
              <p className="text-sm text-gray-600">Especies Analizadas</p>
              <p className="text-3xl font-bold mt-2">47</p>
              <p className="text-xs text-blue-600 mt-2">+5 nuevas este mes</p>
            </div>
          </Card>
        </div>

        <Tabs defaultValue="overview" className="w-full">
          <TabsList>
            <TabsTrigger value="overview">Resumen</TabsTrigger>
            <TabsTrigger value="species">Por Especie</TabsTrigger>
            <TabsTrigger value="categories">Por Categoría</TabsTrigger>
            <TabsTrigger value="trends">Tendencias</TabsTrigger>
          </TabsList>

          {/* Overview */}
          <TabsContent value="overview" className="mt-4">
            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-4">Evolución Mensual</h3>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={timeSeriesData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Line type="monotone" dataKey="patterns" stroke="#3b82f6" name="Patrones Detectados" />
                  <Line type="monotone" dataKey="accuracy" stroke="#10b981" name="Precisión %" />
                  <Line type="monotone" dataKey="confidence" stroke="#f59e0b" name="Confianza %" />
                </LineChart>
              </ResponsiveContainer>
            </Card>
          </TabsContent>

          {/* Por Especie */}
          <TabsContent value="species" className="mt-4">
            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-4">Análisis por Especie</h3>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={speciesData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="patterns" fill="#3b82f6" name="Patrones" />
                  <Bar dataKey="confidence" fill="#10b981" name="Confianza %" />
                  <Bar dataKey="accuracy" fill="#f59e0b" name="Precisión %" />
                </BarChart>
              </ResponsiveContainer>

              <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4">
                {speciesData.map((species) => (
                  <Card key={species.name} className="p-4 bg-gray-50">
                    <p className="font-semibold">{species.name}</p>
                    <div className="grid grid-cols-3 gap-2 mt-2 text-sm">
                      <div>
                        <p className="text-gray-600">Patrones</p>
                        <p className="font-bold">{species.patterns}</p>
                      </div>
                      <div>
                        <p className="text-gray-600">Confianza</p>
                        <p className="font-bold">{species.confidence}%</p>
                      </div>
                      <div>
                        <p className="text-gray-600">Precisión</p>
                        <p className="font-bold">{species.accuracy}%</p>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            </Card>
          </TabsContent>

          {/* Por Categoría */}
          <TabsContent value="categories" className="mt-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="p-6">
                <h3 className="text-lg font-semibold mb-4">Distribución de Categorías</h3>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={categoryDistribution}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, value }) => `${name}: ${value}%`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {categoryDistribution.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </Card>

              <Card className="p-6">
                <h3 className="text-lg font-semibold mb-4">Detalles por Categoría</h3>
                <div className="space-y-4">
                  {categoryDistribution.map((category) => (
                    <div key={category.name}>
                      <div className="flex justify-between mb-2">
                        <span className="font-medium">{category.name}</span>
                        <span className="text-sm text-gray-600">{category.value}%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div
                          className="h-2 rounded-full"
                          style={{ width: `${category.value}%`, backgroundColor: category.color }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </Card>
            </div>
          </TabsContent>

          {/* Tendencias */}
          <TabsContent value="trends" className="mt-4">
            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-4">Tendencias Mensuales</h3>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={timeSeriesData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="patterns" fill="#3b82f6" name="Patrones Detectados" />
                </BarChart>
              </ResponsiveContainer>

              <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
                <Card className="p-4 bg-blue-50">
                  <p className="text-sm text-gray-600">Crecimiento Total</p>
                  <p className="text-2xl font-bold text-blue-600 mt-2">75%</p>
                  <p className="text-xs text-gray-600 mt-1">Últimos 6 meses</p>
                </Card>
                <Card className="p-4 bg-green-50">
                  <p className="text-sm text-gray-600">Mejora de Precisión</p>
                  <p className="text-2xl font-bold text-green-600 mt-2">+7%</p>
                  <p className="text-xs text-gray-600 mt-1">Desde enero</p>
                </Card>
                <Card className="p-4 bg-purple-50">
                  <p className="text-sm text-gray-600">Promedio Mensual</p>
                  <p className="text-2xl font-bold text-purple-600 mt-2">172</p>
                  <p className="text-xs text-gray-600 mt-1">Patrones/mes</p>
                </Card>
              </div>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
}
