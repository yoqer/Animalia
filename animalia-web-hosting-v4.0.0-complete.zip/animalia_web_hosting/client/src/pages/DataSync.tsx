import { useAuth } from "@/_core/hooks/useAuth";
import DashboardLayout from "@/components/DashboardLayout";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Upload, Download, RefreshCw, CheckCircle, AlertCircle, Clock, Database } from "lucide-react";
import { useState } from "react";

const mockSyncHistory = [
  { id: 1, type: "upload", source: "Desktop App", items: 45, size: "2.3 MB", status: "completed", date: "2026-02-23 14:30", duration: "2m 15s" },
  { id: 2, type: "download", source: "Web Server", items: 78, size: "4.1 MB", status: "completed", date: "2026-02-23 12:00", duration: "3m 45s" },
  { id: 3, type: "upload", source: "Mobile App", items: 32, size: "1.8 MB", status: "completed", date: "2026-02-22 18:45", duration: "1m 30s" },
  { id: 4, type: "download", source: "Web Server", items: 56, size: "3.2 MB", status: "failed", date: "2026-02-22 10:15", duration: "45s" },
];

const mockBackups = [
  { id: 1, name: "Backup Completo - 2026-02-23", size: "12.5 MB", items: 211, date: "2026-02-23", status: "ready" },
  { id: 2, name: "Backup Completo - 2026-02-20", size: "11.2 MB", items: 189, date: "2026-02-20", status: "ready" },
  { id: 3, name: "Backup Completo - 2026-02-15", size: "10.8 MB", items: 167, date: "2026-02-15", status: "ready" },
];

const getSyncIcon = (type: string) => {
  return type === "upload" ? <Upload className="w-5 h-5 text-blue-500" /> : <Download className="w-5 h-5 text-green-500" />;
};

const getStatusIcon = (status: string) => {
  switch (status) {
    case "completed":
      return <CheckCircle className="w-5 h-5 text-green-500" />;
    case "processing":
      return <Clock className="w-5 h-5 text-blue-500 animate-spin" />;
    case "failed":
      return <AlertCircle className="w-5 h-5 text-red-500" />;
    default:
      return <Clock className="w-5 h-5 text-gray-500" />;
  }
};

const getStatusColor = (status: string) => {
  const colors: Record<string, string> = {
    "completed": "bg-green-100 text-green-800",
    "processing": "bg-blue-100 text-blue-800",
    "failed": "bg-red-100 text-red-800",
    "ready": "bg-green-100 text-green-800",
  };
  return colors[status] || "bg-gray-100 text-gray-800";
};

export default function DataSync() {
  const { isAuthenticated } = useAuth();
  const [syncProgress, setSyncProgress] = useState(0);
  const [isSyncing, setIsSyncing] = useState(false);

  if (!isAuthenticated) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Card className="p-8 text-center">
          <p className="text-lg font-semibold">Por favor, inicia sesión</p>
        </Card>
      </div>
    );
  }

  const handleSync = () => {
    setIsSyncing(true);
    let progress = 0;
    const interval = setInterval(() => {
      progress += Math.random() * 30;
      if (progress >= 100) {
        setSyncProgress(100);
        setIsSyncing(false);
        clearInterval(interval);
      } else {
        setSyncProgress(Math.min(progress, 99));
      }
    }, 500);
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold">Sincronización de Datos</h1>
            <p className="text-gray-600 mt-1">Sincroniza, respalda e importa datos entre dispositivos</p>
          </div>
        </div>

        {/* Sync Status */}
        <Card className="p-6 bg-gradient-to-r from-blue-50 to-blue-100">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold">Sincronización Automática</h3>
              <Badge className="bg-green-100 text-green-800">Activa</Badge>
            </div>
            <p className="text-sm text-gray-700">Última sincronización: hace 2 horas</p>
            {isSyncing && (
              <div>
                <div className="flex justify-between mb-2">
                  <span className="text-sm font-medium">Progreso</span>
                  <span className="text-sm text-gray-600">{Math.round(syncProgress)}%</span>
                </div>
                <Progress value={syncProgress} className="h-2" />
              </div>
            )}
            <Button onClick={handleSync} disabled={isSyncing} className="w-full">
              <RefreshCw className={`w-4 h-4 mr-2 ${isSyncing ? "animate-spin" : ""}`} />
              {isSyncing ? "Sincronizando..." : "Sincronizar Ahora"}
            </Button>
          </div>
        </Card>

        <Tabs defaultValue="history" className="w-full">
          <TabsList>
            <TabsTrigger value="history">Historial de Sincronización</TabsTrigger>
            <TabsTrigger value="backups">Respaldos</TabsTrigger>
            <TabsTrigger value="import">Importar/Exportar</TabsTrigger>
          </TabsList>

          {/* Historial */}
          <TabsContent value="history" className="mt-4">
            <div className="space-y-4">
              {mockSyncHistory.map((sync) => (
                <Card key={sync.id} className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-start gap-4">
                      {getSyncIcon(sync.type)}
                      <div>
                        <h3 className="font-semibold">
                          {sync.type === "upload" ? "Subida desde" : "Descarga desde"} {sync.source}
                        </h3>
                        <p className="text-sm text-gray-600 mt-1">{sync.date}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {getStatusIcon(sync.status)}
                      <Badge className={getStatusColor(sync.status)}>
                        {sync.status === "completed" ? "Completado" : sync.status === "processing" ? "Procesando" : "Error"}
                      </Badge>
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-4 text-sm mb-4">
                    <div>
                      <p className="text-gray-600">Elementos</p>
                      <p className="font-semibold">{sync.items}</p>
                    </div>
                    <div>
                      <p className="text-gray-600">Tamaño</p>
                      <p className="font-semibold">{sync.size}</p>
                    </div>
                    <div>
                      <p className="text-gray-600">Duración</p>
                      <p className="font-semibold">{sync.duration}</p>
                    </div>
                  </div>

                  {sync.status === "failed" && (
                    <Button variant="outline" size="sm" className="text-red-600">
                      Reintentar
                    </Button>
                  )}
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Respaldos */}
          <TabsContent value="backups" className="mt-4">
            <div className="space-y-4">
              <Button className="w-full">
                <Database className="w-4 h-4 mr-2" />
                Crear Respaldo Ahora
              </Button>

              {mockBackups.map((backup) => (
                <Card key={backup.id} className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h3 className="font-semibold">{backup.name}</h3>
                      <p className="text-sm text-gray-600 mt-1">{backup.date}</p>
                    </div>
                    <Badge className={getStatusColor(backup.status)}>
                      {backup.status === "ready" ? "Listo" : "Procesando"}
                    </Badge>
                  </div>

                  <div className="grid grid-cols-2 gap-4 text-sm mb-4">
                    <div>
                      <p className="text-gray-600">Elementos</p>
                      <p className="font-semibold">{backup.items}</p>
                    </div>
                    <div>
                      <p className="text-gray-600">Tamaño</p>
                      <p className="font-semibold">{backup.size}</p>
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <Button variant="outline" size="sm">
                      <Download className="w-4 h-4 mr-2" />
                      Descargar
                    </Button>
                    <Button variant="outline" size="sm">
                      <RefreshCw className="w-4 h-4 mr-2" />
                      Restaurar
                    </Button>
                  </div>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Importar/Exportar */}
          <TabsContent value="import" className="mt-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Exportar */}
              <Card className="p-6">
                <h3 className="text-lg font-semibold mb-4">Exportar Datos</h3>
                <p className="text-sm text-gray-600 mb-4">
                  Descarga todos tus datos en formato JSON para uso local o transferencia
                </p>
                <div className="space-y-3">
                  <Button className="w-full" variant="outline">
                    <Download className="w-4 h-4 mr-2" />
                    Exportar Todo
                  </Button>
                  <Button className="w-full" variant="outline">
                    <Download className="w-4 h-4 mr-2" />
                    Exportar Patrones
                  </Button>
                  <Button className="w-full" variant="outline">
                    <Download className="w-4 h-4 mr-2" />
                    Exportar Conocimiento
                  </Button>
                  <Button className="w-full" variant="outline">
                    <Download className="w-4 h-4 mr-2" />
                    Exportar Conversaciones
                  </Button>
                </div>
              </Card>

              {/* Importar */}
              <Card className="p-6">
                <h3 className="text-lg font-semibold mb-4">Importar Datos</h3>
                <p className="text-sm text-gray-600 mb-4">
                  Carga datos desde archivos JSON o respaldos anteriores
                </p>
                <div className="space-y-3">
                  <Button className="w-full" variant="outline">
                    <Upload className="w-4 h-4 mr-2" />
                    Importar Archivo
                  </Button>
                  <Button className="w-full" variant="outline">
                    <Upload className="w-4 h-4 mr-2" />
                    Importar desde Respaldo
                  </Button>
                  <Button className="w-full" variant="outline">
                    <Upload className="w-4 h-4 mr-2" />
                    Importar desde Desktop
                  </Button>
                </div>
              </Card>
            </div>
          </TabsContent>
        </Tabs>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="p-4">
            <p className="text-sm text-gray-600">Sincronizaciones Totales</p>
            <p className="text-2xl font-bold mt-2">{mockSyncHistory.length}</p>
          </Card>
          <Card className="p-4">
            <p className="text-sm text-gray-600">Exitosas</p>
            <p className="text-2xl font-bold mt-2 text-green-600">
              {mockSyncHistory.filter(s => s.status === "completed").length}
            </p>
          </Card>
          <Card className="p-4">
            <p className="text-sm text-gray-600">Respaldos Disponibles</p>
            <p className="text-2xl font-bold mt-2">{mockBackups.length}</p>
          </Card>
          <Card className="p-4">
            <p className="text-sm text-gray-600">Datos Totales</p>
            <p className="text-2xl font-bold mt-2">36.5 MB</p>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
}
