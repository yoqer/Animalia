import React, { useEffect, useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Activity, Wifi, WifiOff, RefreshCw, AlertCircle } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

interface Device {
  id: string;
  name: string;
  type: 'desktop' | 'web' | 'mobile';
  status: 'online' | 'offline' | 'syncing';
  lastSync: Date;
  syncProgress: number;
}

interface SyncEvent {
  timestamp: Date;
  deviceId: string;
  type: 'upload' | 'download' | 'conflict';
  status: 'success' | 'error' | 'pending';
  itemsCount: number;
}

export default function Monitoring() {
  const [devices, setDevices] = useState<Device[]>([
    {
      id: 'desktop-1',
      name: 'Mi PC Windows',
      type: 'desktop',
      status: 'online',
      lastSync: new Date(Date.now() - 5 * 60000),
      syncProgress: 100,
    },
    {
      id: 'mobile-1',
      name: 'Mi Teléfono',
      type: 'mobile',
      status: 'syncing',
      lastSync: new Date(Date.now() - 2 * 60000),
      syncProgress: 65,
    },
    {
      id: 'web-1',
      name: 'Web Hosting',
      type: 'web',
      status: 'online',
      lastSync: new Date(),
      syncProgress: 100,
    },
  ]);

  const [syncEvents, setSyncEvents] = useState<SyncEvent[]>([
    {
      timestamp: new Date(Date.now() - 10 * 60000),
      deviceId: 'desktop-1',
      type: 'upload',
      status: 'success',
      itemsCount: 12,
    },
    {
      timestamp: new Date(Date.now() - 5 * 60000),
      deviceId: 'mobile-1',
      type: 'download',
      status: 'success',
      itemsCount: 8,
    },
    {
      timestamp: new Date(),
      deviceId: 'web-1',
      type: 'upload',
      status: 'pending',
      itemsCount: 5,
    },
  ]);

  const [chartData, setChartData] = useState<any[]>([
    { time: '00:00', uploads: 0, downloads: 0, conflicts: 0 },
    { time: '04:00', uploads: 5, downloads: 3, conflicts: 0 },
    { time: '08:00', uploads: 12, downloads: 8, conflicts: 1 },
    { time: '12:00', uploads: 18, downloads: 15, conflicts: 2 },
    { time: '16:00', uploads: 25, downloads: 20, conflicts: 1 },
    { time: '20:00', uploads: 32, downloads: 28, conflicts: 0 },
  ]);

  const getStatusIcon = (status: Device['status']) => {
    switch (status) {
      case 'online':
        return <Wifi className="w-4 h-4 text-green-500" />;
      case 'offline':
        return <WifiOff className="w-4 h-4 text-red-500" />;
      case 'syncing':
        return <RefreshCw className="w-4 h-4 text-blue-500 animate-spin" />;
    }
  };

  const getStatusBadge = (status: Device['status']) => {
    switch (status) {
      case 'online':
        return <Badge className="bg-green-100 text-green-800">En línea</Badge>;
      case 'offline':
        return <Badge className="bg-red-100 text-red-800">Sin conexión</Badge>;
      case 'syncing':
        return <Badge className="bg-blue-100 text-blue-800">Sincronizando</Badge>;
    }
  };

  const getEventStatusColor = (status: SyncEvent['status']) => {
    switch (status) {
      case 'success':
        return 'text-green-600';
      case 'error':
        return 'text-red-600';
      case 'pending':
        return 'text-yellow-600';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Activity className="w-6 h-6 text-blue-600" />
          <h1 className="text-2xl font-bold">Monitoreo en Tiempo Real</h1>
        </div>
        <Button variant="outline" size="sm">
          <RefreshCw className="w-4 h-4 mr-2" />
          Actualizar
        </Button>
      </div>

      {/* Resumen de Dispositivos */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="p-4">
          <div className="text-sm text-gray-600 mb-2">Dispositivos En Línea</div>
          <div className="text-3xl font-bold">{devices.filter(d => d.status === 'online').length}</div>
          <div className="text-xs text-gray-500 mt-2">de {devices.length} dispositivos</div>
        </Card>
        <Card className="p-4">
          <div className="text-sm text-gray-600 mb-2">Sincronizaciones Hoy</div>
          <div className="text-3xl font-bold">{syncEvents.length}</div>
          <div className="text-xs text-gray-500 mt-2">
            {syncEvents.filter(e => e.status === 'success').length} exitosas
          </div>
        </Card>
        <Card className="p-4">
          <div className="text-sm text-gray-600 mb-2">Última Sincronización</div>
          <div className="text-3xl font-bold">
            {Math.floor((Date.now() - devices[0].lastSync.getTime()) / 60000)}m
          </div>
          <div className="text-xs text-gray-500 mt-2">hace</div>
        </Card>
      </div>

      {/* Gráfico de Actividad */}
      <Card className="p-6">
        <h2 className="text-lg font-semibold mb-4">Actividad de Sincronización (Últimas 24h)</h2>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="time" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Line type="monotone" dataKey="uploads" stroke="#3b82f6" name="Subidas" />
            <Line type="monotone" dataKey="downloads" stroke="#10b981" name="Descargas" />
            <Line type="monotone" dataKey="conflicts" stroke="#ef4444" name="Conflictos" />
          </LineChart>
        </ResponsiveContainer>
      </Card>

      {/* Lista de Dispositivos */}
      <Card className="p-6">
        <h2 className="text-lg font-semibold mb-4">Dispositivos Conectados</h2>
        <div className="space-y-3">
          {devices.map(device => (
            <div key={device.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <div className="flex items-center gap-3 flex-1">
                {getStatusIcon(device.status)}
                <div className="flex-1">
                  <div className="font-medium">{device.name}</div>
                  <div className="text-xs text-gray-500">
                    Última sincronización: {device.lastSync.toLocaleTimeString()}
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-3">
                {device.status === 'syncing' && (
                  <div className="w-24 bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-blue-500 h-2 rounded-full"
                      style={{ width: `${device.syncProgress}%` }}
                    ></div>
                  </div>
                )}
                {getStatusBadge(device.status)}
              </div>
            </div>
          ))}
        </div>
      </Card>

      {/* Historial de Sincronización */}
      <Card className="p-6">
        <h2 className="text-lg font-semibold mb-4">Historial de Sincronización</h2>
        <div className="space-y-2">
          {syncEvents.map((event, idx) => (
            <div key={idx} className="flex items-center justify-between p-3 border-b last:border-b-0">
              <div className="flex items-center gap-3 flex-1">
                <div className={`text-sm font-medium ${getEventStatusColor(event.status)}`}>
                  {event.type === 'upload' ? '↑' : event.type === 'download' ? '↓' : '⚠'}
                </div>
                <div className="flex-1">
                  <div className="text-sm font-medium">
                    {event.type === 'upload' ? 'Subida' : event.type === 'download' ? 'Descarga' : 'Conflicto'}
                  </div>
                  <div className="text-xs text-gray-500">
                    {devices.find(d => d.id === event.deviceId)?.name} • {event.timestamp.toLocaleTimeString()}
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <span className="text-xs bg-gray-100 px-2 py-1 rounded">{event.itemsCount} items</span>
                {event.status === 'success' && <Badge className="bg-green-100 text-green-800">Exitosa</Badge>}
                {event.status === 'error' && <Badge className="bg-red-100 text-red-800">Error</Badge>}
                {event.status === 'pending' && <Badge className="bg-yellow-100 text-yellow-800">Pendiente</Badge>}
              </div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
