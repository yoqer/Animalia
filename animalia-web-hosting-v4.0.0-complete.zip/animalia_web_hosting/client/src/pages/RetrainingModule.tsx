import { useAuth } from "@/_core/hooks/useAuth";
import DashboardLayout from "@/components/DashboardLayout";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Brain, Play, Download, AlertCircle, CheckCircle, Clock } from "lucide-react";
import { useState } from "react";

const mockRetrainingRequests = [
  {
    id: 1,
    modelType: "vision",
    status: "processing",
    progress: 65,
    priority: "high",
    createdAt: "2026-02-23",
    updatedAt: "2026-02-23",
    trainingData: "500 muestras de comportamiento",
  },
  {
    id: 2,
    modelType: "chat",
    status: "completed",
    progress: 100,
    priority: "normal",
    createdAt: "2026-02-22",
    updatedAt: "2026-02-23",
    trainingData: "1000 conversaciones",
  },
  {
    id: 3,
    modelType: "vision",
    status: "pending",
    progress: 0,
    priority: "normal",
    createdAt: "2026-02-21",
    updatedAt: "2026-02-21",
    trainingData: "300 muestras nuevas",
  },
];

const getStatusIcon = (status: string) => {
  switch (status) {
    case "completed":
      return <CheckCircle className="w-5 h-5 text-green-500" />;
    case "processing":
      return <Clock className="w-5 h-5 text-blue-500 animate-spin" />;
    case "failed":
      return <AlertCircle className="w-5 h-5 text-red-500" />;
    default:
      return <Clock className="w-5 h-5 text-gray-500" />;
  }
};

const getStatusColor = (status: string) => {
  const colors: Record<string, string> = {
    "completed": "bg-green-100 text-green-800",
    "processing": "bg-blue-100 text-blue-800",
    "pending": "bg-yellow-100 text-yellow-800",
    "failed": "bg-red-100 text-red-800",
  };
  return colors[status] || "bg-gray-100 text-gray-800";
};

export default function RetrainingModule() {
  const { isAuthenticated } = useAuth();
  const [modelType, setModelType] = useState("vision");
  const [trainingData, setTrainingData] = useState("");
  const [weights, setWeights] = useState("");
  const [priority, setPriority] = useState("normal");

  if (!isAuthenticated) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Card className="p-8 text-center">
          <p className="text-lg font-semibold">Por favor, inicia sesión</p>
        </Card>
      </div>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold">Módulo de Reentrenamiento</h1>
            <p className="text-gray-600 mt-1">Solicita y monitorea el reentrenamiento de modelos</p>
          </div>
        </div>

        <Tabs defaultValue="request" className="w-full">
          <TabsList>
            <TabsTrigger value="request">Nueva Solicitud</TabsTrigger>
            <TabsTrigger value="history">Historial</TabsTrigger>
          </TabsList>

          {/* Nueva Solicitud */}
          <TabsContent value="request" className="mt-4">
            <Card className="p-6">
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-medium mb-2">Tipo de Modelo</label>
                  <select
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    value={modelType}
                    onChange={(e) => setModelType(e.target.value)}
                  >
                    <option value="vision">Visión (Análisis de Comportamiento)</option>
                    <option value="chat">Chat (RAG)</option>
                    <option value="all">Todos los Modelos</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Prioridad</label>
                  <select
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    value={priority}
                    onChange={(e) => setPriority(e.target.value)}
                  >
                    <option value="normal">Normal</option>
                    <option value="high">Alta</option>
                    <option value="urgent">Urgente</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Datos de Entrenamiento (JSON)</label>
                  <Textarea
                    placeholder='{"samples": 100, "categories": ["comunicacion", "comportamiento"]}'
                    value={trainingData}
                    onChange={(e) => setTrainingData(e.target.value)}
                    rows={5}
                  />
                  <p className="text-xs text-gray-500 mt-1">Proporciona datos en formato JSON</p>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Pesos Personalizados (JSON)</label>
                  <Textarea
                    placeholder='{"learning_rate": 0.001, "batch_size": 32}'
                    value={weights}
                    onChange={(e) => setWeights(e.target.value)}
                    rows={4}
                  />
                  <p className="text-xs text-gray-500 mt-1">Opcional: Define pesos personalizados para el entrenamiento</p>
                </div>

                <Button className="w-full" size="lg">
                  <Brain className="w-4 h-4 mr-2" />
                  Solicitar Reentrenamiento
                </Button>
              </div>
            </Card>
          </TabsContent>

          {/* Historial */}
          <TabsContent value="history" className="mt-4">
            <div className="space-y-4">
              {mockRetrainingRequests.map((request) => (
                <Card key={request.id} className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center gap-3">
                      {getStatusIcon(request.status)}
                      <div>
                        <h3 className="font-semibold">
                          {request.modelType === "vision" ? "Análisis de Comportamiento" : "Chat RAG"}
                        </h3>
                        <p className="text-sm text-gray-600">{request.trainingData}</p>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Badge className={getStatusColor(request.status)}>
                        {request.status === "completed" ? "Completado" : request.status === "processing" ? "Procesando" : "Pendiente"}
                      </Badge>
                      <Badge variant="outline">{request.priority}</Badge>
                    </div>
                  </div>

                  {request.status !== "pending" && (
                    <div className="mb-4">
                      <div className="flex justify-between mb-2">
                        <span className="text-sm font-medium">Progreso</span>
                        <span className="text-sm text-gray-600">{request.progress}%</span>
                      </div>
                      <Progress value={request.progress} className="h-2" />
                    </div>
                  )}

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm mb-4">
                    <div>
                      <p className="text-gray-600">Creado</p>
                      <p className="font-medium">{request.createdAt}</p>
                    </div>
                    <div>
                      <p className="text-gray-600">Actualizado</p>
                      <p className="font-medium">{request.updatedAt}</p>
                    </div>
                    <div>
                      <p className="text-gray-600">Tipo</p>
                      <p className="font-medium">{request.modelType}</p>
                    </div>
                    <div>
                      <p className="text-gray-600">Estado</p>
                      <p className="font-medium capitalize">{request.status}</p>
                    </div>
                  </div>

                  {request.status === "completed" && (
                    <Button variant="outline" className="w-full">
                      <Download className="w-4 h-4 mr-2" />
                      Descargar Modelo
                    </Button>
                  )}
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="p-4">
            <p className="text-sm text-gray-600">Total de Solicitudes</p>
            <p className="text-2xl font-bold mt-2">{mockRetrainingRequests.length}</p>
          </Card>
          <Card className="p-4">
            <p className="text-sm text-gray-600">Completadas</p>
            <p className="text-2xl font-bold mt-2 text-green-600">
              {mockRetrainingRequests.filter(r => r.status === "completed").length}
            </p>
          </Card>
          <Card className="p-4">
            <p className="text-sm text-gray-600">En Proceso</p>
            <p className="text-2xl font-bold mt-2 text-blue-600">
              {mockRetrainingRequests.filter(r => r.status === "processing").length}
            </p>
          </Card>
          <Card className="p-4">
            <p className="text-sm text-gray-600">Pendientes</p>
            <p className="text-2xl font-bold mt-2 text-yellow-600">
              {mockRetrainingRequests.filter(r => r.status === "pending").length}
            </p>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
}
