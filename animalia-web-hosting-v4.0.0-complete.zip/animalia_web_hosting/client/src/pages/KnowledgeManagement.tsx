import { useAuth } from "@/_core/hooks/useAuth";
import DashboardLayout from "@/components/DashboardLayout";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Upload, Download, Plus, Trash2, Edit2, FileJson, Database, Clock } from "lucide-react";
import { useState } from "react";

const mockKnowledgeBase = [
  { id: 1, name: "Patrones de Comunicación Felina", category: "Comunicación", items: 45, size: "2.3 MB", createdAt: "2026-02-20", status: "active" },
  { id: 2, name: "Comportamiento de Manadas de Lobos", category: "Comportamiento", items: 78, size: "4.1 MB", createdAt: "2026-02-18", status: "active" },
  { id: 3, name: "Patrones de Alimentación de Osos", category: "Alimentación", items: 32, size: "1.8 MB", createdAt: "2026-02-15", status: "processing" },
  { id: 4, name: "Señales de Reproducción Equina", category: "Reproducción", items: 56, size: "3.2 MB", createdAt: "2026-02-10", status: "active" },
];

export default function KnowledgeManagement() {
  const { isAuthenticated } = useAuth();
  const [newKnowledge, setNewKnowledge] = useState({ name: "", category: "", data: "" });
  const [selectedFile, setSelectedFile] = useState<File | null>(null);

  if (!isAuthenticated) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Card className="p-8 text-center">
          <p className="text-lg font-semibold">Por favor, inicia sesión</p>
        </Card>
      </div>
    );
  }

  const getStatusColor = (status: string) => {
    const colors: Record<string, string> = {
      "active": "bg-green-100 text-green-800",
      "processing": "bg-blue-100 text-blue-800",
      "archived": "bg-gray-100 text-gray-800",
    };
    return colors[status] || "bg-gray-100 text-gray-800";
  };

  const getStatusLabel = (status: string) => {
    const labels: Record<string, string> = {
      "active": "Activo",
      "processing": "Procesando",
      "archived": "Archivado",
    };
    return labels[status] || status;
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold">Gestión de Conocimiento</h1>
            <p className="text-gray-600 mt-1">Administra la base de conocimiento para entrenamientos</p>
          </div>
        </div>

        <Tabs defaultValue="library" className="w-full">
          <TabsList>
            <TabsTrigger value="library">Biblioteca</TabsTrigger>
            <TabsTrigger value="import">Importar Datos</TabsTrigger>
            <TabsTrigger value="create">Crear Nuevo</TabsTrigger>
          </TabsList>

          {/* Biblioteca */}
          <TabsContent value="library" className="mt-4">
            <div className="space-y-4">
              {mockKnowledgeBase.map((kb) => (
                <Card key={kb.id} className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-start gap-4 flex-1">
                      <Database className="w-8 h-8 text-blue-500 mt-1" />
                      <div className="flex-1">
                        <h3 className="text-lg font-semibold">{kb.name}</h3>
                        <p className="text-sm text-gray-600 mt-1">{kb.category}</p>
                      </div>
                    </div>
                    <Badge className={getStatusColor(kb.status)}>
                      {getStatusLabel(kb.status)}
                    </Badge>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4 text-sm">
                    <div>
                      <p className="text-gray-600">Elementos</p>
                      <p className="font-semibold">{kb.items}</p>
                    </div>
                    <div>
                      <p className="text-gray-600">Tamaño</p>
                      <p className="font-semibold">{kb.size}</p>
                    </div>
                    <div>
                      <p className="text-gray-600">Creado</p>
                      <p className="font-semibold">{kb.createdAt}</p>
                    </div>
                    <div>
                      <p className="text-gray-600">Versión</p>
                      <p className="font-semibold">v1.0</p>
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <Button variant="outline" size="sm">
                      <Download className="w-4 h-4 mr-2" />
                      Descargar
                    </Button>
                    <Button variant="outline" size="sm">
                      <Edit2 className="w-4 h-4 mr-2" />
                      Editar
                    </Button>
                    <Button variant="outline" size="sm" className="text-red-600">
                      <Trash2 className="w-4 h-4 mr-2" />
                      Eliminar
                    </Button>
                  </div>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Importar Datos */}
          <TabsContent value="import" className="mt-4">
            <Card className="p-6">
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-medium mb-4">Cargar Archivo de Datos</label>
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                    <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-600 mb-2">Arrastra archivos aquí o haz clic para seleccionar</p>
                    <p className="text-sm text-gray-500 mb-4">Formatos soportados: JSON, CSV, TXT, XLSX</p>
                    <input
                      type="file"
                      className="hidden"
                      accept=".json,.csv,.txt,.xlsx"
                      onChange={(e) => setSelectedFile(e.target.files?.[0] || null)}
                    />
                    <Button variant="outline">
                      Seleccionar Archivo
                    </Button>
                    {selectedFile && (
                      <p className="text-sm text-green-600 mt-2">✓ {selectedFile.name}</p>
                    )}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Nombre del Conjunto de Datos</label>
                  <Input
                    placeholder="Ej: Patrones de Comunicación Felina"
                    value={newKnowledge.name}
                    onChange={(e) => setNewKnowledge({ ...newKnowledge, name: e.target.value })}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Categoría</label>
                  <select className="w-full px-3 py-2 border border-gray-300 rounded-md">
                    <option>Comunicación</option>
                    <option>Comportamiento</option>
                    <option>Alimentación</option>
                    <option>Reproducción</option>
                    <option>Otra</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Descripción (Opcional)</label>
                  <Textarea
                    placeholder="Describe el contenido y propósito de este conjunto de datos..."
                    rows={4}
                  />
                </div>

                <Button className="w-full" size="lg">
                  <Upload className="w-4 h-4 mr-2" />
                  Importar Datos
                </Button>
              </div>
            </Card>
          </TabsContent>

          {/* Crear Nuevo */}
          <TabsContent value="create" className="mt-4">
            <Card className="p-6">
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-medium mb-2">Nombre del Conjunto</label>
                  <Input
                    placeholder="Ej: Nuevos Patrones de Comportamiento"
                    value={newKnowledge.name}
                    onChange={(e) => setNewKnowledge({ ...newKnowledge, name: e.target.value })}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Categoría</label>
                  <select
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    value={newKnowledge.category}
                    onChange={(e) => setNewKnowledge({ ...newKnowledge, category: e.target.value })}
                  >
                    <option value="">Seleccionar categoría</option>
                    <option value="comunicacion">Comunicación</option>
                    <option value="comportamiento">Comportamiento</option>
                    <option value="alimentacion">Alimentación</option>
                    <option value="reproduccion">Reproducción</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Datos (JSON)</label>
                  <Textarea
                    placeholder='{&#10;  "patterns": [&#10;    {"species": "Panthera leo", "behavior": "Rugido territorial", "confidence": 0.95}&#10;  ]&#10;}'
                    value={newKnowledge.data}
                    onChange={(e) => setNewKnowledge({ ...newKnowledge, data: e.target.value })}
                    rows={8}
                    className="font-mono text-sm"
                  />
                  <p className="text-xs text-gray-500 mt-2">Proporciona datos en formato JSON válido</p>
                </div>

                <Button className="w-full" size="lg">
                  <Plus className="w-4 h-4 mr-2" />
                  Crear Conjunto de Datos
                </Button>
              </div>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="p-4">
            <p className="text-sm text-gray-600">Total de Conjuntos</p>
            <p className="text-2xl font-bold mt-2">{mockKnowledgeBase.length}</p>
          </Card>
          <Card className="p-4">
            <p className="text-sm text-gray-600">Elementos Totales</p>
            <p className="text-2xl font-bold mt-2">
              {mockKnowledgeBase.reduce((sum, kb) => sum + kb.items, 0)}
            </p>
          </Card>
          <Card className="p-4">
            <p className="text-sm text-gray-600">Tamaño Total</p>
            <p className="text-2xl font-bold mt-2">11.4 MB</p>
          </Card>
          <Card className="p-4">
            <p className="text-sm text-gray-600">Activos</p>
            <p className="text-2xl font-bold mt-2 text-green-600">
              {mockKnowledgeBase.filter(kb => kb.status === "active").length}
            </p>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
}
