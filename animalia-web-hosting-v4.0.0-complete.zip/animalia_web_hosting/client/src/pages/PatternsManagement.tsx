import { useAuth } from "@/_core/hooks/useAuth";
import DashboardLayout from "@/components/DashboardLayout";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Search, Plus, Edit2, Trash2, Filter } from "lucide-react";
import { useState } from "react";

const mockPatterns = [
  { id: 1, species: "Panthera leo", category: "Comunicación", pattern: "Rugido territorial", confidence: 95, date: "2026-02-20" },
  { id: 2, species: "Canis lupus", category: "Comportamiento", pattern: "Aullido de manada", confidence: 88, date: "2026-02-19" },
  { id: 3, species: "Ursus arctos", category: "Alimentación", pattern: "Búsqueda de salmón", confidence: 92, date: "2026-02-18" },
  { id: 4, species: "Equus ferus", category: "Reproducción", pattern: "Relincho de apareamiento", confidence: 85, date: "2026-02-17" },
  { id: 5, species: "Panthera leo", category: "Comunicación", pattern: "Gruñido de advertencia", confidence: 90, date: "2026-02-16" },
];

const getCategoryColor = (category: string) => {
  const colors: Record<string, string> = {
    "Comunicación": "bg-blue-100 text-blue-800",
    "Comportamiento": "bg-green-100 text-green-800",
    "Alimentación": "bg-orange-100 text-orange-800",
    "Reproducción": "bg-purple-100 text-purple-800",
  };
  return colors[category] || "bg-gray-100 text-gray-800";
};

export default function PatternsManagement() {
  const { isAuthenticated } = useAuth();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("Todas");

  const filteredPatterns = mockPatterns.filter(pattern => {
    const matchesSearch = pattern.species.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         pattern.pattern.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === "Todas" || pattern.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  if (!isAuthenticated) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Card className="p-8 text-center">
          <p className="text-lg font-semibold">Por favor, inicia sesión</p>
        </Card>
      </div>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold">Gestión de Patrones</h1>
            <p className="text-gray-600 mt-1">Administra los patrones de comportamiento animal detectados</p>
          </div>
          <Button>
            <Plus className="w-4 h-4 mr-2" />
            Nuevo Patrón
          </Button>
        </div>

        {/* Filters */}
        <Card className="p-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
              <Input
                placeholder="Buscar por especie o patrón..."
                className="pl-10"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <div className="flex gap-2">
              <Filter className="w-4 h-4 mt-3 text-gray-400" />
              <select
                className="flex-1 px-3 py-2 border border-gray-300 rounded-md"
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
              >
                <option>Todas</option>
                <option>Comunicación</option>
                <option>Comportamiento</option>
                <option>Alimentación</option>
                <option>Reproducción</option>
              </select>
            </div>
          </div>
        </Card>

        {/* Table */}
        <Card className="overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Especie</TableHead>
                <TableHead>Patrón</TableHead>
                <TableHead>Categoría</TableHead>
                <TableHead>Confianza</TableHead>
                <TableHead>Fecha</TableHead>
                <TableHead>Acciones</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredPatterns.map((pattern) => (
                <TableRow key={pattern.id}>
                  <TableCell className="font-medium">{pattern.species}</TableCell>
                  <TableCell>{pattern.pattern}</TableCell>
                  <TableCell>
                    <Badge className={getCategoryColor(pattern.category)}>
                      {pattern.category}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <div className="w-16 bg-gray-200 rounded-full h-2">
                        <div
                          className="bg-green-500 h-2 rounded-full"
                          style={{ width: `${pattern.confidence}%` }}
                        />
                      </div>
                      <span className="text-sm font-medium">{pattern.confidence}%</span>
                    </div>
                  </TableCell>
                  <TableCell className="text-sm text-gray-600">{pattern.date}</TableCell>
                  <TableCell>
                    <div className="flex gap-2">
                      <Button variant="ghost" size="sm">
                        <Edit2 className="w-4 h-4" />
                      </Button>
                      <Button variant="ghost" size="sm">
                        <Trash2 className="w-4 h-4 text-red-500" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Card>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card className="p-4">
            <p className="text-sm text-gray-600">Total de Patrones</p>
            <p className="text-2xl font-bold mt-2">{filteredPatterns.length}</p>
          </Card>
          <Card className="p-4">
            <p className="text-sm text-gray-600">Confianza Promedio</p>
            <p className="text-2xl font-bold mt-2">
              {(filteredPatterns.reduce((sum, p) => sum + p.confidence, 0) / filteredPatterns.length).toFixed(1)}%
            </p>
          </Card>
          <Card className="p-4">
            <p className="text-sm text-gray-600">Especies Únicas</p>
            <p className="text-2xl font-bold mt-2">
              {new Set(filteredPatterns.map(p => p.species)).size}
            </p>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
}
