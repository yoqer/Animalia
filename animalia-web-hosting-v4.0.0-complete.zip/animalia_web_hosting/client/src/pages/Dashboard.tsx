import { useAuth } from "@/_core/hooks/useAuth";
import DashboardLayout from "@/components/DashboardLayout";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, LineChart, Line } from "recharts";
import { Activity, Database, Brain, TrendingUp, Download, Upload } from "lucide-react";

const mockPatternsData = [
  { species: "Panthera leo", count: 45, confidence: 92 },
  { species: "Canis lupus", count: 38, confidence: 88 },
  { species: "Ursus arctos", count: 32, confidence: 85 },
  { species: "Equus ferus", count: 28, confidence: 90 },
];

const mockSyncData = [
  { date: "Lun", uploads: 12, downloads: 8 },
  { date: "Mar", uploads: 19, downloads: 14 },
  { date: "Mié", uploads: 15, downloads: 11 },
  { date: "Jue", uploads: 22, downloads: 18 },
  { date: "Vie", uploads: 18, downloads: 16 },
];

export default function Dashboard() {
  const { user, isAuthenticated } = useAuth();

  if (!isAuthenticated) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Card className="p-8 text-center">
          <p className="text-lg font-semibold mb-4">Por favor, inicia sesión para acceder al dashboard</p>
        </Card>
      </div>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold">Dashboard</h1>
            <p className="text-gray-600 mt-1">Bienvenido, {user?.name}</p>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Patrones Detectados</p>
                <p className="text-2xl font-bold mt-2">142</p>
              </div>
              <Activity className="w-8 h-8 text-blue-500" />
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Base de Conocimiento</p>
                <p className="text-2xl font-bold mt-2">56</p>
              </div>
              <Database className="w-8 h-8 text-green-500" />
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Solicitudes de Reentreno</p>
                <p className="text-2xl font-bold mt-2">8</p>
              </div>
              <Brain className="w-8 h-8 text-purple-500" />
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Confianza Promedio</p>
                <p className="text-2xl font-bold mt-2">89%</p>
              </div>
              <TrendingUp className="w-8 h-8 text-orange-500" />
            </div>
          </Card>
        </div>

        {/* Charts */}
        <Tabs defaultValue="patterns" className="w-full">
          <TabsList>
            <TabsTrigger value="patterns">Patrones por Especie</TabsTrigger>
            <TabsTrigger value="sync">Historial de Sincronización</TabsTrigger>
          </TabsList>

          <TabsContent value="patterns" className="mt-4">
            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-4">Patrones Detectados por Especie</h3>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={mockPatternsData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="species" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="count" fill="#3b82f6" name="Patrones" />
                  <Bar dataKey="confidence" fill="#10b981" name="Confianza %" />
                </BarChart>
              </ResponsiveContainer>
            </Card>
          </TabsContent>

          <TabsContent value="sync" className="mt-4">
            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-4">Actividad de Sincronización</h3>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={mockSyncData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Line type="monotone" dataKey="uploads" stroke="#3b82f6" name="Subidas" />
                  <Line type="monotone" dataKey="downloads" stroke="#10b981" name="Descargas" />
                </LineChart>
              </ResponsiveContainer>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Quick Actions */}
        <Card className="p-6">
          <h3 className="text-lg font-semibold mb-4">Acciones Rápidas</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Button className="w-full" variant="outline">
              <Upload className="w-4 h-4 mr-2" />
              Subir Datos
            </Button>
            <Button className="w-full" variant="outline">
              <Download className="w-4 h-4 mr-2" />
              Descargar Datos
            </Button>
            <Button className="w-full" variant="outline">
              <Brain className="w-4 h-4 mr-2" />
              Solicitar Reentreno
            </Button>
          </div>
        </Card>
      </div>
    </DashboardLayout>
  );
}
