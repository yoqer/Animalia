# 🔧 Manual Alternativo - Despliegue Manual Paso a Paso

**Para cuando el script automático no funciona o necesitas más control**

---

## 📋 Checklist Inicial

Antes de comenzar, verifica:

```bash
# 1. Node.js instalado
node --version
# Esperado: v18.0.0 o superior

# 2. pnpm instalado
pnpm --version
# Esperado: 8.0.0 o superior

# 3. MySQL ejecutándose
mysql -u root -p
# Debería conectar sin error

# 4. Git (opcional)
git --version
```

---

## 🎯 Paso 1: Preparar Directorio y Archivos

### 1.1 Crear estructura de directorios

```bash
# Crear carpeta principal
mkdir -p /home/usuario/animalia_web_hosting
cd /home/usuario/animalia_web_hosting

# Crear carpetas necesarias
mkdir -p client/src
mkdir -p server
mkdir -p drizzle
mkdir -p logs
mkdir -p backups
```

### 1.2 Crear archivo `.env`

**IMPORTANTE**: Este archivo contiene credenciales. Nunca lo compartas.

```bash
# Crear archivo .env
cat > .env << 'EOF'
# Base de Datos
DATABASE_URL=mysql://usuario:contraseña@localhost:3306/animalia

# Seguridad
JWT_SECRET=tu_secreto_muy_largo_y_aleatorio_aqui_12345678901234567890

# OAuth (si usas Manus)
VITE_APP_ID=tu_app_id_aqui
OAUTH_SERVER_URL=https://api.manus.im
VITE_OAUTH_PORTAL_URL=https://login.manus.im

# URLs
VITE_FRONTEND_FORGE_API_URL=http://localhost:3000
BUILT_IN_FORGE_API_URL=http://localhost:3000

# Claves API
VITE_FRONTEND_FORGE_API_KEY=tu_api_key_aqui
BUILT_IN_FORGE_API_KEY=tu_api_key_aqui

# Información del propietario
OWNER_NAME=Tu Nombre
OWNER_OPEN_ID=tu_open_id

# Analíticas
VITE_ANALYTICS_ENDPOINT=http://localhost:3000/analytics
VITE_ANALYTICS_WEBSITE_ID=animalia

# Aplicación
VITE_APP_TITLE=Animalia - Sistema de Comunicación Multi-Especies
VITE_APP_LOGO=/logo.png
EOF

chmod 600 .env  # Solo tú puedes leer este archivo
```

**Explicación de variables**:

| Variable | Qué es | Ejemplo |
|----------|--------|---------|
| `DATABASE_URL` | Conexión a MySQL | `mysql://root:password@localhost:3306/animalia` |
| `JWT_SECRET` | Clave para tokens | Algo aleatorio y largo |
| `VITE_APP_ID` | ID de aplicación | Proporcionado por Manus |
| `OWNER_NAME` | Tu nombre | "Juan Pérez" |

---

## 🎯 Paso 2: Instalar Dependencias

### 2.1 Instalar pnpm (si no lo tienes)

```bash
# Opción 1: Con npm
npm install -g pnpm

# Opción 2: Con curl (Linux/Mac)
curl -fsSL https://get.pnpm.io/install.sh | sh -

# Verificar
pnpm --version
```

### 2.2 Instalar dependencias del proyecto

```bash
cd /home/usuario/animalia_web_hosting

# Instalar todos los paquetes
pnpm install

# Esto descarga ~500 MB
# Toma 5-10 minutos
# Verás muchas líneas, es normal
```

**¿Qué sucede?**
- Se crea carpeta `node_modules/` con todas las librerías
- Se crea archivo `pnpm-lock.yaml` (no editar)

---

## 🎯 Paso 3: Configurar Base de Datos

### 3.1 Crear base de datos MySQL

```bash
# Conectar a MySQL
mysql -u root -p

# Dentro de MySQL, ejecutar:
CREATE DATABASE animalia CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'animalia_user'@'localhost' IDENTIFIED BY 'contraseña_segura';
GRANT ALL PRIVILEGES ON animalia.* TO 'animalia_user'@'localhost';
FLUSH PRIVILEGES;
EXIT;
```

**Actualizar `.env` con credenciales**:
```
DATABASE_URL=mysql://animalia_user:contraseña_segura@localhost:3306/animalia
```

### 3.2 Generar migraciones

```bash
cd /home/usuario/animalia_web_hosting

# Generar migraciones basadas en schema.ts
pnpm exec drizzle-kit generate

# Output esperado:
# [✓] Your SQL migration file ➜ drizzle/0001_*.sql
```

### 3.3 Aplicar migraciones a la BD

```bash
# Aplicar cambios a la base de datos
pnpm exec drizzle-kit migrate

# Output esperado:
# [✓] Migrations applied successfully
```

**Verificar que las tablas se crearon**:

```bash
mysql -u animalia_user -p animalia

# Dentro de MySQL:
SHOW TABLES;

# Deberías ver:
# animal_patterns
# conversations
# knowledge
# retraining_requests
# sync_history
# users
```

---

## 🎯 Paso 4: Compilar el Proyecto

### 4.1 Validar TypeScript

```bash
cd /home/usuario/animalia_web_hosting

# Verificar que no hay errores de tipo
pnpm run check

# Output esperado: "No errors found"
```

### 4.2 Compilar para producción

```bash
# Compilar código
pnpm run build

# Esto crea carpeta 'dist/' con código optimizado
# Toma 2-5 minutos
```

**Verificar compilación**:
```bash
ls -la dist/
# Deberías ver archivos .js y .css
```

---

## 🎯 Paso 5: Ejecutar Tests (Recomendado)

```bash
cd /home/usuario/animalia_web_hosting

# Ejecutar tests automáticos
pnpm run test

# Verifica que todo funcione correctamente
# Output: "X tests passed"
```

---

## 🎯 Paso 6: Iniciar Servidor

### 6.1 Desarrollo (para pruebas)

```bash
cd /home/usuario/animalia_web_hosting

# Iniciar servidor de desarrollo
pnpm run dev

# Output esperado:
# Server running on http://localhost:3000/
# [OAuth] Initialized with baseURL: https://api.manus.im
```

**Acceder a la aplicación**:
- Abre navegador: `http://localhost:3000`
- Deberías ver la página de login

### 6.2 Producción (para desplegar)

```bash
cd /home/usuario/animalia_web_hosting

# Compilar
pnpm run build

# Iniciar servidor compilado
pnpm run start

# Output esperado:
# Server running on http://localhost:3000/
```

---

## 🧪 Paso 7: Verificar Comunicación

### 7.1 Verificar API de Sincronización

**Archivo de prueba**: `test-sync-api.js`

```javascript
// test-sync-api.js
const http = require('http');

function testEndpoint(path, method = 'GET') {
  return new Promise((resolve) => {
    const options = {
      hostname: 'localhost',
      port: 3000,
      path: path,
      method: method,
      headers: {
        'Content-Type': 'application/json'
      }
    };

    const req = http.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        console.log(`${method} ${path}: ${res.statusCode}`);
        resolve(res.statusCode);
      });
    });

    req.on('error', () => {
      console.log(`${method} ${path}: ❌ Error de conexión`);
      resolve(null);
    });

    req.end();
  });
}

async function runTests() {
  console.log('🧪 Probando endpoints de Animalia...\n');
  
  await testEndpoint('/api/trpc/auth.me');
  await testEndpoint('/api/trpc/sync.getPatterns');
  await testEndpoint('/api/trpc/sync.getKnowledge');
  await testEndpoint('/api/trpc/sync.getConversations');
  
  console.log('\n✅ Pruebas completadas');
}

runTests();
```

**Ejecutar**:
```bash
node test-sync-api.js
```

### 7.2 Verificar WebSocket

**En consola del navegador (F12)**:

```javascript
// Conectar a WebSocket
const socket = io('http://localhost:3000');

socket.on('connect', () => {
  console.log('✅ WebSocket conectado');
});

socket.on('disconnect', () => {
  console.log('❌ WebSocket desconectado');
});

// Enviar ping
socket.emit('ping');
```

---

## 🔍 Monitoreo y Logs

### Ver logs en tiempo real

```bash
# Logs del servidor
tail -f .manus-logs/devserver.log

# Buscar errores específicos
grep "ERROR" .manus-logs/devserver.log

# Buscar sincronización
grep "sync" .manus-logs/devserver.log
```

### Estadísticas de caché

```bash
# En consola del navegador
wsClient.getCacheStats()

// Output:
// {
//   entries: 45,
//   size: 12345,
//   connected: true
// }
```

---

## 🚨 Problemas y Soluciones

### Problema: "Cannot find module 'socket.io'"

**Solución**:
```bash
pnpm add socket.io
pnpm install
```

### Problema: "EADDRINUSE: address already in use :::3000"

**Solución**:
```bash
# Encontrar proceso en puerto 3000
lsof -i :3000

# Matar proceso (reemplaza PID)
kill -9 <PID>

# O usar puerto diferente
PORT=3001 pnpm dev
```

### Problema: "Access denied for user 'animalia_user'@'localhost'"

**Solución**:
```bash
# Verificar credenciales en .env
cat .env | grep DATABASE_URL

# Verificar usuario en MySQL
mysql -u root -p
SHOW GRANTS FOR 'animalia_user'@'localhost';
```

### Problema: "ENOENT: no such file or directory, open '.env'"

**Solución**:
```bash
# Crear archivo .env
touch .env

# Agregar contenido (ver Paso 1.2)
```

---

## 📊 Checklist de Despliegue

Antes de considerar "listo para producción":

- [ ] `.env` configurado correctamente
- [ ] Base de datos creada y migraciones aplicadas
- [ ] `pnpm install` completado sin errores
- [ ] `pnpm run build` genera carpeta `dist/`
- [ ] `pnpm run test` pasa todos los tests
- [ ] Servidor inicia con `pnpm run dev` o `pnpm run start`
- [ ] Puedes acceder a `http://localhost:3000`
- [ ] API de sincronización responde (test-sync-api.js)
- [ ] WebSocket conecta correctamente
- [ ] Caché local funciona

---

## 🎯 Archivos Clave para Verificación

Si necesitas verificar comunicación Desktop-Web:

### 1. **Servidor WebSocket**: `server/websocket.ts`

```typescript
// Líneas clave:
// 60: io.on("connection", (socket: any) => {
// 70: socket.on("sync:request", (data: { since?: Date }) => {
// 85: socket.on("sync:upload", (message: SyncMessage) => {
```

### 2. **API de Sincronización**: `server/routers/sync.ts`

```typescript
// Líneas clave:
// 10: getPatterns: protectedProcedure.query(...)
// 50: uploadPatterns: protectedProcedure.mutation(...)
// 150: fullSync: protectedProcedure.query(...)
```

### 3. **Cliente WebSocket (Desktop)**: `src/lib/websocketClient.ts`

```typescript
// Líneas clave:
// 35: connect(token: string): Promise<void>
// 80: async requestSync(since?: Date): Promise<any>
// 100: async uploadData(message: SyncMessage): Promise<void>
```

### 4. **Hook de Sincronización (Web)**: `client/src/hooks/useSyncManager.ts`

```typescript
// Líneas clave:
// 29: const syncPatterns = trpc.sync.getPatterns.useQuery(...)
// 50: const uploadPatterns = trpc.sync.uploadPatterns.useMutation();
// 114: useEffect(() => { performSync(); }, ...)
```

---

## 📞 Verificación de Comunicación

**Paso a paso para verificar que Desktop y Web se comunican**:

1. **Abre navegador**: `http://localhost:3000`
2. **Abre consola**: F12 → Pestaña "Console"
3. **Ejecuta**:
   ```javascript
   // Ver si WebSocket está conectado
   console.log(wsClient.isConnected());
   
   // Ver estadísticas de caché
   console.log(wsClient.getCacheStats());
   
   // Intentar sincronización
   wsClient.requestSync().then(data => console.log('Sync OK', data));
   ```

4. **Verifica logs del servidor**:
   ```bash
   grep "WebSocket\|sync" .manus-logs/devserver.log
   ```

---

## 🎓 Próximos Pasos

1. **Configurar HTTPS**: Necesario para producción
2. **Configurar dominio**: Apunta tu dominio al servidor
3. **Configurar backups**: Automatizar respaldos de BD
4. **Monitoreo**: Configurar alertas para errores
5. **Escalado**: Preparar para múltiples usuarios

---

## 💾 Crear Backup Manual

```bash
# Backup de base de datos
mysqldump -u animalia_user -p animalia > backup_$(date +%Y%m%d_%H%M%S).sql

# Backup de proyecto
tar -czf animalia_backup_$(date +%Y%m%d_%H%M%S).tar.gz \
  --exclude=node_modules \
  --exclude=dist \
  /home/usuario/animalia_web_hosting
```

---

**¡Listo! Ahora tienes Animalia funcionando completamente.** ✅

