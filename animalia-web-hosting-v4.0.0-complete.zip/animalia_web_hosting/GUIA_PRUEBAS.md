# 🧪 Guía de Pruebas - Verificación de Comunicación

**Cómo verificar que Desktop App y Web se comunican correctamente**

---

## 📋 Requisitos Previos

Antes de ejecutar pruebas:

- [ ] Servidor Web ejecutándose: `pnpm run dev`
- [ ] Base de datos MySQL conectada
- [ ] Desktop App compilada y ejecutándose
- [ ] Navegador con consola abierta (F12)

---

## 🎯 Prueba 1: Verificar Servidor Web

### Paso 1: Iniciar servidor

```bash
cd /home/usuario/animalia_web_hosting
pnpm run dev
```

**Output esperado**:
```
[11:25:28] Server running on http://localhost:3000/
[11:25:28] [OAuth] Initialized with baseURL: https://api.manus.im
```

### Paso 2: Acceder a la aplicación

Abre navegador: `http://localhost:3000`

**Deberías ver**: Página de login de Animalia

### Paso 3: Verificar en consola

Abre consola del navegador (F12 → Console):

```javascript
// Verificar que tRPC está disponible
console.log(trpc);

// Debería mostrar objeto con métodos
// {
//   auth: { me: {...}, logout: {...} },
//   sync: { getPatterns: {...}, ... },
//   ...
// }
```

---

## 🎯 Prueba 2: Verificar API de Sincronización

### Archivo de prueba: `test-sync-endpoints.js`

Crea este archivo en la raíz del proyecto:

```javascript
// test-sync-endpoints.js
const http = require('http');

const endpoints = [
  { path: '/api/trpc/auth.me', method: 'GET', name: 'Autenticación' },
  { path: '/api/trpc/sync.getPatterns', method: 'GET', name: 'Obtener Patrones' },
  { path: '/api/trpc/sync.getKnowledge', method: 'GET', name: 'Obtener Conocimiento' },
  { path: '/api/trpc/sync.getConversations', method: 'GET', name: 'Obtener Conversaciones' },
  { path: '/api/trpc/sync.getRetrainingRequests', method: 'GET', name: 'Obtener Reentrenos' },
  { path: '/api/trpc/sync.getSyncHistory', method: 'GET', name: 'Historial de Sincronización' },
];

async function testEndpoint(endpoint) {
  return new Promise((resolve) => {
    const options = {
      hostname: 'localhost',
      port: 3000,
      path: endpoint.path,
      method: endpoint.method,
      headers: {
        'Content-Type': 'application/json'
      }
    };

    const req = http.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        const status = res.statusCode;
        const icon = status === 200 || status === 401 ? '✅' : '❌';
        console.log(`${icon} [${status}] ${endpoint.name}`);
        resolve({ endpoint: endpoint.name, status });
      });
    });

    req.on('error', (error) => {
      console.log(`❌ [ERROR] ${endpoint.name} - ${error.message}`);
      resolve({ endpoint: endpoint.name, status: 'ERROR' });
    });

    req.end();
  });
}

async function runTests() {
  console.log('🧪 Probando endpoints de Animalia...\n');
  console.log('Servidor: http://localhost:3000\n');

  const results = [];
  for (const endpoint of endpoints) {
    const result = await testEndpoint(endpoint);
    results.push(result);
    await new Promise(r => setTimeout(r, 100)); // Pequeño delay
  }

  console.log('\n📊 Resumen:');
  const passed = results.filter(r => r.status === 200 || r.status === 401).length;
  console.log(`${passed}/${results.length} endpoints respondieron correctamente\n`);

  if (passed === results.length) {
    console.log('✅ ¡Todos los endpoints funcionan correctamente!');
  } else {
    console.log('⚠️  Algunos endpoints tienen problemas. Revisa los logs del servidor.');
  }
}

runTests();
```

### Ejecutar prueba

```bash
node test-sync-endpoints.js
```

**Output esperado**:
```
🧪 Probando endpoints de Animalia...

Servidor: http://localhost:3000

✅ [200] Autenticación
✅ [200] Obtener Patrones
✅ [200] Obtener Conocimiento
✅ [200] Obtener Conversaciones
✅ [200] Obtener Reentrenos
✅ [200] Historial de Sincronización

📊 Resumen:
6/6 endpoints respondieron correctamente

✅ ¡Todos los endpoints funcionan correctamente!
```

---

## 🎯 Prueba 3: Verificar WebSocket

### En consola del navegador (F12)

```javascript
// 1. Verificar que Socket.IO está disponible
console.log(typeof io);
// Esperado: "function"

// 2. Conectar a WebSocket
const socket = io('http://localhost:3000', {
  auth: {
    token: 'test-token'
  },
  query: {
    deviceType: 'web'
  }
});

// 3. Escuchar eventos de conexión
socket.on('connect', () => {
  console.log('✅ WebSocket conectado');
  console.log('Socket ID:', socket.id);
});

socket.on('connect_error', (error) => {
  console.log('❌ Error de conexión:', error);
});

socket.on('disconnect', () => {
  console.log('❌ WebSocket desconectado');
});

// 4. Enviar ping
socket.emit('ping', () => {
  console.log('✅ Ping respondió');
});

// 5. Solicitar sincronización
socket.emit('sync:request', { since: new Date(Date.now() - 3600000) }, (response) => {
  console.log('Sync Response:', response);
});
```

**Output esperado**:
```
✅ WebSocket conectado
Socket ID: abc123def456
✅ Ping respondió
Sync Response: { success: true, messages: [...], timestamp: "..." }
```

---

## 🎯 Prueba 4: Verificar Caché Local

### En consola del navegador

```javascript
// 1. Verificar que wsClient está disponible
console.log(wsClient);

// 2. Ver estadísticas de caché
console.log('Estadísticas de caché:', wsClient.getCacheStats());
// Esperado: { entries: 0-100, size: 0-50000, connected: true/false }

// 3. Guardar datos en caché
wsClient.setCacheEntry('test-key', { data: 'test-value' }, 3600000);
console.log('✅ Datos guardados en caché');

// 4. Recuperar datos del caché
const cachedData = wsClient.getCacheEntry('test-key');
console.log('Datos recuperados:', cachedData);
// Esperado: { data: 'test-value' }

// 5. Limpiar caché expirado
wsClient.cleanExpiredCache();
console.log('✅ Caché limpiado');

// 6. Ver contenido de localStorage
console.log('localStorage:', localStorage.getItem('animalia_cache'));
```

**Output esperado**:
```
Estadísticas de caché: { entries: 1, size: 45, connected: true }
✅ Datos guardados en caché
Datos recuperados: { data: 'test-value' }
✅ Caché limpiado
localStorage: {"test-key":{"data":"test-value","timestamp":"...","ttl":3600000}}
```

---

## 🎯 Prueba 5: Verificar Sincronización Completa

### Archivo de prueba: `test-full-sync.js`

```javascript
// test-full-sync.js
const http = require('http');

async function testFullSync() {
  console.log('🔄 Iniciando prueba de sincronización completa...\n');

  // Paso 1: Obtener patrones
  console.log('1️⃣  Obteniendo patrones...');
  const patterns = await fetchData('/api/trpc/sync.getPatterns');
  console.log(`   ✅ ${patterns.length} patrones obtenidos\n`);

  // Paso 2: Obtener conocimiento
  console.log('2️⃣  Obteniendo conocimiento...');
  const knowledge = await fetchData('/api/trpc/sync.getKnowledge');
  console.log(`   ✅ ${knowledge.length} elementos de conocimiento obtenidos\n`);

  // Paso 3: Obtener conversaciones
  console.log('3️⃣  Obteniendo conversaciones...');
  const conversations = await fetchData('/api/trpc/sync.getConversations');
  console.log(`   ✅ ${conversations.length} conversaciones obtenidas\n`);

  // Paso 4: Obtener solicitudes de reentreno
  console.log('4️⃣  Obteniendo solicitudes de reentreno...');
  const retraining = await fetchData('/api/trpc/sync.getRetrainingRequests');
  console.log(`   ✅ ${retraining.length} solicitudes de reentreno obtenidas\n`);

  // Paso 5: Obtener historial de sincronización
  console.log('5️⃣  Obteniendo historial de sincronización...');
  const history = await fetchData('/api/trpc/sync.getSyncHistory');
  console.log(`   ✅ ${history.length} registros en historial\n`);

  // Resumen
  console.log('📊 Resumen de Sincronización:');
  console.log(`   Patrones: ${patterns.length}`);
  console.log(`   Conocimiento: ${knowledge.length}`);
  console.log(`   Conversaciones: ${conversations.length}`);
  console.log(`   Reentrenos: ${retraining.length}`);
  console.log(`   Historial: ${history.length}`);
  console.log(`\n✅ Sincronización completada exitosamente`);
}

function fetchData(path) {
  return new Promise((resolve) => {
    const options = {
      hostname: 'localhost',
      port: 3000,
      path: path,
      method: 'GET',
      headers: {
        'Content-Type': 'application/json'
      }
    };

    const req = http.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          const parsed = JSON.parse(data);
          resolve(Array.isArray(parsed) ? parsed : parsed.result || []);
        } catch {
          resolve([]);
        }
      });
    });

    req.on('error', () => resolve([]));
    req.end();
  });
}

testFullSync();
```

**Ejecutar**:
```bash
node test-full-sync.js
```

---

## 🎯 Prueba 6: Verificar Base de Datos

### Conectar a MySQL

```bash
mysql -u animalia_user -p animalia
```

### Ejecutar queries

```sql
-- Ver todas las tablas
SHOW TABLES;

-- Contar registros en cada tabla
SELECT 'users' as tabla, COUNT(*) as registros FROM users
UNION ALL
SELECT 'animal_patterns', COUNT(*) FROM animal_patterns
UNION ALL
SELECT 'knowledge', COUNT(*) FROM knowledge
UNION ALL
SELECT 'conversations', COUNT(*) FROM conversations
UNION ALL
SELECT 'retraining_requests', COUNT(*) FROM retraining_requests
UNION ALL
SELECT 'sync_history', COUNT(*) FROM sync_history;

-- Ver estructura de tabla
DESCRIBE animal_patterns;

-- Ver últimos registros
SELECT * FROM sync_history ORDER BY createdAt DESC LIMIT 5;
```

---

## 🎯 Prueba 7: Verificar Logs

### Ver logs en tiempo real

```bash
# Terminal 1: Ver todos los logs
tail -f .manus-logs/devserver.log

# Terminal 2: Filtrar por "sync"
tail -f .manus-logs/devserver.log | grep sync

# Terminal 3: Filtrar por "WebSocket"
tail -f .manus-logs/devserver.log | grep WebSocket
```

### Buscar errores específicos

```bash
# Errores de sincronización
grep -i "sync.*error" .manus-logs/devserver.log

# Errores de WebSocket
grep -i "websocket.*error" .manus-logs/devserver.log

# Errores de base de datos
grep -i "database.*error" .manus-logs/devserver.log
```

---

## ✅ Checklist de Pruebas

Marca cada prueba como completada:

- [ ] **Prueba 1**: Servidor Web inicia correctamente
- [ ] **Prueba 2**: Todos los endpoints responden (6/6)
- [ ] **Prueba 3**: WebSocket conecta y responde ping
- [ ] **Prueba 4**: Caché local guarda y recupera datos
- [ ] **Prueba 5**: Sincronización completa obtiene datos
- [ ] **Prueba 6**: Base de datos tiene tablas y registros
- [ ] **Prueba 7**: Logs muestran actividad sin errores

**Si todas las pruebas pasan**: ✅ **Sistema listo para producción**

---

## 🚨 Problemas Comunes en Pruebas

### Problema: "Cannot GET /api/trpc/sync.getPatterns"

**Causa**: Router de sincronización no está registrado

**Solución**:
```bash
# Verificar que sync.ts existe
ls -la server/routers/sync.ts

# Verificar que está importado en routers.ts
grep "syncRouter" server/routers.ts

# Reiniciar servidor
pnpm run dev
```

### Problema: "WebSocket connection failed"

**Causa**: Socket.IO no está instalado o configurado

**Solución**:
```bash
# Instalar socket.io
pnpm add socket.io

# Verificar que websocket.ts existe
ls -la server/websocket.ts

# Reiniciar servidor
pnpm run dev
```

### Problema: "Cache is empty"

**Causa**: Normal en primera ejecución

**Solución**:
```javascript
// Agregar datos manualmente
wsClient.setCacheEntry('test', { value: 123 }, 3600000);

// Verificar
wsClient.getCacheStats();
```

### Problema: "Database connection error"

**Causa**: Credenciales incorrectas en .env

**Solución**:
```bash
# Verificar .env
cat .env | grep DATABASE_URL

# Verificar que MySQL está ejecutándose
mysql -u root -p

# Verificar usuario y permisos
mysql -u animalia_user -p animalia -e "SELECT 1;"
```

---

## 📞 Archivos de Prueba Clave

Si necesitas verificar comunicación específica:

| Archivo | Propósito | Ubicación |
|---------|-----------|-----------|
| `test-sync-endpoints.js` | Probar API REST | Raíz del proyecto |
| `test-full-sync.js` | Probar sincronización | Raíz del proyecto |
| `test-connection.js` | Probar conexión básica | Raíz del proyecto |
| `.manus-logs/devserver.log` | Ver logs del servidor | Directorio del proyecto |

---

## 🎓 Interpretación de Resultados

### Resultado Exitoso

```
✅ [200] Autenticación
✅ [200] Obtener Patrones
✅ WebSocket conectado
✅ Caché guardado
✅ Sincronización completada
```

**Significa**: Todo funciona correctamente

### Resultado Parcial

```
✅ [200] Autenticación
❌ [500] Obtener Patrones
⚠️  WebSocket conectado pero lento
```

**Significa**: Hay problemas específicos, revisa logs

### Resultado Fallido

```
❌ [ERROR] Autenticación
❌ [ERROR] Obtener Patrones
❌ WebSocket no conecta
```

**Significa**: Problema fundamental, revisa servidor y BD

---

**¡Listo! Ahora puedes verificar que Animalia funciona correctamente.** ✅

