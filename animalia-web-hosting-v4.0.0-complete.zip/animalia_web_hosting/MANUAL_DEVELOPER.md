# 📚 Manual de Developer - Animalia Web Hosting

**Versión**: 1.0.0  
**Última actualización**: Febrero 2026  
**Objetivo**: Guía completa para desplegar Animalia en producción sin complejidades técnicas

---

## 🎯 ¿Qué es Animalia?

Animalia es una **plataforma web de análisis de comportamiento animal** que permite:
- 💬 Chat RAG contextualizado
- 🔄 Sincronización automática entre Desktop y Web
- 📊 Análisis de patrones de comportamiento
- 🧠 Reentrenamiento de modelos de IA
- 💾 Gestión de conocimiento y bases de datos

---

## 📋 Requisitos Previos

Antes de comenzar, asegúrate de tener:

| Requisito | Versión | Cómo Verificar |
|-----------|---------|----------------|
| **Node.js** | 18+ | `node --version` |
| **pnpm** | 8+ | `pnpm --version` |
| **MySQL** | 5.7+ | `mysql --version` |
| **Git** | Cualquiera | `git --version` |

### Instalación Rápida

**Windows/Mac:**
1. Descarga Node.js desde [nodejs.org](https://nodejs.org)
2. Instala pnpm: `npm install -g pnpm`

**Linux:**
```bash
curl -fsSL https://get.pnpm.io/install.sh | sh -
```

---

## 🚀 Despliegue Automático (Recomendado)

### Opción 1: Script de Autodespliegue

**Lo que hace**: Instala todo automáticamente, configura la BD y compila el proyecto.

```bash
# 1. Navega al directorio del proyecto
cd /ruta/a/animalia_web_hosting

# 2. Ejecuta el script de despliegue
./deploy.sh producción
```

**¿Qué sucede?**
- ✅ Verifica que tengas Node.js y pnpm
- ✅ Crea un backup automático
- ✅ Instala todas las dependencias (paquetes)
- ✅ Configura la base de datos
- ✅ Compila el código
- ✅ Ejecuta tests
- ✅ Prepara para producción

**Tiempo estimado**: 10-15 minutos

---

## 🔧 Despliegue Manual (Si el automático falla)

### Paso 1: Preparar el Entorno

```bash
# Ir al directorio del proyecto
cd /ruta/a/animalia_web_hosting

# Crear archivo .env con las variables de entorno
cat > .env << EOF
DATABASE_URL=mysql://usuario:contraseña@localhost:3306/animalia
JWT_SECRET=tu_secreto_aleatorio_aqui
VITE_APP_ID=tu_app_id
OAUTH_SERVER_URL=https://api.manus.im
EOF
```

**Variables importantes**:
- `DATABASE_URL`: Conexión a tu base de datos MySQL
- `JWT_SECRET`: Clave secreta para tokens (usa algo aleatorio)
- `VITE_APP_ID`: ID de tu aplicación

### Paso 2: Instalar Dependencias

```bash
# Instalar todos los paquetes necesarios
pnpm install

# Esto descarga ~500 MB de código
# Toma 5-10 minutos dependiendo de tu conexión
```

**¿Qué es esto?** Son librerías de código que Animalia necesita para funcionar (React, Express, etc.)

### Paso 3: Configurar Base de Datos

```bash
# Generar migraciones (cambios en la BD)
pnpm exec drizzle-kit generate

# Aplicar cambios a la BD
pnpm exec drizzle-kit migrate
```

**¿Qué sucede?** Se crean las tablas necesarias en tu MySQL:
- `users`: Usuarios del sistema
- `animal_patterns`: Patrones de comportamiento
- `knowledge`: Base de conocimiento
- `conversations`: Historial de chats
- `retraining_requests`: Solicitudes de reentrenamiento
- `sync_history`: Historial de sincronización

### Paso 4: Compilar el Proyecto

```bash
# Compilar código para producción
pnpm run build

# Esto crea carpeta 'dist' con todo listo
```

**¿Qué sucede?** El código se optimiza y prepara para servidor.

### Paso 5: Ejecutar Tests (Opcional pero Recomendado)

```bash
# Ejecutar pruebas automáticas
pnpm run test

# Verifica que todo funcione correctamente
```

---

## 📁 Estructura de Archivos Clave

```
animalia_web_hosting/
├── .env                          ← ARCHIVO CRÍTICO: Variables de entorno
├── deploy.sh                     ← Script de autodespliegue
├── package.json                  ← Lista de dependencias
│
├── client/                       ← Código Frontend (lo que ve el usuario)
│   ├── src/
│   │   ├── pages/               ← Páginas principales
│   │   │   ├── Dashboard.tsx    ← Panel principal
│   │   │   ├── PatternsManagement.tsx
│   │   │   ├── RetrainingModule.tsx
│   │   │   └── Analytics.tsx
│   │   ├── hooks/
│   │   │   └── useSyncManager.ts ← Sincronización automática
│   │   └── App.tsx              ← Aplicación principal
│
├── server/                       ← Código Backend (servidor)
│   ├── routers/
│   │   └── sync.ts              ← API de sincronización
│   ├── websocket.ts             ← Conexión en tiempo real
│   ├── db.ts                    ← Funciones de base de datos
│   └── routers.ts               ← Endpoints de la API
│
├── drizzle/                      ← Configuración de base de datos
│   └── schema.ts                ← Definición de tablas
│
└── dist/                         ← Código compilado (se genera con `pnpm build`)
```

**Archivos que DEBES editar**:
- `.env`: Variables de entorno (credenciales, URLs)
- `drizzle/schema.ts`: Si necesitas agregar campos a tablas

**Archivos que NO debes tocar**:
- `node_modules/`: Librerías (se genera automáticamente)
- `dist/`: Código compilado (se genera automáticamente)

---

## 🔌 Sincronización: Cómo Funciona

### WebSocket (Tiempo Real)

Animalia usa **WebSocket** para sincronización en tiempo real entre Desktop y Web:

```
Desktop App ←→ WebSocket ←→ Servidor Web ←→ Base de Datos
```

**Ventajas**:
- ✅ Sincronización instantánea
- ✅ Bajo consumo de datos
- ✅ Funciona incluso con conexión lenta

### Caché Local

La Desktop App mantiene una **copia local** de datos para funcionar sin conexión:

```
Datos en Servidor → Descarga → Caché Local (localStorage)
                                    ↓
                            Uso offline
                                    ↓
                        Sincroniza cuando conecta
```

**Ubicación del caché**: `localStorage` del navegador Tauri

---

## 🧪 Verificar que Todo Funciona

### Archivo de Prueba: `test-connection.js`

Crea este archivo para verificar conexión:

```javascript
// test-connection.js
const http = require('http');

const options = {
  hostname: 'localhost',
  port: 3000,
  path: '/api/trpc/auth.me',
  method: 'GET'
};

const req = http.request(options, (res) => {
  console.log(`Status: ${res.statusCode}`);
  if (res.statusCode === 200) {
    console.log('✅ Servidor está funcionando');
  } else {
    console.log('❌ Error en servidor');
  }
});

req.on('error', (error) => {
  console.log('❌ No se puede conectar al servidor');
  console.log('Asegúrate de ejecutar: pnpm dev');
});

req.end();
```

**Ejecutar**:
```bash
node test-connection.js
```

### Verificar Base de Datos

```bash
# Conectar a MySQL
mysql -u usuario -p

# Dentro de MySQL:
USE animalia;
SHOW TABLES;  # Ver todas las tablas

# Ver estructura de tabla
DESCRIBE users;
```

---

## 🚨 Solución de Problemas Comunes

### Problema: "pnpm: command not found"

**Solución**:
```bash
npm install -g pnpm
pnpm --version  # Verificar instalación
```

### Problema: "Error de conexión a base de datos"

**Verificar**:
1. MySQL está ejecutándose: `mysql -u root -p`
2. Credenciales en `.env` son correctas
3. Base de datos existe: `CREATE DATABASE animalia;`

### Problema: "Puerto 3000 ya está en uso"

**Solución**:
```bash
# Encontrar proceso en puerto 3000
lsof -i :3000

# Matar proceso
kill -9 <PID>

# O usar puerto diferente
PORT=3001 pnpm dev
```

### Problema: "node_modules corrupto"

**Solución**:
```bash
# Limpiar e reinstalar
rm -rf node_modules pnpm-lock.yaml
pnpm install
```

---

## 📊 Monitoreo en Producción

### Logs Importantes

```bash
# Ver logs del servidor
tail -f .manus-logs/devserver.log

# Ver logs de base de datos
tail -f /var/log/mysql/error.log

# Ver logs de sincronización
grep "sync" .manus-logs/devserver.log
```

### Métricas a Monitorear

| Métrica | Ubicación | Qué Significa |
|---------|-----------|---------------|
| **Conexiones activas** | WebSocket | Usuarios conectados |
| **Errores de BD** | MySQL logs | Problemas de datos |
| **Tiempo de respuesta** | Server logs | Velocidad de API |
| **Uso de caché** | Browser DevTools | Datos locales |

---

## 🔐 Seguridad: Checklist

Antes de ir a producción:

- [ ] `.env` tiene secretos únicos y fuertes
- [ ] Base de datos tiene contraseña segura
- [ ] SSL/HTTPS está configurado
- [ ] Firewall bloquea puertos innecesarios
- [ ] Backups automáticos están configurados
- [ ] Logs se guardan y revisan regularmente

---

## 📞 Archivos Clave para Comunicación

Si necesitas verificar que Desktop y Web se comunican:

1. **`server/routers/sync.ts`** - Define los endpoints de sincronización
2. **`client/src/hooks/useSyncManager.ts`** - Sincronización automática en Web
3. **`src/lib/websocketClient.ts`** - Cliente WebSocket en Desktop
4. **`server/websocket.ts`** - Servidor WebSocket

**Verificar comunicación**:
```bash
# En consola del navegador (F12)
console.log(trpc.sync.getPatterns.useQuery())

# En logs del servidor
grep "sync:" .manus-logs/devserver.log
```

---

## 🎓 Próximos Pasos

1. **Personalización**: Edita `client/src/pages/Dashboard.tsx` para tu marca
2. **Integración**: Conecta tu LLM en `server/routers/sync.ts`
3. **Monitoreo**: Configura alertas para errores críticos
4. **Escalado**: Prepara para múltiples usuarios

---

## 📚 Recursos Adicionales

- **Documentación de React**: https://react.dev
- **Documentación de Express**: https://expressjs.com
- **Documentación de MySQL**: https://dev.mysql.com
- **Documentación de tRPC**: https://trpc.io

---

## 💬 Soporte

Si encuentras problemas:

1. **Revisa los logs**: `.manus-logs/devserver.log`
2. **Consulta la sección de solución de problemas** arriba
3. **Verifica que todos los requisitos estén instalados**
4. **Ejecuta el script de despliegue nuevamente**

---

**¡Felicidades! Ahora tienes Animalia funcionando en producción.** 🎉

