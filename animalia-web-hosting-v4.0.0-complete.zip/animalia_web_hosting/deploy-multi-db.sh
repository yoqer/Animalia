#!/bin/bash

###############################################################################
# SCRIPT DE AUTODESPLIEGUE MULTI-BD - ANIMALIA WEB HOSTING
# 
# Soporta: MySQL, PostgreSQL, MongoDB, SQLite
# Detecta automáticamente la BD y configura todo
#
# Uso: ./deploy-multi-db.sh [mysql|postgresql|mongodb|sqlite] [producción|staging|desarrollo]
###############################################################################

set -e

# Colores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

# Variables
DB_TYPE=${1:-"mysql"}
ENVIRONMENT=${2:-"desarrollo"}
PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOG_FILE="$PROJECT_DIR/deploy.log"
TIMESTAMP=$(date '+%Y-%m-%d %H:%M:%S')

# Funciones de utilidad
log() {
  echo -e "${BLUE}[${TIMESTAMP}]${NC} $1" | tee -a "$LOG_FILE"
}

success() {
  echo -e "${GREEN}✓ $1${NC}" | tee -a "$LOG_FILE"
}

error() {
  echo -e "${RED}✗ $1${NC}" | tee -a "$LOG_FILE"
  exit 1
}

warning() {
  echo -e "${YELLOW}⚠ $1${NC}" | tee -a "$LOG_FILE"
}

info() {
  echo -e "${CYAN}ℹ $1${NC}" | tee -a "$LOG_FILE"
}

# Banner
show_banner() {
  clear
  echo -e "${BLUE}"
  echo "╔════════════════════════════════════════════════════════════╗"
  echo "║     ANIMALIA WEB HOSTING - AUTODESPLIEGUE MULTI-BD         ║"
  echo "║                                                            ║"
  echo "║  Base de Datos: ${DB_TYPE^^}                                  ║"
  echo "║  Entorno: ${ENVIRONMENT^^}                                   ║"
  echo "╚════════════════════════════════════════════════════════════╝"
  echo -e "${NC}\n"
}

# Verificar requisitos
check_requirements() {
  log "Verificando requisitos..."

  if ! command -v node &> /dev/null; then
    error "Node.js no está instalado"
  fi
  success "Node.js: $(node --version)"

  if ! command -v pnpm &> /dev/null; then
    error "pnpm no está instalado. Instálalo con: npm install -g pnpm"
  fi
  success "pnpm: $(pnpm --version)"

  # Verificar BD específica
  case $DB_TYPE in
    mysql)
      if ! command -v mysql &> /dev/null; then
        warning "Cliente MySQL no encontrado. Se usará URL de conexión remota"
      else
        success "MySQL: $(mysql --version)"
      fi
      ;;
    postgresql)
      if ! command -v psql &> /dev/null; then
        warning "Cliente PostgreSQL no encontrado. Se usará URL de conexión remota"
      else
        success "PostgreSQL: $(psql --version)"
      fi
      ;;
    mongodb)
      if ! command -v mongosh &> /dev/null; then
        warning "Cliente MongoDB no encontrado. Se usará URL de conexión remota"
      else
        success "MongoDB: $(mongosh --version)"
      fi
      ;;
    sqlite)
      if ! command -v sqlite3 &> /dev/null; then
        warning "SQLite3 no encontrado. Se instalará automáticamente"
      else
        success "SQLite3: $(sqlite3 --version)"
      fi
      ;;
  esac
}

# Crear archivo .env
create_env_file() {
  log "Configurando archivo .env para $DB_TYPE..."

  if [ -f "$PROJECT_DIR/.env" ]; then
    warning "Archivo .env ya existe. Haciendo backup..."
    cp "$PROJECT_DIR/.env" "$PROJECT_DIR/.env.backup.$(date +%s)"
  fi

  case $DB_TYPE in
    mysql)
      cat > "$PROJECT_DIR/.env" << 'EOF'
# Base de Datos MySQL
DATABASE_URL=mysql://usuario:contraseña@localhost:3306/animalia
DB_TYPE=mysql

# Seguridad
JWT_SECRET=tu_secreto_muy_largo_y_aleatorio_aqui_12345678901234567890

# OAuth
VITE_APP_ID=tu_app_id_aqui
OAUTH_SERVER_URL=https://api.manus.im
VITE_OAUTH_PORTAL_URL=https://login.manus.im

# URLs
VITE_FRONTEND_FORGE_API_URL=http://localhost:3000
BUILT_IN_FORGE_API_URL=http://localhost:3000

# Claves API
VITE_FRONTEND_FORGE_API_KEY=tu_api_key_aqui
BUILT_IN_FORGE_API_KEY=tu_api_key_aqui

# Información del propietario
OWNER_NAME=Tu Nombre
OWNER_OPEN_ID=tu_open_id

# Analíticas
VITE_ANALYTICS_ENDPOINT=http://localhost:3000/analytics
VITE_ANALYTICS_WEBSITE_ID=animalia

# Aplicación
VITE_APP_TITLE=Animalia - Sistema de Comunicación Multi-Especies
VITE_APP_LOGO=/logo.png
EOF
      ;;

    postgresql)
      cat > "$PROJECT_DIR/.env" << 'EOF'
# Base de Datos PostgreSQL
DATABASE_URL=postgresql://usuario:contraseña@localhost:5432/animalia
DB_TYPE=postgresql

# Resto de configuración igual a MySQL...
JWT_SECRET=tu_secreto_muy_largo_y_aleatorio_aqui_12345678901234567890
VITE_APP_ID=tu_app_id_aqui
OAUTH_SERVER_URL=https://api.manus.im
VITE_OAUTH_PORTAL_URL=https://login.manus.im
VITE_FRONTEND_FORGE_API_URL=http://localhost:3000
BUILT_IN_FORGE_API_URL=http://localhost:3000
VITE_FRONTEND_FORGE_API_KEY=tu_api_key_aqui
BUILT_IN_FORGE_API_KEY=tu_api_key_aqui
OWNER_NAME=Tu Nombre
OWNER_OPEN_ID=tu_open_id
VITE_ANALYTICS_ENDPOINT=http://localhost:3000/analytics
VITE_ANALYTICS_WEBSITE_ID=animalia
VITE_APP_TITLE=Animalia - Sistema de Comunicación Multi-Especies
VITE_APP_LOGO=/logo.png
EOF
      ;;

    mongodb)
      cat > "$PROJECT_DIR/.env" << 'EOF'
# Base de Datos MongoDB
DATABASE_URL=mongodb://usuario:contraseña@localhost:27017/animalia
DB_TYPE=mongodb

# Resto de configuración igual...
JWT_SECRET=tu_secreto_muy_largo_y_aleatorio_aqui_12345678901234567890
VITE_APP_ID=tu_app_id_aqui
OAUTH_SERVER_URL=https://api.manus.im
VITE_OAUTH_PORTAL_URL=https://login.manus.im
VITE_FRONTEND_FORGE_API_URL=http://localhost:3000
BUILT_IN_FORGE_API_URL=http://localhost:3000
VITE_FRONTEND_FORGE_API_KEY=tu_api_key_aqui
BUILT_IN_FORGE_API_KEY=tu_api_key_aqui
OWNER_NAME=Tu Nombre
OWNER_OPEN_ID=tu_open_id
VITE_ANALYTICS_ENDPOINT=http://localhost:3000/analytics
VITE_ANALYTICS_WEBSITE_ID=animalia
VITE_APP_TITLE=Animalia - Sistema de Comunicación Multi-Especies
VITE_APP_LOGO=/logo.png
EOF
      ;;

    sqlite)
      cat > "$PROJECT_DIR/.env" << 'EOF'
# Base de Datos SQLite (Local)
DATABASE_URL=sqlite:///home/usuario/animalia.db
DB_TYPE=sqlite

# Resto de configuración igual...
JWT_SECRET=tu_secreto_muy_largo_y_aleatorio_aqui_12345678901234567890
VITE_APP_ID=tu_app_id_aqui
OAUTH_SERVER_URL=https://api.manus.im
VITE_OAUTH_PORTAL_URL=https://login.manus.im
VITE_FRONTEND_FORGE_API_URL=http://localhost:3000
BUILT_IN_FORGE_API_URL=http://localhost:3000
VITE_FRONTEND_FORGE_API_KEY=tu_api_key_aqui
BUILT_IN_FORGE_API_KEY=tu_api_key_aqui
OWNER_NAME=Tu Nombre
OWNER_OPEN_ID=tu_open_id
VITE_ANALYTICS_ENDPOINT=http://localhost:3000/analytics
VITE_ANALYTICS_WEBSITE_ID=animalia
VITE_APP_TITLE=Animalia - Sistema de Comunicación Multi-Especies
VITE_APP_LOGO=/logo.png
EOF
      ;;
  esac

  chmod 600 "$PROJECT_DIR/.env"
  success "Archivo .env creado para $DB_TYPE"
}

# Instalar dependencias
install_dependencies() {
  log "Instalando dependencias..."
  cd "$PROJECT_DIR"

  pnpm install --frozen-lockfile || error "Error al instalar dependencias"
  success "Dependencias instaladas"
}

# Instalar dependencias específicas de BD
install_db_dependencies() {
  log "Instalando dependencias de $DB_TYPE..."
  cd "$PROJECT_DIR"

  case $DB_TYPE in
    mysql)
      pnpm add mysql2 drizzle-orm
      ;;
    postgresql)
      pnpm add postgres drizzle-orm
      ;;
    mongodb)
      pnpm add mongodb drizzle-orm
      ;;
    sqlite)
      pnpm add better-sqlite3 drizzle-orm
      ;;
  esac

  success "Dependencias de $DB_TYPE instaladas"
}

# Configurar base de datos
setup_database() {
  log "Configurando base de datos $DB_TYPE..."
  cd "$PROJECT_DIR"

  case $DB_TYPE in
    mysql)
      log "Creando base de datos MySQL..."
      mysql -u root -p << EOF
CREATE DATABASE IF NOT EXISTS animalia CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER IF NOT EXISTS 'animalia_user'@'localhost' IDENTIFIED BY 'animalia_password';
GRANT ALL PRIVILEGES ON animalia.* TO 'animalia_user'@'localhost';
FLUSH PRIVILEGES;
EOF
      ;;

    postgresql)
      log "Creando base de datos PostgreSQL..."
      psql -U postgres << EOF
CREATE DATABASE animalia;
CREATE USER animalia_user WITH PASSWORD 'animalia_password';
GRANT ALL PRIVILEGES ON DATABASE animalia TO animalia_user;
EOF
      ;;

    mongodb)
      log "Creando base de datos MongoDB..."
      mongosh << EOF
use animalia
db.createCollection("users")
db.createCollection("animal_patterns")
db.createCollection("knowledge")
db.createCollection("conversations")
db.createCollection("retraining_requests")
db.createCollection("sync_history")
EOF
      ;;

    sqlite)
      log "Creando base de datos SQLite..."
      sqlite3 "$PROJECT_DIR/animalia.db" << EOF
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  openId TEXT UNIQUE NOT NULL,
  name TEXT,
  email TEXT,
  role TEXT DEFAULT 'user',
  createdAt DATETIME DEFAULT CURRENT_TIMESTAMP
);
EOF
      ;;
  esac

  success "Base de datos $DB_TYPE configurada"
}

# Generar y aplicar migraciones
run_migrations() {
  log "Generando migraciones..."
  cd "$PROJECT_DIR"

  pnpm exec drizzle-kit generate || warning "Error al generar migraciones"

  log "Aplicando migraciones..."
  pnpm exec drizzle-kit migrate || warning "Error al aplicar migraciones"

  success "Migraciones completadas"
}

# Compilar proyecto
build_project() {
  log "Compilando proyecto..."
  cd "$PROJECT_DIR"

  rm -rf dist
  pnpm run build || error "Error al compilar"

  success "Proyecto compilado"
}

# Ejecutar tests
run_tests() {
  log "Ejecutando tests..."
  cd "$PROJECT_DIR"

  pnpm run test || warning "Algunos tests fallaron"

  success "Tests completados"
}

# Iniciar servidor
start_server() {
  log "Iniciando servidor..."
  cd "$PROJECT_DIR"

  case $ENVIRONMENT in
    desarrollo)
      info "Iniciando servidor de desarrollo..."
      pnpm run dev
      ;;
    staging)
      info "Iniciando servidor de staging..."
      PORT=3001 pnpm run start
      ;;
    producción)
      info "Iniciando servidor de producción..."
      PORT=3000 pnpm run start
      ;;
  esac
}

# Mostrar resumen
show_summary() {
  log "=========================================="
  log "RESUMEN DE DESPLIEGUE"
  log "=========================================="
  log "Base de Datos: $DB_TYPE"
  log "Entorno: $ENVIRONMENT"
  log "Directorio: $PROJECT_DIR"
  log "Archivo .env: $PROJECT_DIR/.env"
  log "Log: $LOG_FILE"
  log "=========================================="
}

# Menú principal
main() {
  show_banner
  check_requirements
  create_env_file
  install_dependencies
  install_db_dependencies
  setup_database
  run_migrations
  build_project
  run_tests
  show_summary

  success "¡Despliegue completado exitosamente!"
  info "Para iniciar el servidor, ejecuta: ./deploy-multi-db.sh $DB_TYPE $ENVIRONMENT"
}

# Ejecutar
main "$@"
