#!/bin/bash

###############################################################################
# SCRIPT DE AUTODESPLIEGUE - ANIMALIA WEB HOSTING
# 
# Este script automatiza el despliegue de Animalia en producción.
# Incluye: instalación de dependencias, migraciones de BD, build y deploy.
#
# Uso: ./deploy.sh [producción|staging|desarrollo]
###############################################################################

set -e  # Salir si hay error

# Colores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Variables
ENVIRONMENT=${1:-"producción"}
PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOG_FILE="$PROJECT_DIR/deploy.log"
TIMESTAMP=$(date '+%Y-%m-%d %H:%M:%S')

# Funciones de utilidad
log() {
  echo -e "${BLUE}[${TIMESTAMP}]${NC} $1" | tee -a "$LOG_FILE"
}

success() {
  echo -e "${GREEN}✓ $1${NC}" | tee -a "$LOG_FILE"
}

error() {
  echo -e "${RED}✗ $1${NC}" | tee -a "$LOG_FILE"
  exit 1
}

warning() {
  echo -e "${YELLOW}⚠ $1${NC}" | tee -a "$LOG_FILE"
}

# Verificar requisitos
check_requirements() {
  log "Verificando requisitos..."

  if ! command -v node &> /dev/null; then
    error "Node.js no está instalado"
  fi
  success "Node.js: $(node --version)"

  if ! command -v pnpm &> /dev/null; then
    error "pnpm no está instalado. Instálalo con: npm install -g pnpm"
  fi
  success "pnpm: $(pnpm --version)"

  if ! command -v git &> /dev/null; then
    warning "Git no está instalado (opcional)"
  else
    success "Git: $(git --version)"
  fi
}

# Instalar dependencias
install_dependencies() {
  log "Instalando dependencias..."
  cd "$PROJECT_DIR"
  
  if [ -d "node_modules" ]; then
    warning "node_modules ya existe. Ejecutando pnpm install..."
  fi
  
  pnpm install --frozen-lockfile || error "Error al instalar dependencias"
  success "Dependencias instaladas"
}

# Crear/actualizar base de datos
setup_database() {
  log "Configurando base de datos..."
  
  # Verificar archivo .env
  if [ ! -f "$PROJECT_DIR/.env" ]; then
    error "Archivo .env no encontrado. Por favor, crea el archivo .env con las variables de entorno"
  fi
  
  cd "$PROJECT_DIR"
  
  # Generar migraciones
  log "Generando migraciones..."
  pnpm exec drizzle-kit generate || warning "Error al generar migraciones (puede ser normal si no hay cambios)"
  
  # Aplicar migraciones
  log "Aplicando migraciones a la base de datos..."
  pnpm exec drizzle-kit migrate || error "Error al aplicar migraciones"
  
  success "Base de datos configurada"
}

# Compilar proyecto
build_project() {
  log "Compilando proyecto..."
  cd "$PROJECT_DIR"
  
  # Limpiar builds anteriores
  rm -rf dist
  
  # Compilar
  pnpm run build || error "Error al compilar el proyecto"
  
  success "Proyecto compilado exitosamente"
}

# Ejecutar tests
run_tests() {
  log "Ejecutando tests..."
  cd "$PROJECT_DIR"
  
  pnpm run test || warning "Algunos tests fallaron (revisar logs)"
  
  success "Tests completados"
}

# Validar TypeScript
validate_typescript() {
  log "Validando TypeScript..."
  cd "$PROJECT_DIR"
  
  pnpm run check || error "Errores de TypeScript encontrados"
  
  success "TypeScript validado"
}

# Crear backup
create_backup() {
  log "Creando backup..."
  
  BACKUP_DIR="$PROJECT_DIR/backups"
  mkdir -p "$BACKUP_DIR"
  
  BACKUP_FILE="$BACKUP_DIR/backup-$(date '+%Y%m%d-%H%M%S').tar.gz"
  
  tar -czf "$BACKUP_FILE" \
    --exclude=node_modules \
    --exclude=dist \
    --exclude=.git \
    --exclude=backups \
    -C "$(dirname "$PROJECT_DIR")" \
    "$(basename "$PROJECT_DIR")" || warning "Error al crear backup"
  
  success "Backup creado: $BACKUP_FILE"
}

# Desplegar
deploy() {
  log "Desplegando a $ENVIRONMENT..."
  
  case $ENVIRONMENT in
    producción)
      log "Desplegando a producción..."
      # Aquí iría el comando específico para tu hosting
      # Ejemplo: rsync, scp, git push, etc.
      warning "Configura el comando de despliegue para tu hosting específico"
      ;;
    staging)
      log "Desplegando a staging..."
      warning "Configura el comando de despliegue para staging"
      ;;
    desarrollo)
      log "Iniciando servidor de desarrollo..."
      pnpm run dev
      ;;
    *)
      error "Entorno desconocido: $ENVIRONMENT"
      ;;
  esac
  
  success "Despliegue completado"
}

# Mostrar resumen
show_summary() {
  log "=========================================="
  log "RESUMEN DE DESPLIEGUE"
  log "=========================================="
  log "Proyecto: Animalia Web Hosting"
  log "Entorno: $ENVIRONMENT"
  log "Directorio: $PROJECT_DIR"
  log "Timestamp: $TIMESTAMP"
  log "Log: $LOG_FILE"
  log "=========================================="
}

# Menú principal
main() {
  clear
  echo -e "${BLUE}"
  echo "╔════════════════════════════════════════╗"
  echo "║   ANIMALIA WEB HOSTING - AUTODESPLIEGUE║"
  echo "╚════════════════════════════════════════╝"
  echo -e "${NC}"
  
  log "Iniciando despliegue para: $ENVIRONMENT"
  
  check_requirements
  create_backup
  install_dependencies
  setup_database
  validate_typescript
  build_project
  run_tests
  deploy
  show_summary
  
  success "¡Despliegue completado exitosamente!"
}

# Ejecutar
main "$@"
