import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// Tablas para sincronización
export const animalPatterns = mysqlTable("animal_patterns", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  species: varchar("species", { length: 255 }).notNull(),
  pattern: text("pattern").notNull(),
  category: varchar("category", { length: 100 }).notNull(),
  confidence: int("confidence").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const knowledge = mysqlTable("knowledge", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  category: varchar("category", { length: 100 }).notNull(),
  data: text("data").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const conversations = mysqlTable("conversations", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  message: text("message").notNull(),
  response: text("response").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const retrainingRequests = mysqlTable("retraining_requests", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  modelType: varchar("modelType", { length: 50 }).notNull(),
  status: mysqlEnum("status", ["pending", "processing", "completed", "failed"]).default("pending").notNull(),
  progress: int("progress").default(0).notNull(),
  trainingData: text("trainingData").notNull(),
  weights: text("weights"),
  priority: mysqlEnum("priority", ["normal", "high", "urgent"]).default("normal").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const syncHistory = mysqlTable("sync_history", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  type: mysqlEnum("type", ["upload", "download"]).notNull(),
  source: varchar("source", { length: 100 }).notNull(),
  itemsCount: int("itemsCount").notNull(),
  size: varchar("size", { length: 50 }).notNull(),
  status: mysqlEnum("status", ["completed", "failed", "processing"]).default("completed").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type AnimalPattern = typeof animalPatterns.$inferSelect;
export type Knowledge = typeof knowledge.$inferSelect;
export type Conversation = typeof conversations.$inferSelect;
export type RetrainingRequest = typeof retrainingRequests.$inferSelect;
export type SyncHistory = typeof syncHistory.$inferSelect;