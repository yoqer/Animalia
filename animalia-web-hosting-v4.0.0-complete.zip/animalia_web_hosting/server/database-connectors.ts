/**
 * Conectores para Bases de Datos Externas
 * Soporta: Supabase, Database.com, Notion, Obsidian, NotebookLM
 */

export interface DatabaseConnectorConfig {
  type: string;
  credentials: string;
  endpoint?: string;
}

export interface ExtractedData {
  records: any[];
  totalRecords: number;
  extractedAt: Date;
}

/**
 * Clase base para conectores de BD
 */
abstract class BaseDatabaseConnector {
  protected config: DatabaseConnectorConfig;

  constructor(config: DatabaseConnectorConfig) {
    this.config = config;
  }

  abstract connect(): Promise<boolean>;
  abstract extractData(query?: string, limit?: number): Promise<ExtractedData>;
  abstract testConnection(): Promise<boolean>;
}

/**
 * Supabase (PostgreSQL en la nube)
 */
class SupabaseConnector extends BaseDatabaseConnector {
  async connect(): Promise<boolean> {
    try {
      const response = await fetch(`https://${this.config.endpoint}/rest/v1/`, {
        headers: {
          apikey: this.config.credentials,
          Authorization: `Bearer ${this.config.credentials}`,
        },
      });
      return response.ok;
    } catch {
      return false;
    }
  }

  async extractData(query?: string, limit: number = 1000): Promise<ExtractedData> {
    try {
      const endpoint = `https://${this.config.endpoint}/rest/v1/`;
      const table = query || 'public';

      const response = await fetch(`${endpoint}${table}?limit=${limit}`, {
        headers: {
          apikey: this.config.credentials,
          Authorization: `Bearer ${this.config.credentials}`,
        },
      });

      if (!response.ok) throw new Error(`Supabase error: ${response.statusText}`);

      const records = await response.json();
      return {
        records,
        totalRecords: records.length,
        extractedAt: new Date(),
      };
    } catch (error: any) {
      throw new Error(`Supabase extraction error: ${error.message}`);
    }
  }

  async testConnection(): Promise<boolean> {
    return this.connect();
  }
}

/**
 * Notion
 */
class NotionConnector extends BaseDatabaseConnector {
  async connect(): Promise<boolean> {
    try {
      const response = await fetch('https://api.notion.com/v1/users/me', {
        headers: {
          Authorization: `Bearer ${this.config.credentials}`,
          'Notion-Version': '2022-06-28',
        },
      });
      return response.ok;
    } catch {
      return false;
    }
  }

  async extractData(query?: string, limit: number = 100): Promise<ExtractedData> {
    try {
      const databaseId = query || this.config.endpoint;
      if (!databaseId) throw new Error('Database ID requerido');

      const response = await fetch(
        `https://api.notion.com/v1/databases/${databaseId}/query`,
        {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${this.config.credentials}`,
            'Notion-Version': '2022-06-28',
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            page_size: limit,
          }),
        }
      );

      if (!response.ok) throw new Error(`Notion error: ${response.statusText}`);

      const data = await response.json();
      return {
        records: data.results,
        totalRecords: data.results.length,
        extractedAt: new Date(),
      };
    } catch (error: any) {
      throw new Error(`Notion extraction error: ${error.message}`);
    }
  }

  async testConnection(): Promise<boolean> {
    return this.connect();
  }
}

/**
 * Obsidian (vía API local o sincronización)
 */
class ObsidianConnector extends BaseDatabaseConnector {
  async connect(): Promise<boolean> {
    try {
      const endpoint = this.config.endpoint || 'http://localhost:27123';
      const response = await fetch(`${endpoint}/vault/`);
      return response.ok;
    } catch {
      return false;
    }
  }

  async extractData(query?: string, limit: number = 1000): Promise<ExtractedData> {
    try {
      const endpoint = this.config.endpoint || 'http://localhost:27123';
      const vaultPath = query || '/';

      const response = await fetch(`${endpoint}/vault${vaultPath}`, {
        headers: {
          'X-Vault-Access-Token': this.config.credentials,
        },
      });

      if (!response.ok) throw new Error(`Obsidian error: ${response.statusText}`);

      const files = await response.json();
      return {
        records: files.slice(0, limit),
        totalRecords: files.length,
        extractedAt: new Date(),
      };
    } catch (error: any) {
      throw new Error(`Obsidian extraction error: ${error.message}`);
    }
  }

  async testConnection(): Promise<boolean> {
    return this.connect();
  }
}

/**
 * NotebookLM
 */
class NotebookLMConnector extends BaseDatabaseConnector {
  async connect(): Promise<boolean> {
    try {
      const response = await fetch('https://notebooklm.google.com/api/v1/notebooks', {
        headers: {
          Authorization: `Bearer ${this.config.credentials}`,
        },
      });
      return response.ok;
    } catch {
      return false;
    }
  }

  async extractData(query?: string, limit: number = 100): Promise<ExtractedData> {
    try {
      const response = await fetch('https://notebooklm.google.com/api/v1/notebooks', {
        headers: {
          Authorization: `Bearer ${this.config.credentials}`,
        },
      });

      if (!response.ok) throw new Error(`NotebookLM error: ${response.statusText}`);

      const data = await response.json();
      const notebooks = data.notebooks || [];

      return {
        records: notebooks.slice(0, limit),
        totalRecords: notebooks.length,
        extractedAt: new Date(),
      };
    } catch (error: any) {
      throw new Error(`NotebookLM extraction error: ${error.message}`);
    }
  }

  async testConnection(): Promise<boolean> {
    return this.connect();
  }
}

/**
 * Database.com (Salesforce)
 */
class DatabaseComConnector extends BaseDatabaseConnector {
  async connect(): Promise<boolean> {
    try {
      const response = await fetch('https://api.database.com/v1/auth/validate', {
        headers: {
          Authorization: `Bearer ${this.config.credentials}`,
        },
      });
      return response.ok;
    } catch {
      return false;
    }
  }

  async extractData(query?: string, limit: number = 1000): Promise<ExtractedData> {
    try {
      const soqlQuery = query || 'SELECT * FROM Account';

      const response = await fetch('https://api.database.com/v1/query', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${this.config.credentials}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          query: `${soqlQuery} LIMIT ${limit}`,
        }),
      });

      if (!response.ok) throw new Error(`Database.com error: ${response.statusText}`);

      const data = await response.json();
      return {
        records: data.records || [],
        totalRecords: data.totalSize || 0,
        extractedAt: new Date(),
      };
    } catch (error: any) {
      throw new Error(`Database.com extraction error: ${error.message}`);
    }
  }

  async testConnection(): Promise<boolean> {
    return this.connect();
  }
}

/**
 * Factory para crear conectores
 */
export class DatabaseConnectorFactory {
  static create(
    type: string,
    config: DatabaseConnectorConfig
  ): BaseDatabaseConnector {
    const typeUpper = type.toUpperCase();

    if (typeUpper.includes('SUPABASE')) {
      return new SupabaseConnector(config);
    } else if (typeUpper.includes('NOTION')) {
      return new NotionConnector(config);
    } else if (typeUpper.includes('OBSIDIAN')) {
      return new ObsidianConnector(config);
    } else if (typeUpper.includes('NOTEBOOKLM')) {
      return new NotebookLMConnector(config);
    } else if (typeUpper.includes('DATABASE')) {
      return new DatabaseComConnector(config);
    }

    throw new Error(`Tipo de BD no soportado: ${type}`);
  }
}

/**
 * Bases de datos soportadas
 */
export const SUPPORTED_DATABASES = [
  { id: 'supabase', name: 'Supabase', category: 'postgresql' },
  { id: 'notion', name: 'Notion', category: 'knowledge' },
  { id: 'obsidian', name: 'Obsidian', category: 'knowledge' },
  { id: 'notebooklm', name: 'NotebookLM', category: 'ai' },
  { id: 'database-com', name: 'Database.com', category: 'crm' },
];
