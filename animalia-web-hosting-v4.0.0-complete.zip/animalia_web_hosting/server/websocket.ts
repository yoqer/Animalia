import { Server } from "socket.io";
import { Express } from "express";

/**
 * WebSocket Server para Animalia
 * Maneja sincronización en tiempo real entre Desktop App y Web
 */

interface SyncMessage {
  type: "patterns" | "knowledge" | "conversations" | "retraining" | "status";
  action: "upload" | "download" | "update";
  data: any;
  timestamp: Date;
  userId: number;
}

interface ClientConnection {
  userId: number;
  deviceType: "web" | "desktop" | "mobile";
  lastSync: Date;
  isOnline: boolean;
}

const clients = new Map<string, ClientConnection>();
const syncQueue = new Map<number, SyncMessage[]>();

export function setupWebSocket(app: Express, server: any) {
  const io = new Server(server, {
    cors: {
      origin: process.env.VITE_FRONTEND_FORGE_API_URL || "*",
      methods: ["GET", "POST"],
      credentials: true,
    },
  });

  /**
   * Middleware de autenticación
   */
  io.use(async (socket: any, next: any) => {
    try {
      const token = socket.handshake.auth.token;
      if (!token) {
        return next(new Error("No authentication token provided"));
      }

      // Aquí se verificaría el token JWT
      // const user = await verifySessionCookie(token);
      // socket.userId = user.id;

      next();
    } catch (error) {
      next(new Error("Authentication failed"));
    }
  });

  /**
   * Conexión de cliente
   */
  io.on("connection", (socket: any) => {
    console.log(`[WebSocket] Cliente conectado: ${socket.id}`);

    // Registrar cliente
    const clientInfo: ClientConnection = {
      userId: 1, // Debería venir del token
      deviceType: socket.handshake.query.deviceType as "web" | "desktop" | "mobile" || "web",
      lastSync: new Date(),
      isOnline: true,
    };

    clients.set(socket.id, clientInfo);

    /**
     * Evento: Cliente solicita sincronización
     */
    socket.on("sync:request", (data: { since?: Date }) => {
      console.log(`[WebSocket] Sincronización solicitada por ${socket.id}`);

      const messages = syncQueue.get(clientInfo.userId) || [];
      const filteredMessages = data.since
        ? messages.filter((m) => m.timestamp > data.since!)
        : messages;

      socket.emit("sync:response", {
        success: true,
        messages: filteredMessages,
        timestamp: new Date(),
      });

      // Limpiar cola después de enviar
      syncQueue.set(clientInfo.userId, []);
    });

    /**
     * Evento: Cliente sube datos
     */
    socket.on("sync:upload", (message: SyncMessage) => {
      console.log(`[WebSocket] Upload recibido: ${message.type} de ${socket.id}`);

      // Guardar en cola para otros clientes
      const queue = syncQueue.get(clientInfo.userId) || [];
      queue.push(message);
      syncQueue.set(clientInfo.userId, queue);

      // Notificar a otros clientes del mismo usuario
      io.to(`user:${clientInfo.userId}`).emit("sync:update", {
        type: message.type,
        action: message.action,
        timestamp: new Date(),
      });

      socket.emit("sync:ack", {
        success: true,
        message: "Datos recibidos correctamente",
      });
    });

    /**
     * Evento: Cliente descarga datos
     */
    socket.on("sync:download", (data: { type: string; since?: Date }) => {
      console.log(`[WebSocket] Download solicitado: ${data.type} de ${socket.id}`);

      const messages = syncQueue.get(clientInfo.userId) || [];
      const filtered = messages.filter((m) => m.type === data.type);

      socket.emit("sync:data", {
        type: data.type,
        data: filtered,
        timestamp: new Date(),
      });
    });

    /**
     * Evento: Ping para verificar conexión
     */
    socket.on("ping", () => {
      socket.emit("pong", { timestamp: new Date() });
    });

    /**
     * Evento: Actualizar estado de cliente
     */
    socket.on("status:update", (status: any) => {
      clientInfo.lastSync = new Date();
      clientInfo.isOnline = true;

      // Notificar a otros clientes
      io.to(`user:${clientInfo.userId}`).emit("status:changed", {
        deviceType: clientInfo.deviceType,
        isOnline: true,
        lastSync: clientInfo.lastSync,
      });
    });

    /**
     * Evento: Solicitar estado de otros clientes
     */
    socket.on("status:query", () => {
      const userClients = Array.from(clients.values()).filter(
        (c) => c.userId === clientInfo.userId
      );

      socket.emit("status:response", {
        clients: userClients,
        timestamp: new Date(),
      });
    });

    /**
     * Desconexión
     */
    socket.on("disconnect", () => {
      console.log(`[WebSocket] Cliente desconectado: ${socket.id}`);
      clients.delete(socket.id);

      // Notificar a otros clientes
      io.to(`user:${clientInfo.userId}`).emit("status:changed", {
        deviceType: clientInfo.deviceType,
        isOnline: false,
        lastSync: clientInfo.lastSync,
      });
    });

    /**
     * Manejo de errores
     */
    socket.on("error", (error: any) => {
      console.error(`[WebSocket] Error en ${socket.id}:`, error);
    });
  });

  return io;
}

/**
 * Funciones auxiliares para usar WebSocket desde el servidor
 */

export function broadcastToUser(io: Server, userId: number, event: string, data: any) {
  io.to(`user:${userId}`).emit(event, data);
}

export function broadcastToDevice(io: Server, userId: number, deviceType: string, event: string, data: any) {
  const userClients = Array.from(clients.entries())
    .filter(([_, client]) => client.userId === userId && client.deviceType === deviceType)
    .map(([socketId, _]) => socketId);

  userClients.forEach((socketId) => {
    io.to(socketId).emit(event, data);
  });
}

export function getConnectedClients(userId: number) {
  return Array.from(clients.values()).filter((c) => c.userId === userId);
}
