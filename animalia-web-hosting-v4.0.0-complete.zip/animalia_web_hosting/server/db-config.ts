/**
 * Configuración de Base de Datos - Soporte Múltiple
 * 
 * Soporta: MySQL, PostgreSQL, MongoDB, SQLite
 * Detecta automáticamente la BD según .env
 */

import { drizzle } from "drizzle-orm/mysql2";
import { drizzle as drizzlePg } from "drizzle-orm/postgres-js";
import { drizzle as drizzleSqlite } from "drizzle-orm/better-sqlite3";
import { MongoClient } from "mongodb";
import postgres from "postgres";
import Database from "better-sqlite3";

export type DatabaseType = "mysql" | "postgresql" | "mongodb" | "sqlite";

interface DatabaseConfig {
  type: DatabaseType;
  url: string;
  options?: Record<string, any>;
}

/**
 * Detectar tipo de base de datos desde URL
 */
export function detectDatabaseType(url: string): DatabaseType {
  if (url.startsWith("mysql://")) return "mysql";
  if (url.startsWith("postgresql://") || url.startsWith("postgres://"))
    return "postgresql";
  if (url.startsWith("mongodb://") || url.startsWith("mongodb+srv://"))
    return "mongodb";
  if (url.startsWith("sqlite://") || url.endsWith(".db"))
    return "sqlite";
  
  // Default a MySQL si no se especifica
  return "mysql";
}

/**
 * Obtener configuración de BD desde .env
 */
export function getDatabaseConfig(): DatabaseConfig {
  const url = process.env.DATABASE_URL || "";
  const type = detectDatabaseType(url);

  return {
    type,
    url,
    options: {
      mysql: {
        connectionLimit: 10,
        waitForConnections: true,
        queueLimit: 0,
      },
      postgresql: {
        max: 10,
        idleTimeoutMillis: 30000,
        connectionTimeoutMillis: 2000,
      },
      mongodb: {
        maxPoolSize: 10,
        minPoolSize: 2,
      },
      sqlite: {
        fileMustExist: false,
        timeout: 5000,
      },
    }[type],
  };
}

/**
 * Inicializar conexión a base de datos
 */
export async function initializeDatabase() {
  const config = getDatabaseConfig();

  console.log(`[Database] Inicializando ${config.type.toUpperCase()}...`);

  try {
    switch (config.type) {
      case "mysql":
        return initializeMysql(config.url);

      case "postgresql":
        return initializePostgresql(config.url);

      case "mongodb":
        return initializeMongodb(config.url);

      case "sqlite":
        return initializeSqlite(config.url);

      default:
        throw new Error(`Tipo de BD no soportado: ${config.type}`);
    }
  } catch (error) {
    console.error(`[Database] Error al inicializar ${config.type}:`, error);
    throw error;
  }
}

/**
 * Inicializar MySQL
 */
function initializeMysql(url: string) {
  const mysql = require("mysql2/promise");
  const pool = mysql.createPool(url);
  return drizzle(pool);
}

/**
 * Inicializar PostgreSQL
 */
function initializePostgresql(url: string) {
  const client = postgres(url);
  return drizzlePg(client);
}

/**
 * Inicializar MongoDB
 */
async function initializeMongodb(url: string) {
  const client = new MongoClient(url);
  await client.connect();
  console.log("[Database] MongoDB conectado");
  return client.db("animalia");
}

/**
 * Inicializar SQLite
 */
function initializeSqlite(url: string) {
  const dbPath = url.replace("sqlite://", "");
  const db = new Database(dbPath);
  db.pragma("journal_mode = WAL");
  return drizzleSqlite(db);
}

/**
 * Verificar conexión a BD
 */
export async function verifyDatabaseConnection(): Promise<boolean> {
  try {
    const config = getDatabaseConfig();

    switch (config.type) {
      case "mysql": {
        const mysql = require("mysql2/promise");
        const connection = await mysql.createConnection(config.url);
        await connection.execute("SELECT 1");
        await connection.end();
        return true;
      }

      case "postgresql": {
        const client = postgres(config.url);
        await client`SELECT 1`;
        await client.end();
        return true;
      }

      case "mongodb": {
        const client = new MongoClient(config.url);
        await client.connect();
        await client.db("admin").command({ ping: 1 });
        await client.close();
        return true;
      }

      case "sqlite": {
        const dbPath = config.url.replace("sqlite://", "");
        const db = new Database(dbPath);
        db.exec("SELECT 1");
        db.close();
        return true;
      }

      default:
        return false;
    }
  } catch (error) {
    console.error("[Database] Error al verificar conexión:", error);
    return false;
  }
}

/**
 * Obtener información de la BD
 */
export async function getDatabaseInfo(): Promise<{
  type: DatabaseType;
  connected: boolean;
  tables?: number;
  size?: string;
}> {
  const config = getDatabaseConfig();
  const connected = await verifyDatabaseConnection();

  return {
    type: config.type,
    connected,
    tables: connected ? 6 : 0, // Número de tablas esperadas
    size: "variable",
  };
}

export default {
  detectDatabaseType,
  getDatabaseConfig,
  initializeDatabase,
  verifyDatabaseConnection,
  getDatabaseInfo,
};
