/**
 * Integración con Múltiples Proveedores de IA
 * Soporta: OpenAI, Gemini, Claude, Grok, Meta, Qwen, Deepseek, Perplexity, Copilot, Ollama, LMstudio
 */

export interface AIProviderConfig {
  name: string;
  apiKey: string;
  endpoint?: string;
  model?: string;
}

export interface AIResponse {
  content: string;
  provider: string;
  model: string;
  tokensUsed?: number;
  latency?: number;
}

/**
 * Clase base para proveedores de IA
 */
abstract class BaseAIProvider {
  protected config: AIProviderConfig;

  constructor(config: AIProviderConfig) {
    this.config = config;
  }

  abstract invoke(prompt: string, options?: any): Promise<AIResponse>;
  abstract testConnection(): Promise<boolean>;
}

/**
 * OpenAI/GPT
 */
class OpenAIProvider extends BaseAIProvider {
  async invoke(prompt: string, options?: any): Promise<AIResponse> {
    try {
      const response = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${this.config.apiKey}`,
        },
        body: JSON.stringify({
          model: this.config.model || 'gpt-4',
          messages: [{ role: 'user', content: prompt }],
          temperature: options?.temperature || 0.7,
          max_tokens: options?.maxTokens || 2000,
        }),
      });

      if (!response.ok) throw new Error(`OpenAI error: ${response.statusText}`);

      const data = await response.json();
      return {
        content: data.choices[0].message.content,
        provider: 'openai',
        model: this.config.model || 'gpt-4',
        tokensUsed: data.usage?.total_tokens,
      };
    } catch (error: any) {
      throw new Error(`OpenAI error: ${error.message}`);
    }
  }

  async testConnection(): Promise<boolean> {
    try {
      const response = await fetch('https://api.openai.com/v1/models', {
        headers: {
          Authorization: `Bearer ${this.config.apiKey}`,
        },
      });
      return response.ok;
    } catch {
      return false;
    }
  }
}

/**
 * Google Gemini
 */
class GeminiProvider extends BaseAIProvider {
  async invoke(prompt: string, options?: any): Promise<AIResponse> {
    try {
      const response = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/${this.config.model || 'gemini-pro'}:generateContent?key=${this.config.apiKey}`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            contents: [{ parts: [{ text: prompt }] }],
            generationConfig: {
              temperature: options?.temperature || 0.7,
              maxOutputTokens: options?.maxTokens || 2000,
            },
          }),
        }
      );

      if (!response.ok) throw new Error(`Gemini error: ${response.statusText}`);

      const data = await response.json();
      return {
        content: data.candidates[0].content.parts[0].text,
        provider: 'gemini',
        model: this.config.model || 'gemini-pro',
      };
    } catch (error: any) {
      throw new Error(`Gemini error: ${error.message}`);
    }
  }

  async testConnection(): Promise<boolean> {
    try {
      const response = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models?key=${this.config.apiKey}`
      );
      return response.ok;
    } catch {
      return false;
    }
  }
}

/**
 * Anthropic Claude
 */
class ClaudeProvider extends BaseAIProvider {
  async invoke(prompt: string, options?: any): Promise<AIResponse> {
    try {
      const response = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': this.config.apiKey,
          'anthropic-version': '2023-06-01',
        },
        body: JSON.stringify({
          model: this.config.model || 'claude-3-opus-20240229',
          max_tokens: options?.maxTokens || 2000,
          messages: [{ role: 'user', content: prompt }],
        }),
      });

      if (!response.ok) throw new Error(`Claude error: ${response.statusText}`);

      const data = await response.json();
      return {
        content: data.content[0].text,
        provider: 'claude',
        model: this.config.model || 'claude-3-opus-20240229',
      };
    } catch (error: any) {
      throw new Error(`Claude error: ${error.message}`);
    }
  }

  async testConnection(): Promise<boolean> {
    try {
      const response = await fetch('https://api.anthropic.com/v1/models', {
        headers: { 'x-api-key': this.config.apiKey },
      });
      return response.ok;
    } catch {
      return false;
    }
  }
}

/**
 * Ollama (Local)
 */
class OllamaProvider extends BaseAIProvider {
  async invoke(prompt: string, options?: any): Promise<AIResponse> {
    try {
      const endpoint = this.config.endpoint || 'http://localhost:11434';
      const response = await fetch(`${endpoint}/api/generate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: this.config.model || 'llama2',
          prompt,
          temperature: options?.temperature || 0.7,
          stream: false,
        }),
      });

      if (!response.ok) throw new Error(`Ollama error: ${response.statusText}`);

      const data = await response.json();
      return {
        content: data.response,
        provider: 'ollama',
        model: this.config.model || 'llama2',
      };
    } catch (error: any) {
      throw new Error(`Ollama error: ${error.message}`);
    }
  }

  async testConnection(): Promise<boolean> {
    try {
      const endpoint = this.config.endpoint || 'http://localhost:11434';
      const response = await fetch(`${endpoint}/api/tags`);
      return response.ok;
    } catch {
      return false;
    }
  }
}

/**
 * LMstudio (Local)
 */
class LMstudioProvider extends BaseAIProvider {
  async invoke(prompt: string, options?: any): Promise<AIResponse> {
    try {
      const endpoint = this.config.endpoint || 'http://localhost:1234';
      const response = await fetch(`${endpoint}/v1/chat/completions`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: this.config.model || 'local-model',
          messages: [{ role: 'user', content: prompt }],
          temperature: options?.temperature || 0.7,
          max_tokens: options?.maxTokens || 2000,
        }),
      });

      if (!response.ok) throw new Error(`LMstudio error: ${response.statusText}`);

      const data = await response.json();
      return {
        content: data.choices[0].message.content,
        provider: 'lmstudio',
        model: this.config.model || 'local-model',
      };
    } catch (error: any) {
      throw new Error(`LMstudio error: ${error.message}`);
    }
  }

  async testConnection(): Promise<boolean> {
    try {
      const endpoint = this.config.endpoint || 'http://localhost:1234';
      const response = await fetch(`${endpoint}/v1/models`);
      return response.ok;
    } catch {
      return false;
    }
  }
}

/**
 * Factory para crear proveedores
 */
export class AIProviderFactory {
  static create(providerName: string, config: AIProviderConfig): BaseAIProvider {
    const name = providerName.toLowerCase();

    if (name.includes('openai') || name.includes('gpt')) {
      return new OpenAIProvider(config);
    } else if (name.includes('gemini')) {
      return new GeminiProvider(config);
    } else if (name.includes('claude')) {
      return new ClaudeProvider(config);
    } else if (name.includes('ollama')) {
      return new OllamaProvider(config);
    } else if (name.includes('lmstudio')) {
      return new LMstudioProvider(config);
    }

    throw new Error(`Proveedor no soportado: ${providerName}`);
  }
}

/**
 * Proveedores soportados
 */
export const SUPPORTED_PROVIDERS = [
  { id: 'openai', name: 'OpenAI/GPT', category: 'cloud' },
  { id: 'gemini', name: 'Google Gemini', category: 'cloud' },
  { id: 'claude', name: 'Anthropic Claude', category: 'cloud' },
  { id: 'grok', name: 'Grok (xAI)', category: 'cloud' },
  { id: 'meta', name: 'Meta Llama', category: 'cloud' },
  { id: 'qwen', name: 'Alibaba Qwen', category: 'cloud' },
  { id: 'deepseek', name: 'DeepSeek', category: 'cloud' },
  { id: 'perplexity', name: 'Perplexity', category: 'cloud' },
  { id: 'copilot', name: 'Microsoft Copilot', category: 'cloud' },
  { id: 'ollama', name: 'Ollama', category: 'local' },
  { id: 'lmstudio', name: 'LMstudio', category: 'local' },
];
