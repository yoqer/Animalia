import axios from 'axios';
import { protectedProcedure, router } from './_core/trpc';
import { z } from 'zod';

/**
 * Sistema de Webhooks Extensible para Animalia
 * Soporta reintentos automáticos, logging y múltiples eventos
 */

// Tipos
export type WebhookEvent = 
  | 'pattern.created'
  | 'pattern.updated'
  | 'knowledge.imported'
  | 'sync.completed'
  | 'retraining.started'
  | 'retraining.completed'
  | 'ai.response';

export interface WebhookPayload {
  event: WebhookEvent;
  timestamp: Date;
  data: any;
  userId: string;
}

interface WebhookConfig {
  id: string;
  userId: string;
  url: string;
  events: WebhookEvent[];
  active: boolean;
  retries: number;
  maxRetries: number;
  secret?: string;
  createdAt: Date;
  lastTriggered?: Date;
}

interface WebhookLog {
  id: string;
  webhookId: string;
  event: WebhookEvent;
  status: 'success' | 'failed' | 'pending';
  statusCode?: number;
  response?: string;
  error?: string;
  retryCount: number;
  timestamp: Date;
}

// Almacenamiento en memoria (en producción usar BD)
const webhooks: Map<string, WebhookConfig> = new Map();
const webhookLogs: WebhookLog[] = [];

/**
 * Enviar webhook con reintentos automáticos
 */
export async function triggerWebhook(
  webhookConfig: WebhookConfig,
  payload: WebhookPayload,
  retryCount = 0
): Promise<void> {
  try {
    // Crear firma HMAC si existe secret
    let headers: any = {
      'Content-Type': 'application/json',
      'User-Agent': 'Animalia-Webhook/1.0',
    };

    if (webhookConfig.secret) {
      const crypto = require('crypto');
      const signature = crypto
        .createHmac('sha256', webhookConfig.secret)
        .update(JSON.stringify(payload))
        .digest('hex');
      headers['X-Animalia-Signature'] = signature;
    }

    // Enviar webhook
    const response = await axios.post(webhookConfig.url, payload, {
      headers,
      timeout: 10000,
    });

    // Registrar éxito
    logWebhookEvent({
      id: `log-${Date.now()}`,
      webhookId: webhookConfig.id,
      event: payload.event,
      status: 'success',
      statusCode: response.status,
      response: JSON.stringify(response.data),
      retryCount,
      timestamp: new Date(),
    });

    webhookConfig.lastTriggered = new Date();
  } catch (error: any) {
    // Registrar error
    logWebhookEvent({
      id: `log-${Date.now()}`,
      webhookId: webhookConfig.id,
      event: payload.event,
      status: retryCount >= webhookConfig.maxRetries ? 'failed' : 'pending',
      statusCode: error.response?.status,
      error: error.message,
      retryCount,
      timestamp: new Date(),
    });

    // Reintentar si no se alcanzó el máximo
    if (retryCount < webhookConfig.maxRetries) {
      const delay = Math.pow(2, retryCount) * 1000; // Exponential backoff
      setTimeout(() => {
        triggerWebhook(webhookConfig, payload, retryCount + 1);
      }, delay);
    }
  }
}

/**
 * Registrar evento de webhook
 */
function logWebhookEvent(log: WebhookLog): void {
  webhookLogs.push(log);
  // Mantener solo últimos 1000 logs
  if (webhookLogs.length > 1000) {
    webhookLogs.shift();
  }
}

/**
 * Router tRPC para gestión de webhooks
 */
export const webhookRouter = router({
  /**
   * Registrar nuevo webhook
   */
  register: protectedProcedure
    .input(
      z.object({
        url: z.string().url(),
        events: z.array(z.string()),
        secret: z.string().optional(),
        maxRetries: z.number().default(3),
      })
    )
    .mutation(({ ctx, input }) => {
      const webhookId = `webhook-${Date.now()}`;
      const config: WebhookConfig = {
        id: webhookId,
        userId: ctx.user?.id.toString() || 'unknown',
        url: input.url,
        events: input.events as WebhookEvent[],
        active: true,
        retries: 0,
        maxRetries: input.maxRetries,
        secret: input.secret,
        createdAt: new Date(),
      };

      webhooks.set(webhookId, config);
      return { id: webhookId, ...config };
    }),

  /**
   * Obtener webhooks del usuario
   */
  list: protectedProcedure.query(({ ctx }) => {
    const userId = ctx.user?.id.toString() || 'unknown';
    return Array.from(webhooks.values()).filter(w => w.userId === userId);
  }),

  /**
   * Actualizar webhook
   */
  update: protectedProcedure
    .input(
      z.object({
        id: z.string(),
        url: z.string().url().optional(),
        events: z.array(z.string()).optional(),
        active: z.boolean().optional(),
      })
    )
    .mutation(({ ctx, input }) => {
      const webhook = webhooks.get(input.id);
      if (!webhook || webhook.userId !== ctx.user?.id.toString()) {
        throw new Error('Webhook no encontrado');
      }

      if (input.url) webhook.url = input.url;
      if (input.events) webhook.events = input.events as WebhookEvent[];
      if (input.active !== undefined) webhook.active = input.active;

      return webhook;
    }),

  /**
   * Eliminar webhook
   */
  delete: protectedProcedure
    .input(z.object({ id: z.string() }))
    .mutation(({ ctx, input }) => {
      const webhook = webhooks.get(input.id);
      if (!webhook || webhook.userId !== ctx.user?.id.toString()) {
        throw new Error('Webhook no encontrado');
      }

      webhooks.delete(input.id);
      return { success: true };
    }),

  /**
   * Obtener historial de webhook
   */
  getHistory: protectedProcedure
    .input(z.object({ webhookId: z.string(), limit: z.number().default(50) }))
    .query(({ ctx, input }) => {
      const webhook = webhooks.get(input.webhookId);
      if (!webhook || webhook.userId !== ctx.user?.id.toString()) {
        throw new Error('Webhook no encontrado');
      }

      return webhookLogs
        .filter(log => log.webhookId === input.webhookId)
        .slice(-input.limit)
        .reverse();
    }),

  /**
   * Probar webhook
   */
  test: protectedProcedure
    .input(z.object({ id: z.string() }))
    .mutation(async ({ ctx, input }) => {
      const webhook = webhooks.get(input.id);
      if (!webhook || webhook.userId !== ctx.user?.id.toString()) {
        throw new Error('Webhook no encontrado');
      }

      const testPayload: WebhookPayload = {
        event: 'sync.completed',
        timestamp: new Date(),
        data: { test: true, message: 'Prueba de webhook' },
        userId: ctx.user?.id.toString() || 'test',
      };

      await triggerWebhook(webhook, testPayload);
      return { success: true };
    }),
});

/**
 * Disparar webhook para todos los usuarios interesados
 */
export async function broadcastWebhook(event: WebhookEvent, data: any): Promise<void> {
  const payload: WebhookPayload = {
    event,
    timestamp: new Date(),
    data,
    userId: 'system',
  };

  for (const webhook of webhooks.values()) {
    if (webhook.active && webhook.events.includes(event)) {
      triggerWebhook(webhook, payload);
    }
  }
}
