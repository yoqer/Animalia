import { protectedProcedure, router } from '../_core/trpc';
import { z } from 'zod';

/**
 * Router tRPC para Panel de Administración
 * Gestiona proveedores de IA, bases de datos y webhooks
 */

// Simulación de almacenamiento en memoria (en producción usar BD)
const aiProvidersStore = new Map<string, any>();
const databasesStore = new Map<string, any>();
const webhooksStore = new Map<string, any>();

export const adminRouter = router({
  /**
   * Listar todos los proveedores de IA configurados
   */
  listAIProviders: protectedProcedure.query(() => {
    return {
      providers: Array.from(aiProvidersStore.values()),
    };
  }),

  /**
   * Agregar nuevo proveedor de IA
   */
  addAIProvider: protectedProcedure
    .input(
      z.object({
        name: z.string(),
        apiKey: z.string(),
        endpoint: z.string().optional(),
      })
    )
    .mutation(({ input }) => {
      const id = `provider-${Date.now()}`;
      const provider = {
        id,
        name: input.name,
        apiKey: input.apiKey,
        endpoint: input.endpoint,
        active: true,
        type: detectProviderType(input.name),
        createdAt: new Date(),
      };
      aiProvidersStore.set(id, provider);
      return { success: true, provider };
    }),

  /**
   * Remover proveedor de IA
   */
  removeAIProvider: protectedProcedure
    .input(z.string())
    .mutation(({ input }) => {
      aiProvidersStore.delete(input);
      return { success: true };
    }),

  /**
   * Listar todas las bases de datos configuradas
   */
  listDatabases: protectedProcedure.query(() => {
    return {
      databases: Array.from(databasesStore.values()),
    };
  }),

  /**
   * Agregar nueva base de datos
   */
  addDatabase: protectedProcedure
    .input(
      z.object({
        name: z.string(),
        type: z.enum([
          'supabase',
          'database-com',
          'notion',
          'obsidian',
          'notebooklm',
          'postgresql',
          'mongodb',
          'custom',
        ]),
        credentials: z.string(),
      })
    )
    .mutation(({ input }) => {
      const id = `db-${Date.now()}`;
      const database = {
        id,
        name: input.name,
        type: input.type,
        credentials: input.credentials,
        connected: false,
        createdAt: new Date(),
      };
      databasesStore.set(id, database);
      return { success: true, database };
    }),

  /**
   * Remover base de datos
   */
  removeDatabase: protectedProcedure
    .input(z.string())
    .mutation(({ input }) => {
      databasesStore.delete(input);
      return { success: true };
    }),

  /**
   * Listar todos los webhooks
   */
  listWebhooks: protectedProcedure.query(() => {
    return {
      webhooks: Array.from(webhooksStore.values()),
    };
  }),

  /**
   * Probar conexión con proveedor o BD
   */
  testConnection: protectedProcedure
    .input(
      z.object({
        type: z.enum(['ai-provider', 'database']),
        id: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      try {
        if (input.type === 'ai-provider') {
          const provider = aiProvidersStore.get(input.id);
          if (!provider) throw new Error('Proveedor no encontrado');

          // Simular prueba de conexión
          await new Promise((resolve) => setTimeout(resolve, 1000));

          return {
            success: true,
            message: `Conexión exitosa con ${provider.name}`,
            latency: Math.random() * 500,
          };
        } else {
          const database = databasesStore.get(input.id);
          if (!database) throw new Error('Base de datos no encontrada');

          // Simular prueba de conexión
          await new Promise((resolve) => setTimeout(resolve, 1000));

          database.connected = true;
          return {
            success: true,
            message: `Conexión exitosa con ${database.name}`,
            latency: Math.random() * 500,
          };
        }
      } catch (error: any) {
        return {
          success: false,
          error: error.message,
        };
      }
    }),

  /**
   * Extraer datos de base de datos para entrenamiento
   */
  extractTrainingData: protectedProcedure
    .input(
      z.object({
        databaseId: z.string(),
        query: z.string().optional(),
        limit: z.number().default(1000),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const database = databasesStore.get(input.databaseId);
        if (!database) throw new Error('Base de datos no encontrada');

        // Simular extracción de datos
        const mockData = {
          records: [
            {
              id: 1,
              content: 'Datos de ejemplo para entrenamiento',
              source: database.name,
              timestamp: new Date(),
            },
          ],
          totalRecords: 1,
          extractedAt: new Date(),
        };

        return {
          success: true,
          data: mockData,
        };
      } catch (error: any) {
        return {
          success: false,
          error: error.message,
        };
      }
    }),

  /**
   * Configurar caché Redis
   */
  configureRedis: protectedProcedure
    .input(
      z.object({
        host: z.string(),
        port: z.number(),
        password: z.string().optional(),
        ttl: z.number().default(3600),
      })
    )
    .mutation(({ input }) => {
      // En producción, guardar en BD
      return {
        success: true,
        message: 'Configuración de Redis guardada',
        config: input,
      };
    }),

  /**
   * Obtener estadísticas del sistema
   */
  getStats: protectedProcedure.query(() => {
    return {
      aiProviders: aiProvidersStore.size,
      databases: databasesStore.size,
      webhooks: webhooksStore.size,
      totalConnections: aiProvidersStore.size + databasesStore.size,
    };
  }),
});

/**
 * Detectar tipo de proveedor por nombre
 */
function detectProviderType(name: string): string {
  const nameUpper = name.toUpperCase();
  if (nameUpper.includes('OPENAI') || nameUpper.includes('GPT')) return 'openai';
  if (nameUpper.includes('GEMINI')) return 'gemini';
  if (nameUpper.includes('CLAUDE')) return 'claude';
  if (nameUpper.includes('GROK')) return 'grok';
  if (nameUpper.includes('META')) return 'meta';
  if (nameUpper.includes('QWEN')) return 'qwen';
  if (nameUpper.includes('DEEPSEEK')) return 'deepseek';
  if (nameUpper.includes('PERPLEXITY')) return 'perplexity';
  if (nameUpper.includes('COPILOT')) return 'copilot';
  if (nameUpper.includes('OLLAMA')) return 'ollama';
  if (nameUpper.includes('LMSTUDIO')) return 'lmstudio';
  return 'custom';
}
