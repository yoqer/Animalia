import { protectedProcedure, router } from '../_core/trpc';
import { z } from 'zod';
import { aiOrchestrator, standardMCPTools, AIProvider } from '../ai-orchestrator';

/**
 * Router tRPC para Orquestador de IA
 * Permite seleccionar proveedor de IA por solicitud
 */

export const aiRouter = router({
  /**
   * Invocar IA con proveedor especificado
   */
  invoke: protectedProcedure
    .input(
      z.object({
        prompt: z.string(),
        provider: z.enum(['openai', 'manus', 'local', 'agent']),
        model: z.string().optional(),
        agentId: z.string().optional(),
        temperature: z.number().min(0).max(1).default(0.7),
        maxTokens: z.number().default(2000),
        context: z.record(z.any()).optional(),
        useMCPTools: z.boolean().default(true),
      })
    )
    .mutation(async ({ ctx, input }) => {
      try {
        const response = await aiOrchestrator.invoke({
          prompt: input.prompt,
          config: {
            provider: input.provider as AIProvider,
            model: input.model,
            agentId: input.agentId,
            temperature: input.temperature,
            maxTokens: input.maxTokens,
          },
          context: input.context,
          tools: input.useMCPTools ? standardMCPTools : undefined,
        });

        return {
          success: true,
          content: response.content,
          provider: response.provider,
          model: response.model,
          tokensUsed: response.tokensUsed,
          metadata: response.metadata,
        };
      } catch (error: any) {
        return {
          success: false,
          error: error.message,
          provider: input.provider,
        };
      }
    }),

  /**
   * Invocar con fallback automático
   */
  invokeWithFallback: protectedProcedure
    .input(
      z.object({
        prompt: z.string(),
        primaryProvider: z.enum(['openai', 'manus', 'local', 'agent']),
        fallbackProviders: z.array(z.enum(['openai', 'manus', 'local', 'agent'])).default(['manus', 'local']),
        model: z.string().optional(),
        temperature: z.number().min(0).max(1).default(0.7),
      })
    )
    .mutation(async ({ ctx, input }) => {
      try {
        const response = await aiOrchestrator.invokeWithFallback(
          {
            prompt: input.prompt,
            config: {
              provider: input.primaryProvider as AIProvider,
              model: input.model,
              temperature: input.temperature,
            },
          },
          input.fallbackProviders as AIProvider[]
        );

        return {
          success: true,
          content: response.content,
          provider: response.provider,
          model: response.model,
          usedFallback: response.provider !== input.primaryProvider,
        };
      } catch (error: any) {
        return {
          success: false,
          error: error.message,
        };
      }
    }),

  /**
   * Listar proveedores disponibles
   */
  listProviders: protectedProcedure.query(() => {
    return {
      providers: [
        {
          id: 'openai',
          name: 'OpenAI GPT',
          description: 'Modelos GPT-4 y GPT-3.5 de OpenAI',
          available: !!process.env.OPENAI_API_KEY,
          models: ['gpt-4', 'gpt-3.5-turbo'],
        },
        {
          id: 'manus',
          name: 'Manus API',
          description: 'Modelos de IA de Manus',
          available: true,
          models: ['manus-default'],
        },
        {
          id: 'local',
          name: 'LLM Local',
          description: 'Modelos LLM ejecutados localmente (Ollama, etc.)',
          available: !!process.env.LOCAL_LLM_ENDPOINT,
          models: ['llama2', 'mistral', 'neural-chat'],
        },
        {
          id: 'agent',
          name: 'Agentes Personalizados',
          description: 'Agentes como Clawbot u otros agentes personalizados',
          available: true,
          models: [],
        },
      ],
    };
  }),

  /**
   * Obtener herramientas MCP disponibles
   */
  getMCPTools: protectedProcedure.query(() => {
    return {
      tools: standardMCPTools.map(tool => ({
        name: tool.name,
        description: tool.description,
        parameters: tool.parameters,
      })),
    };
  }),

  /**
   * Registrar agente personalizado
   */
  registerAgent: protectedProcedure
    .input(
      z.object({
        agentId: z.string(),
        name: z.string(),
        description: z.string(),
        config: z.record(z.any()),
      })
    )
    .mutation(({ ctx, input }) => {
      // En producción, guardar en BD
      aiOrchestrator.registerAgent(input.agentId, {
        id: input.agentId,
        name: input.name,
        description: input.description,
        config: input.config,
        process: async (request: any) => {
          // Lógica del agente personalizado
          return {
            content: `Respuesta del agente ${input.agentId}`,
            metadata: { agentId: input.agentId },
          };
        },
      });

      return {
        success: true,
        agentId: input.agentId,
      };
    }),

  /**
   * Probar conexión con proveedor
   */
  testProvider: protectedProcedure
    .input(
      z.object({
        provider: z.enum(['openai', 'manus', 'local', 'agent']),
        model: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      try {
        const response = await aiOrchestrator.invoke({
          prompt: 'Responde con una palabra: "funcionando"',
          config: {
            provider: input.provider as AIProvider,
            model: input.model,
            maxTokens: 10,
          },
        });

        return {
          success: true,
          provider: input.provider,
          response: response.content,
          latency: Date.now(),
        };
      } catch (error: any) {
        return {
          success: false,
          provider: input.provider,
          error: error.message,
        };
      }
    }),
});
