import { invokeLLM } from './_core/llm';
import axios from 'axios';
import { z } from 'zod';

/**
 * Orquestador de IA Multi-Proveedor
 * Soporta: OpenAI/GPT, Manus API, LLM Local, Agentes (Clawbot)
 */

export type AIProvider = 'openai' | 'manus' | 'local' | 'agent';

export interface AIConfig {
  provider: AIProvider;
  model?: string;
  apiKey?: string;
  endpoint?: string;
  agentId?: string;
  temperature?: number;
  maxTokens?: number;
}

export interface AIRequest {
  prompt: string;
  config: AIConfig;
  context?: Record<string, any>;
  tools?: AITool[];
}

export interface AIResponse {
  content: string;
  provider: AIProvider;
  model?: string;
  tokensUsed?: number;
  metadata?: Record<string, any>;
}

export interface AITool {
  name: string;
  description: string;
  parameters: Record<string, any>;
  handler: (params: any) => Promise<any>;
}

/**
 * Clase base para proveedores de IA
 */
abstract class AIProviderBase {
  abstract invoke(request: AIRequest): Promise<AIResponse>;
}

/**
 * Proveedor: OpenAI/GPT
 */
class OpenAIProvider extends AIProviderBase {
  private apiKey: string;
  private endpoint: string = 'https://api.openai.com/v1/chat/completions';

  constructor(apiKey: string) {
    super();
    this.apiKey = apiKey;
  }

  async invoke(request: AIRequest): Promise<AIResponse> {
    try {
      const response = await axios.post(
        this.endpoint,
        {
          model: request.config.model || 'gpt-4',
          messages: [
            {
              role: 'system',
              content: 'Eres un asistente inteligente para Animalia, un sistema de comunicación multi-especies.',
            },
            { role: 'user', content: request.prompt },
          ],
          temperature: request.config.temperature || 0.7,
          max_tokens: request.config.maxTokens || 2000,
          tools: request.tools?.map(tool => ({
            type: 'function',
            function: {
              name: tool.name,
              description: tool.description,
              parameters: tool.parameters,
            },
          })),
        },
        {
          headers: {
            Authorization: `Bearer ${this.apiKey}`,
            'Content-Type': 'application/json',
          },
        }
      );

      return {
        content: response.data.choices[0].message.content,
        provider: 'openai',
        model: request.config.model || 'gpt-4',
        tokensUsed: response.data.usage?.total_tokens,
        metadata: {
          finishReason: response.data.choices[0].finish_reason,
        },
      };
    } catch (error: any) {
      throw new Error(`OpenAI Error: ${error.message}`);
    }
  }
}

/**
 * Proveedor: Manus API
 */
class ManusProvider extends AIProviderBase {
  private apiKey: string;
  private endpoint: string;

  constructor(apiKey: string, endpoint: string = 'https://api.manus.im/v1') {
    super();
    this.apiKey = apiKey;
    this.endpoint = endpoint;
  }

  async invoke(request: AIRequest): Promise<AIResponse> {
    try {
      // Usar la función invokeLLM de Manus
      const response = await invokeLLM({
        messages: [
          {
            role: 'system',
            content: 'Eres un asistente inteligente para Animalia.',
          },
          { role: 'user', content: request.prompt },
        ],
        temperature: request.config.temperature || 0.7,
      });

      return {
        content: response.choices[0].message.content,
        provider: 'manus',
        model: request.config.model || 'manus-default',
        metadata: {
          finishReason: response.choices[0].finish_reason,
        },
      };
    } catch (error: any) {
      throw new Error(`Manus Error: ${error.message}`);
    }
  }
}

/**
 * Proveedor: LLM Local
 */
class LocalLLMProvider extends AIProviderBase {
  private endpoint: string;

  constructor(endpoint: string = 'http://localhost:11434') {
    super();
    this.endpoint = endpoint;
  }

  async invoke(request: AIRequest): Promise<AIResponse> {
    try {
      const response = await axios.post(
        `${this.endpoint}/api/generate`,
        {
          model: request.config.model || 'llama2',
          prompt: request.prompt,
          stream: false,
          temperature: request.config.temperature || 0.7,
        },
        { timeout: 60000 }
      );

      return {
        content: response.data.response,
        provider: 'local',
        model: request.config.model || 'llama2',
        metadata: {
          context: response.data.context,
        },
      };
    } catch (error: any) {
      throw new Error(`Local LLM Error: ${error.message}`);
    }
  }
}

/**
 * Proveedor: Agentes (Clawbot, etc.)
 */
class AgentProvider extends AIProviderBase {
  private agentRegistry: Map<string, any> = new Map();

  registerAgent(agentId: string, agent: any): void {
    this.agentRegistry.set(agentId, agent);
  }

  async invoke(request: AIRequest): Promise<AIResponse> {
    const agentId = request.config.agentId;
    if (!agentId) {
      throw new Error('agentId es requerido para provider "agent"');
    }

    const agent = this.agentRegistry.get(agentId);
    if (!agent) {
      throw new Error(`Agente no encontrado: ${agentId}`);
    }

    try {
      const response = await agent.process({
        prompt: request.prompt,
        context: request.context,
        tools: request.tools,
      });

      return {
        content: response.content || response,
        provider: 'agent',
        model: agentId,
        metadata: response.metadata,
      };
    } catch (error: any) {
      throw new Error(`Agent Error: ${error.message}`);
    }
  }
}

/**
 * Orquestador Principal
 */
export class AIOrchestrator {
  private providers: Map<AIProvider, AIProviderBase> = new Map();
  private agentProvider: AgentProvider;

  constructor() {
    this.agentProvider = new AgentProvider();
    this.providers.set('agent', this.agentProvider);
  }

  /**
   * Configurar proveedor de OpenAI
   */
  configureOpenAI(apiKey: string): void {
    this.providers.set('openai', new OpenAIProvider(apiKey));
  }

  /**
   * Configurar proveedor de Manus
   */
  configureManus(apiKey: string, endpoint?: string): void {
    this.providers.set('manus', new ManusProvider(apiKey, endpoint));
  }

  /**
   * Configurar proveedor de LLM Local
   */
  configureLocalLLM(endpoint?: string): void {
    this.providers.set('local', new LocalLLMProvider(endpoint));
  }

  /**
   * Registrar agente personalizado
   */
  registerAgent(agentId: string, agent: any): void {
    this.agentProvider.registerAgent(agentId, agent);
  }

  /**
   * Invocar IA con proveedor especificado
   */
  async invoke(request: AIRequest): Promise<AIResponse> {
    const provider = this.providers.get(request.config.provider);
    if (!provider) {
      throw new Error(`Proveedor no configurado: ${request.config.provider}`);
    }

    return provider.invoke(request);
  }

  /**
   * Invocar con fallback automático
   */
  async invokeWithFallback(
    request: AIRequest,
    fallbackProviders: AIProvider[] = ['manus', 'local']
  ): Promise<AIResponse> {
    try {
      return await this.invoke(request);
    } catch (error) {
      console.warn(`Fallo en proveedor ${request.config.provider}, intentando fallback...`);

      for (const fallback of fallbackProviders) {
        try {
          request.config.provider = fallback;
          return await this.invoke(request);
        } catch (fallbackError) {
          console.warn(`Fallback ${fallback} también falló`);
        }
      }

      throw error;
    }
  }
}

/**
 * Instancia global del orquestador
 */
export const aiOrchestrator = new AIOrchestrator();

// Configurar proveedores por defecto
if (process.env.OPENAI_API_KEY) {
  aiOrchestrator.configureOpenAI(process.env.OPENAI_API_KEY);
}

aiOrchestrator.configureManus(
  process.env.BUILT_IN_FORGE_API_KEY || 'default',
  process.env.BUILT_IN_FORGE_API_URL
);

if (process.env.LOCAL_LLM_ENDPOINT) {
  aiOrchestrator.configureLocalLLM(process.env.LOCAL_LLM_ENDPOINT);
}

/**
 * Herramientas MCP estándar
 */
export const standardMCPTools: AITool[] = [
  {
    name: 'search_patterns',
    description: 'Buscar patrones de comportamiento animal',
    parameters: {
      type: 'object',
      properties: {
        query: { type: 'string', description: 'Término de búsqueda' },
        limit: { type: 'number', description: 'Límite de resultados' },
      },
      required: ['query'],
    },
    handler: async (params) => {
      // Implementar búsqueda de patrones
      return { results: [] };
    },
  },
  {
    name: 'get_knowledge',
    description: 'Obtener base de conocimiento',
    parameters: {
      type: 'object',
      properties: {
        category: { type: 'string', description: 'Categoría de conocimiento' },
      },
    },
    handler: async (params) => {
      // Implementar obtención de conocimiento
      return { knowledge: [] };
    },
  },
  {
    name: 'request_retraining',
    description: 'Solicitar reentrenamiento del modelo',
    parameters: {
      type: 'object',
      properties: {
        datasetId: { type: 'string', description: 'ID del dataset' },
        epochs: { type: 'number', description: 'Número de épocas' },
      },
      required: ['datasetId'],
    },
    handler: async (params) => {
      // Implementar solicitud de reentrenamiento
      return { trainingId: 'training-' + Date.now() };
    },
  },
];
